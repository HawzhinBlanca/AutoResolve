#!/bin/bash

# Pro Auto Editor - Production Startup Script
# Starts the hardened production application

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PRODUCTION_PORT=${PORT:-8080}
PRODUCTION_HOST=${HOST:-0.0.0.0}
LOG_LEVEL=${LOG_LEVEL:-INFO}
MAX_WORKERS=${MAX_WORKERS:-4}

# Functions
print_header() {
    echo -e "${BLUE}================================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}================================================${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

check_requirements() {
    print_header "Checking Requirements"
    
    # Check Python
    if command -v python3 &> /dev/null; then
        print_success "Python3 installed: $(python3 --version)"
    else
        print_error "Python3 not found"
        exit 1
    fi
    
    # Check FFmpeg
    if command -v ffmpeg &> /dev/null; then
        print_success "FFmpeg installed: $(ffmpeg -version 2>&1 | head -1)"
    else
        print_error "FFmpeg not found"
        exit 1
    fi
    
    # Check disk space
    available_space=$(df -h . | awk 'NR==2 {print $4}')
    print_success "Available disk space: $available_space"
}

setup_environment() {
    print_header "Setting Up Environment"
    
    # Create required directories
    directories=(
        "data"
        "logs"
        "temp"
        "uploads"
        "artifacts/editdata"
        "artifacts/renders"
        "artifacts/logs"
        "static"
    )
    
    for dir in "${directories[@]}"; do
        if [ ! -d "$dir" ]; then
            mkdir -p "$dir"
            print_success "Created directory: $dir"
        fi
    done
    
    # Set permissions
    chmod 755 data logs temp uploads artifacts
    
    # Check/create virtual environment
    if [ ! -d "venv" ]; then
        print_warning "Creating virtual environment..."
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Install/upgrade dependencies
    print_warning "Installing production dependencies..."
    pip install --quiet --upgrade pip
    
    if [ -f "requirements_production.txt" ]; then
        pip install --quiet -r requirements_production.txt
    else
        pip install --quiet -r requirements.txt
    fi
    
    print_success "Environment ready"
}

start_services() {
    print_header "Starting Services"
    
    # Kill any existing processes
    pkill -f "production_app.py" 2>/dev/null || true
    pkill -f "backend_service.py" 2>/dev/null || true
    pkill -f "web_gui.py" 2>/dev/null || true
    
    sleep 2
    
    # Start production app
    print_warning "Starting production app on port $PRODUCTION_PORT..."
    
    export PYTHONUNBUFFERED=1
    export LOG_LEVEL=$LOG_LEVEL
    export MAX_WORKERS=$MAX_WORKERS
    
    nohup python3 production_app.py > logs/production.log 2>&1 &
    PROD_PID=$!
    
    echo $PROD_PID > .production.pid
    
    sleep 3
    
    # Check if started successfully
    if kill -0 $PROD_PID 2>/dev/null; then
        print_success "Production app started (PID: $PROD_PID)"
    else
        print_error "Failed to start production app"
        tail -20 logs/production.log
        exit 1
    fi
}

health_check() {
    print_header "Running Health Check"
    
    # Wait for service to be ready
    max_attempts=10
    attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if curl -s -f "http://$PRODUCTION_HOST:$PRODUCTION_PORT/health" > /dev/null 2>&1; then
            print_success "Health check passed"
            
            # Get detailed health status
            health_status=$(curl -s "http://$PRODUCTION_HOST:$PRODUCTION_PORT/health")
            
            # Parse and display key metrics
            if command -v jq &> /dev/null; then
                echo -e "\n${BLUE}System Status:${NC}"
                echo "$health_status" | jq -r '
                    "CPU: \(.resources.cpu_percent)%",
                    "Memory: \(.resources.memory_percent)%",
                    "Disk: \(.resources.disk_percent)%",
                    "Services:",
                    "  FFmpeg: \(.services.ffmpeg)",
                    "  Database: \(.services.database)",
                    "  Resolve: \(.services.resolve)"
                '
            fi
            
            return 0
        fi
        
        attempt=$((attempt + 1))
        print_warning "Waiting for service to start... ($attempt/$max_attempts)"
        sleep 2
    done
    
    print_error "Health check failed after $max_attempts attempts"
    return 1
}

show_info() {
    print_header "Pro Auto Editor - Production Ready"
    
    echo -e "${GREEN}Service Status:${NC}"
    echo "  Web Interface: http://$PRODUCTION_HOST:$PRODUCTION_PORT"
    echo "  API Endpoint:  http://$PRODUCTION_HOST:$PRODUCTION_PORT/api"
    echo "  WebSocket:     ws://$PRODUCTION_HOST:$PRODUCTION_PORT/ws"
    echo "  Health Check:  http://$PRODUCTION_HOST:$PRODUCTION_PORT/health"
    echo ""
    echo -e "${GREEN}Monitoring:${NC}"
    echo "  Logs:          tail -f logs/production.log"
    echo "  Process:       ps aux | grep production_app"
    echo "  Stop:          ./stop_production.sh"
    echo ""
    echo -e "${GREEN}Features Enabled:${NC}"
    echo "  ✓ Error recovery with automatic retry"
    echo "  ✓ File validation and security checks"
    echo "  ✓ Progress tracking via WebSocket"
    echo "  ✓ Health monitoring and auto-recovery"
    echo "  ✓ Job queue with persistent storage"
    echo "  ✓ Rate limiting and resource management"
    echo "  ✓ Production logging and monitoring"
    echo ""
    print_success "System ready for production use!"
}

# Main execution
main() {
    print_header "Pro Auto Editor - Production Startup"
    
    check_requirements
    setup_environment
    start_services
    
    if health_check; then
        show_info
        
        # Open in browser
        if [ "$(uname)" == "Darwin" ]; then
            open "http://$PRODUCTION_HOST:$PRODUCTION_PORT"
        elif [ "$(uname)" == "Linux" ]; then
            xdg-open "http://$PRODUCTION_HOST:$PRODUCTION_PORT" 2>/dev/null || true
        fi
    else
        print_error "Startup failed. Check logs/production.log for details"
        exit 1
    fi
}

# Run main function
main