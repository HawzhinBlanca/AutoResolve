#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
from pathlib import Path


def srt_timestamp(seconds: float) -> str:
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int(round((seconds - int(seconds)) * 1000))
    return f"{hours:02}:{minutes:02}:{secs:02},{millis:03}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True, help='transcript.json from faster-whisper')
    ap.add_argument('--output', required=True, help='output .srt path')
    args = ap.parse_args()
    data = json.loads(Path(args.input).read_text())
    segs = data.get('segments', [])
    lines = []
    for i, s in enumerate(segs, 1):
        start = float(s['start'])
        end = float(s['end'])
        text = str(s['text']).strip()
        if not text:
            continue
        lines.append(str(i))
        lines.append(f"{srt_timestamp(start)} --> {srt_timestamp(end)}")
        lines.append(text)
        lines.append('')
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    Path(args.output).write_text('\n'.join(lines))
    print(f'wrote {args.output}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
