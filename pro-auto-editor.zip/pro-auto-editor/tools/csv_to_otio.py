#!/usr/bin/env python3
from __future__ import annotations
import csv
import sys
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List
import opentimelineio as otio

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


def parse_timecode_to_seconds(tc: str) -> Optional[float]:
    """Parse various timecode formats to seconds.
    
    Supports:
    - HH:MM:SS
    - HH:MM:SS.mmm (with milliseconds)
    - HH:MM:SS;FF (with frame numbers)
    - MM:SS or SS (shorter formats)
    """
    if not tc or not isinstance(tc, str):
        return None
        
    tc = tc.strip()
    
    try:
        # Handle frame-based timecode (HH:MM:SS;FF or HH:MM:SS:FF)
        if ';' in tc or tc.count(':') == 3:
            separator = ';' if ';' in tc else ':'
            parts = tc.split(separator)
            if len(parts) == 4:  # HH:MM:SS:FF
                hh, mm, ss, ff = parts
                return int(hh) * 3600 + int(mm) * 60 + int(ss) + int(ff) / 30.0  # Assume 30fps
            elif len(parts) == 2:  # SS;FF
                ss, ff = parts
                return int(ss) + int(ff) / 30.0
        
        # Handle colon-separated timecode
        parts = tc.split(':')
        
        if len(parts) == 3:  # HH:MM:SS or HH:MM:SS.mmm
            hh, mm, ss = parts
            if '.' in ss:
                sec, ms = ss.split('.')
                return int(hh) * 3600 + int(mm) * 60 + int(sec) + float(f'0.{ms}')
            return int(hh) * 3600 + int(mm) * 60 + int(ss)
            
        elif len(parts) == 2:  # MM:SS
            mm, ss = parts
            if '.' in ss:
                sec, ms = ss.split('.')
                return int(mm) * 60 + int(sec) + float(f'0.{ms}')
            return int(mm) * 60 + int(ss)
            
        elif len(parts) == 1:  # Just seconds
            return float(tc)
            
    except (ValueError, IndexError) as e:
        logger.warning(f"Failed to parse timecode '{tc}': {e}")
        return None
        
    logger.warning(f"Unrecognized timecode format: '{tc}'")
    return None


def detect_csv_format(csv_path: Path) -> Dict[str, str]:
    """Detect CSV format and column mappings."""
    with csv_path.open() as f:
        sample = f.read(1024)
        f.seek(0)
        
        # Detect delimiter
        sniffer = csv.Sniffer()
        delimiter = sniffer.sniff(sample).delimiter
        
        # Read header
        reader = csv.DictReader(f, delimiter=delimiter)
        headers = reader.fieldnames or []
        
    logger.info(f"Detected CSV format: delimiter='{delimiter}', headers={headers}")
    
    # Map common column variations
    column_map = {}
    for header in headers:
        header_lower = header.lower().strip()
        
        # Start time columns
        if any(x in header_lower for x in ['start', 'begin', 'in']):
            if any(x in header_lower for x in ['time', 'timecode', 'tc']):
                if any(x in header_lower for x in ['second', 's', '(s)']):
                    column_map['start_seconds'] = header
                else:
                    column_map['start_timecode'] = header
                    
        # End time columns
        elif any(x in header_lower for x in ['end', 'finish', 'out']):
            if any(x in header_lower for x in ['time', 'timecode', 'tc']):
                if any(x in header_lower for x in ['second', 's', '(s)']):
                    column_map['end_seconds'] = header
                else:
                    column_map['end_timecode'] = header
                    
        # Duration columns
        elif any(x in header_lower for x in ['duration', 'length']):
            if any(x in header_lower for x in ['second', 's', '(s)']):
                column_map['duration_seconds'] = header
            else:
                column_map['duration_timecode'] = header
                
        # Scene/clip name columns
        elif any(x in header_lower for x in ['scene', 'clip', 'name', 'title']):
            column_map['name'] = header
            
    logger.info(f"Column mapping: {column_map}")
    return column_map


def validate_inputs(csv_path: Path, otio_path: Path, fps: float) -> None:
    """Validate input parameters."""
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV file not found: {csv_path}")
        
    if not csv_path.suffix.lower() == '.csv':
        raise ValueError(f"Input file must be CSV format: {csv_path}")
        
    if fps <= 0:
        raise ValueError(f"FPS must be positive: {fps}")
        
    # Ensure output directory exists
    otio_path.parent.mkdir(parents=True, exist_ok=True)


def main() -> int:
    if len(sys.argv) < 3 or len(sys.argv) > 4:
        print('usage: csv_to_otio.py <csv> <otio_out> [fps]', file=sys.stderr)
        print('       fps defaults to 30.0 if not specified', file=sys.stderr)
        return 2
        
    try:
        csv_path = Path(sys.argv[1]).expanduser().resolve()
        otio_path = Path(sys.argv[2]).expanduser().resolve()
        fps = float(sys.argv[3]) if len(sys.argv) == 4 else 30.0
        
        # Validate inputs
        validate_inputs(csv_path, otio_path, fps)
        
        logger.info(f"Converting CSV to OTIO: {csv_path} -> {otio_path} @ {fps}fps")
        
        # Detect CSV format
        column_map = detect_csv_format(csv_path)
        
    except (ValueError, FileNotFoundError) as e:
        logger.error(f"Input validation failed: {e}")
        return 1

        # Create timeline
        tl = otio.schema.Timeline(name=csv_path.stem)
        track = otio.schema.Track(kind=otio.schema.TrackKind.Video, name='scenes')
        tl.tracks.append(track)
        
        clips_created = 0
        clips_skipped = 0
        
        with csv_path.open() as f:
            reader = csv.DictReader(f)
            
            for row_num, row in enumerate(reader, 1):
                try:
                    # Extract timing information using flexible column matching
                    start_s, end_s, duration_s = extract_timing_from_row(row, column_map)
                    
                    if start_s is None:
                        logger.warning(f"Row {row_num}: No valid start time found")
                        clips_skipped += 1
                        continue
                        
                    # Calculate duration
                    if end_s is not None:
                        dur_s = max(0.0, end_s - start_s)
                    elif duration_s is not None:
                        dur_s = max(0.0, duration_s)
                        end_s = start_s + dur_s
                    else:
                        logger.warning(f"Row {row_num}: No valid end time or duration found")
                        clips_skipped += 1
                        continue
                        
                    if dur_s <= 0:
                        logger.warning(f"Row {row_num}: Invalid duration {dur_s}s")
                        clips_skipped += 1
                        continue
                        
                    # Create clip name
                    clip_name = get_clip_name(row, column_map, row_num, start_s)
                    
                    # Create OTIO clip
                    clip = otio.schema.Clip(
                        name=clip_name,
                        source_range=otio.opentime.TimeRange(
                            otio.opentime.RationalTime(start_s * fps, fps),
                            otio.opentime.RationalTime(dur_s * fps, fps),
                        ),
                        metadata={
                            'csv_row': row_num,
                            'start_seconds': start_s,
                            'end_seconds': end_s,
                            'duration_seconds': dur_s,
                            'source_data': dict(row)  # Store original CSV data
                        }
                    )
                    
                    track.append(clip)
                    clips_created += 1
                    logger.debug(f"Created clip: {clip_name} ({start_s:.3f}s - {end_s:.3f}s)")
                    
                except Exception as e:
                    logger.error(f"Row {row_num}: Failed to process - {e}")
                    clips_skipped += 1
                    continue
        
        # Write OTIO file
        otio.adapters.write_to_file(tl, str(otio_path))
        
        logger.info(f"Conversion complete: {clips_created} clips created, {clips_skipped} skipped")
        logger.info(f"Output written to: {otio_path}")
        print(f'Successfully wrote {clips_created} clips to {otio_path}')
        
        return 0
        
    except Exception as e:
        logger.error(f"Conversion failed: {e}")
        return 1


def extract_timing_from_row(row: Dict[str, str], column_map: Dict[str, str]) -> tuple[Optional[float], Optional[float], Optional[float]]:
    """Extract start time, end time, and duration from CSV row."""
    start_s = None
    end_s = None
    duration_s = None
    
    # Try mapped columns first
    if 'start_seconds' in column_map and row.get(column_map['start_seconds']):
        try:
            start_s = float(row[column_map['start_seconds']])
        except (ValueError, TypeError) as e:
            logger.debug(f"Failed to parse start_seconds '{row[column_map['start_seconds']]}': {e}")
            
    if 'end_seconds' in column_map and row.get(column_map['end_seconds']):
        try:
            end_s = float(row[column_map['end_seconds']])
        except (ValueError, TypeError) as e:
            logger.debug(f"Failed to parse end_seconds '{row[column_map['end_seconds']]}': {e}")
            
    if 'duration_seconds' in column_map and row.get(column_map['duration_seconds']):
        try:
            duration_s = float(row[column_map['duration_seconds']])
        except (ValueError, TypeError) as e:
            logger.debug(f"Failed to parse duration_seconds '{row[column_map['duration_seconds']]}': {e}")
    
    # Fallback to timecode parsing
    if start_s is None and 'start_timecode' in column_map:
        start_s = parse_timecode_to_seconds(row.get(column_map['start_timecode'], ''))
        
    if end_s is None and 'end_timecode' in column_map:
        end_s = parse_timecode_to_seconds(row.get(column_map['end_timecode'], ''))
        
    if duration_s is None and 'duration_timecode' in column_map:
        duration_s = parse_timecode_to_seconds(row.get(column_map['duration_timecode'], ''))
    
    # Generic fallback - try common column names
    if start_s is None:
        for key in ('Start Time (s)', 'Start Time Seconds', 'Start Timecode (seconds)', 'start_time', 'start'):
            if row.get(key):
                try:
                    start_s = float(row[key])
                    break
                except (ValueError, TypeError):
                    continue
                    
    if start_s is None:
        for key in ('Start Timecode', 'start_tc', 'in_point'):
            if row.get(key):
                start_s = parse_timecode_to_seconds(row[key])
                if start_s is not None:
                    break
                    
    if end_s is None:
        for key in ('End Time (s)', 'End Time Seconds', 'End Timecode (seconds)', 'end_time', 'end'):
            if row.get(key):
                try:
                    end_s = float(row[key])
                    break
                except (ValueError, TypeError):
                    continue
                    
    if end_s is None:
        for key in ('End Timecode', 'end_tc', 'out_point'):
            if row.get(key):
                end_s = parse_timecode_to_seconds(row[key])
                if end_s is not None:
                    break
    
    return start_s, end_s, duration_s


def get_clip_name(row: Dict[str, str], column_map: Dict[str, str], row_num: int, start_s: float) -> str:
    """Generate clip name from CSV data."""
    # Try mapped name column first
    if 'name' in column_map and row.get(column_map['name']):
        name = row[column_map['name']].strip()
        if name:
            return name
    
    # Try common name columns
    for key in ('Scene', 'Clip', 'Name', 'Title', 'description', 'label'):
        if row.get(key):
            name = row[key].strip()
            if name:
                return name
    
    # Fallback to generated name
    return f'scene_{row_num:03d}_{start_s:.3f}s'


if __name__ == '__main__':
    try:
        exit_code = main()
        sys.exit(exit_code)
    except KeyboardInterrupt:
        logger.info("Conversion cancelled by user")
        sys.exit(130)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        sys.exit(1)
