#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from faster_whisper import WhisperModel


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Transcribe audio/video to JSON using faster-whisper")
    parser.add_argument("--input", required=True, help="Input media file (audio/video)")
    parser.add_argument("--output", required=True, help="Output transcript JSON path")
    parser.add_argument("--model", default="base", help="Whisper model size")
    parser.add_argument("--compute_type", default="int8", help="Compute type for Apple Silicon")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    in_path = Path(args.input).expanduser().resolve()
    out_path = Path(args.output).expanduser().resolve()

    if not in_path.exists():
        print(f"input not found: {in_path}", file=sys.stderr)
        return 2

    out_path.parent.mkdir(parents=True, exist_ok=True)

    model = WhisperModel(args.model, compute_type=args.compute_type)
    segments, info = model.transcribe(str(in_path))

    result = {
        "duration": info.duration,
        "language": info.language,
        "segments": [
            {
                "start": s.start,
                "end": s.end,
                "text": s.text,
            }
            for s in segments
        ],
    }

    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2))
    print(f"wrote {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
