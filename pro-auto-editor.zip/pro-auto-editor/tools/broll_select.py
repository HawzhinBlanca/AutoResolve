#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
from pathlib import Path
from typing import List
import numpy as np

from broll.query import extract_phrases, encode_text_embeddings
from broll.select import load_clip_index, rank_clips_for_window, make_selection_json


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--transcript', required=False, help='transcript.json path (optional)')
    ap.add_argument('--db', required=True, help='broll sqlite index')
    ap.add_argument('--output', required=True, help='output broll_selection.json')
    ap.add_argument('--window_start', type=float, default=0.0)
    ap.add_argument('--window_duration', type=float, default=60.0)
    ap.add_argument('--k', type=int, default=8)
    args = ap.parse_args()

    clip_index = load_clip_index(Path(args.db))
    if not clip_index:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(json.dumps({'window_start': args.window_start, 'window_duration': args.window_duration, 'clips': []}, indent=2))
        print(json.dumps({'selected': 0}))
        return 0

    phrases: List[str] = []
    if args.transcript and Path(args.transcript).exists():
        try:
            phrases = extract_phrases(Path(args.transcript))
        except Exception:
            phrases = []
    if not phrases:
        phrases = ['nature', 'city', 'people']

    text_embs = encode_text_embeddings(phrases)
    query_emb = np.mean(text_embs, axis=0)
    query_emb = query_emb / (np.linalg.norm(query_emb) + 1e-8)

    picks = rank_clips_for_window(clip_index, query_emb, k=args.k)
    make_selection_json(Path(args.output), args.window_start, args.window_duration, picks)
    print(json.dumps({'selected': len(picks)}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
