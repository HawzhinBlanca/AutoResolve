#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
from pathlib import Path


def validate_selection(sel_path: Path) -> bool:
    try:
        data = json.loads(sel_path.read_text())
    except Exception:
        return False
    if 'clips' not in data or not isinstance(data['clips'], list):
        return False
    # window bounds
    start = float(data.get('window_start', 0.0))
    dur = float(data.get('window_duration', 0.0))
    if dur <= 0:
        return False
    # ensure unique paths and non-empty
    seen = set()
    for c in data['clips']:
        p = c.get('path')
        if not p or p in seen:
            return False
        seen.add(p)
    return True


def check_bounds_and_coverage(sel_path: Path, scenes_path: Path, min_cover_ratio: float = 0.25, max_cover_ratio: float = 0.55) -> bool:
    data = json.loads(sel_path.read_text())
    try:
        import opentimelineio as otio
    except Exception:
        # If OTIO not available, fail the QC as per zero-tolerance
        return False

    tl = otio.adapters.read_from_file(str(scenes_path))
    # Build a simple list of scene intervals
    vtrack = next((t for t in tl.tracks if t.kind == otio.schema.TrackKind.Video), None)
    if vtrack is None:
        return False
    scene_bounds = []
    for clip in vtrack:
        sr = clip.source_range
        start_s = float(sr.start_time.to_seconds())
        dur_s = float(sr.duration.to_seconds())
        scene_bounds.append((start_s, start_s + dur_s))

    # Check B-roll clips are within overall window and do not exceed coverage limits
    window_start = float(data.get('window_start', 0.0))
    window_end = window_start + float(data.get('window_duration', 0.0))
    clips = data.get('clips', [])

    # Use configured per-clip seconds if available in selection json
    per_clip_seconds = float(data.get('per_clip_seconds', 3.0))
    total_cover = len(clips) * per_clip_seconds
    window_duration = window_end - window_start
    cover_ratio = 0.0 if window_duration <= 0 else total_cover / window_duration

    if cover_ratio < min_cover_ratio or cover_ratio > max_cover_ratio:
        return False

    # Simplified collision check: ensure dedup already performed and fixed staggering prevents overlap
    # No-repeat window check
    no_repeat_window = int(data.get('no_repeat_window', 3))
    paths = [c.get('path') for c in clips if c.get('path')]
    for i in range(len(paths)):
        window = paths[max(0, i - no_repeat_window):i]
        if paths[i] in window:
            return False
    return True


if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    sel = root / 'artifacts' / 'editdata' / 'broll_selection.json'
    scenes = root / 'artifacts' / 'editdata' / 'scenes.otio'
    if not sel.exists() or not validate_selection(sel):
        print('invalid or missing broll selection', file=sys.stderr)
        sys.exit(1)
    if not scenes.exists() or not check_bounds_and_coverage(sel, scenes):
        print('broll bounds/coverage check failed', file=sys.stderr)
        sys.exit(2)
    sys.exit(0)
