#!/usr/bin/env python3
from __future__ import annotations
import json
import subprocess
import sys
from pathlib import Path


def probe(path: Path) -> dict:
    cmd = [
        'ffprobe','-v','error',
        '-show_entries','format=filename,duration:stream=codec_name,codec_type,width,height,display_aspect_ratio',
        '-of','json',str(path)
    ]
    out = subprocess.check_output(cmd)
    return json.loads(out.decode('utf-8'))


if __name__ == '__main__':
    renders = Path(__file__).resolve().parents[1] / 'artifacts' / 'renders'
    outs = sorted(renders.glob('*.mp4')) + sorted(renders.glob('*.mov'))
    if not outs:
        print('no renders found', file=sys.stderr)
        sys.exit(1)
    report = probe(outs[-1])
    # Validate basic profile fields
    fmt = report.get('format', {})
    streams = report.get('streams', [])
    if not fmt or not streams:
        print('ffprobe missing data', file=sys.stderr)
        sys.exit(2)
    v = next((s for s in streams if s.get('codec_type') == 'video'), {})
    if int(v.get('width', 0)) <= 0 or int(v.get('height', 0)) <= 0:
        print('invalid video dimensions', file=sys.stderr)
        sys.exit(3)
    # Check codec and DAR sane values
    codec = v.get('codec_name')
    if codec not in {'h264','hevc','prores','mpeg4'}:
        print(f'unexpected codec: {codec}', file=sys.stderr)
        sys.exit(4)
    dar = v.get('display_aspect_ratio')
    if not dar:
        print('missing display aspect ratio', file=sys.stderr)
        sys.exit(5)
    # Basic duration check
    try:
        dur = float(fmt.get('duration', 0.0))
    except Exception:
        dur = 0.0
    if dur <= 0.0:
        print('invalid duration', file=sys.stderr)
        sys.exit(6)
    sys.exit(0)
