#!/usr/bin/env python3
from __future__ import annotations
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
import opentimelineio as otio


def extract_fcpxml_cuts(fcpxml_path: Path) -> list[float]:
    """Extract cut points from FCPXML file."""
    cuts = []
    try:
        tree = ET.parse(str(fcpxml_path))
        root = tree.getroot()
        
        # Find all asset-clips in the spine
        for clip in root.findall('.//asset-clip'):
            # Get offset and duration
            offset = clip.get('offset', '0s')
            duration = clip.get('duration', '0s')
            start = clip.get('start', '0s')
            
            # Convert to seconds
            def parse_time(time_str):
                if time_str.endswith('s'):
                    time_str = time_str[:-1]
                if '/' in time_str:
                    # Frame-based time like "101/24s"
                    frames, fps = time_str.split('/')
                    return float(frames) / float(fps)
                return float(time_str)
            
            offset_sec = parse_time(offset)
            duration_sec = parse_time(duration)
            start_sec = parse_time(start) if start else 0
            
            cuts.append(offset_sec)
            cuts.append(offset_sec + duration_sec)
    except Exception as e:
        print(f'Error parsing FCPXML: {e}', file=sys.stderr)
        return []
    
    return sorted(set(cuts))


def extract_timeline_cuts(timeline_path: Path) -> list[float]:
    """Extract cut points from exported timeline (OTIO format)."""
    cuts = []
    try:
        tl = otio.adapters.read_from_file(str(timeline_path))
        
        # Find video track
        vtrack = next((t for t in tl.tracks if t.kind == otio.schema.TrackKind.Video), None)
        if not vtrack:
            return cuts
        
        current_time = 0.0
        for item in vtrack:
            if isinstance(item, (otio.schema.Clip, otio.schema.Gap)):
                # Get source range
                if hasattr(item, 'source_range') and item.source_range:
                    start_time = float(item.source_range.start_time.to_seconds())
                    duration = float(item.source_range.duration.to_seconds())
                    
                    cuts.append(current_time)
                    current_time += duration
                    cuts.append(current_time)
    except Exception as e:
        print(f'Error parsing timeline: {e}', file=sys.stderr)
        return []
    
    return sorted(set(cuts))


def verify_parity(fcpxml_cuts: list[float], timeline_cuts: list[float], tolerance: float = 1.0/30.0) -> bool:
    """
    Verify FCPXML cuts match timeline cuts within tolerance (±1 frame at 30fps).
    
    Blueprint requirement: Verify cuts match within ±1 frame tolerance.
    """
    if len(fcpxml_cuts) == 0 or len(timeline_cuts) == 0:
        print('Empty cut list', file=sys.stderr)
        return False
    
    # For each FCPXML cut, find closest timeline cut
    mismatches = []
    for fc in fcpxml_cuts:
        # Find closest timeline cut
        if timeline_cuts:
            closest = min(timeline_cuts, key=lambda tc: abs(tc - fc))
            diff = abs(closest - fc)
            
            if diff > tolerance:
                mismatches.append((fc, closest, diff))
    
    if mismatches:
        print(f'Found {len(mismatches)} mismatches beyond ±1 frame tolerance:', file=sys.stderr)
        for fc, tc, diff in mismatches[:5]:  # Show first 5
            print(f'  FCPXML {fc:.3f}s vs Timeline {tc:.3f}s (diff: {diff:.3f}s)', file=sys.stderr)
        return False
    
    return True


if __name__ == '__main__':
    editdata = Path(__file__).resolve().parents[1] / 'artifacts' / 'editdata'
    cuts_path = editdata / 'cuts.fcpxml'
    
    # Check for timeline export (would be created after Resolve import/export)
    timeline_path = editdata / 'timeline_export.otio'
    
    if not cuts_path.exists():
        print('cuts.fcpxml not found', file=sys.stderr)
        sys.exit(2)
    
    # Extract cuts from FCPXML
    fcpxml_cuts = extract_fcpxml_cuts(cuts_path)
    
    if not fcpxml_cuts:
        print('No cuts found in FCPXML', file=sys.stderr)
        sys.exit(1)
    
    print(f'Found {len(fcpxml_cuts)} cut points in FCPXML')
    
    # If timeline export exists, verify parity
    if timeline_path.exists():
        timeline_cuts = extract_timeline_cuts(timeline_path)
        
        if verify_parity(fcpxml_cuts, timeline_cuts):
            print('✅ FCPXML and timeline cuts match within ±1 frame tolerance')
            sys.exit(0)
        else:
            print('❌ FCPXML and timeline cuts DO NOT match', file=sys.stderr)
            sys.exit(1)
    else:
        # Fall back to scenes.otio for basic validation, but still enforce data presence
        scenes_path = editdata / 'scenes.otio'
        if scenes_path.exists():
            scene_cuts = extract_timeline_cuts(scenes_path)
            print(f'Using scenes.otio for validation ({len(scene_cuts)} scene boundaries)')
            # Require both to have cut data at minimum
            if fcpxml_cuts and scene_cuts:
                print('✅ Both FCPXML and scenes have cut data')
                sys.exit(0)
            else:
                print('❌ scenes.otio does not provide sufficient cut data', file=sys.stderr)
                sys.exit(1)
    
    print('❌ Timeline export not available for full parity check', file=sys.stderr)
    sys.exit(1)