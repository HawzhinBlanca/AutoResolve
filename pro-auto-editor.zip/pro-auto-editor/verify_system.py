#!/usr/bin/env python3
"""
System Verification Script for AutoResolve
Ensures everything works flawlessly before deployment
"""

import sys
import os
import ast
import json
import yaml
import importlib
from pathlib import Path
from typing import List, Tuple

def check_syntax() -> Tuple[bool, List[str]]:
    """Verify all Python files compile without syntax errors."""
    errors = []
    py_files = []
    
    for root, dirs, files in os.walk('.'):
        if '__pycache__' in root:
            continue
        for file in files:
            if file.endswith('.py'):
                filepath = Path(root) / file
                py_files.append(filepath)
                try:
                    with open(filepath, 'r') as f:
                        ast.parse(f.read())
                except SyntaxError as e:
                    errors.append(f"{filepath}: {e}")
    
    return len(errors) == 0, errors

def check_imports() -> Tuple[bool, List[str]]:
    """Verify critical modules import successfully."""
    critical_modules = [
        'resolve_api.core',
        'resolve_api.timeline_ops',
        'resolve_api.render_ops',
        'pipelines.shortsify',
        'pipelines.multicam_podcast',
        'broll.index',
        'broll.select',
        'production_app',
        'utils.constants',
        'utils.file_validator',
        'utils.error_handler',
    ]
    
    errors = []
    for module in critical_modules:
        try:
            importlib.import_module(module)
        except ImportError as e:
            errors.append(f"{module}: {e}")
    
    return len(errors) == 0, errors

def check_configs() -> Tuple[bool, List[str]]:
    """Verify all configuration files are valid."""
    errors = []
    
    # Check YAML configs
    yaml_files = ['conf/project.yaml', 'conf/broll.yaml']
    for yaml_file in yaml_files:
        if Path(yaml_file).exists():
            try:
                with open(yaml_file, 'r') as f:
                    yaml.safe_load(f)
            except yaml.YAMLError as e:
                errors.append(f"{yaml_file}: {e}")
        else:
            errors.append(f"{yaml_file}: File not found")
    
    # Check JSON presets
    json_files = [
        'presets/render/YouTube_1080p.json',
        'presets/render/TikTok_1080x1920.json',
        'presets/render/Square_1080.json'
    ]
    for json_file in json_files:
        if Path(json_file).exists():
            try:
                with open(json_file, 'r') as f:
                    json.load(f)
            except json.JSONDecodeError as e:
                errors.append(f"{json_file}: {e}")
        else:
            errors.append(f"{json_file}: File not found")
    
    return len(errors) == 0, errors

def check_structure() -> Tuple[bool, List[str]]:
    """Verify required directory structure exists."""
    required_dirs = [
        'resolve_api',
        'pipelines',
        'broll',
        'utils',
        'tests',
        'presets',
        'presets/render',
        'conf',
        'scripts',
        'tools',
        'MacGUI',
        'static',
        'artifacts',
        'inputs'
    ]
    
    missing = []
    for dir_path in required_dirs:
        if not Path(dir_path).is_dir():
            missing.append(dir_path)
    
    return len(missing) == 0, missing

def check_security() -> Tuple[bool, List[str]]:
    """Check for security vulnerabilities."""
    issues = []
    
    for root, dirs, files in os.walk('.'):
        if '__pycache__' in root:
            continue
        for file in files:
            if file.endswith('.py') and file != 'verify_system.py':  # Skip self
                filepath = Path(root) / file
                with open(filepath, 'r') as f:
                    content = f.read()
                    # Check for unsafe eval (not model.eval())
                    lines = content.split('\n')
                    for i, line in enumerate(lines, 1):
                        # Skip comments and string literals
                        stripped = line.strip()
                        if stripped.startswith('#'):
                            continue
                        if 'eval(' in line and 'model.eval()' not in line and 'literal_eval' not in line:
                            issues.append(f"{filepath}:{i} - Unsafe eval() usage")
                        if 'pickle.loads(' in line:
                            issues.append(f"{filepath}:{i} - Unsafe pickle.loads()")
                        if 'exec(' in line and 'subprocess_exec' not in line:
                            issues.append(f"{filepath}:{i} - Unsafe exec() usage")
    
    return len(issues) == 0, issues

def check_performance_features() -> Tuple[bool, List[str]]:
    """Verify performance optimizations are in place."""
    features = []
    missing = []
    
    # Check for caching
    if Path('utils/cache_manager.py').exists():
        features.append("ML model caching implemented")
    else:
        missing.append("utils/cache_manager.py - Caching not implemented")
    
    # Check for constants
    if Path('utils/constants.py').exists():
        features.append("Centralized constants implemented")
    else:
        missing.append("utils/constants.py - Constants not centralized")
    
    # Check for optimized requirements
    if Path('requirements_optimized.txt').exists():
        features.append("Optimized dependencies available")
    else:
        missing.append("requirements_optimized.txt - Optimized deps missing")
    
    return len(missing) == 0, features if len(missing) == 0 else missing

def main():
    """Run all verification checks."""
    print("="*60)
    print("AUTORESOLVE SYSTEM VERIFICATION")
    print("="*60)
    
    all_passed = True
    
    # 1. Syntax Check
    print("\n1. SYNTAX CHECK:")
    passed, errors = check_syntax()
    if passed:
        print("   ✅ All Python files compile successfully")
    else:
        print(f"   ❌ {len(errors)} syntax errors found:")
        for error in errors[:3]:
            print(f"      - {error}")
        all_passed = False
    
    # 2. Import Check
    print("\n2. IMPORT CHECK:")
    passed, errors = check_imports()
    if passed:
        print("   ✅ All critical modules import successfully")
    else:
        print(f"   ❌ {len(errors)} import errors found:")
        for error in errors[:3]:
            print(f"      - {error}")
        all_passed = False
    
    # 3. Config Check
    print("\n3. CONFIGURATION CHECK:")
    passed, errors = check_configs()
    if passed:
        print("   ✅ All configuration files valid")
    else:
        print(f"   ❌ {len(errors)} config errors found:")
        for error in errors[:3]:
            print(f"      - {error}")
        all_passed = False
    
    # 4. Structure Check
    print("\n4. DIRECTORY STRUCTURE CHECK:")
    passed, missing = check_structure()
    if passed:
        print("   ✅ All required directories present")
    else:
        print(f"   ❌ {len(missing)} directories missing:")
        for dir_path in missing[:3]:
            print(f"      - {dir_path}")
        all_passed = False
    
    # 5. Security Check
    print("\n5. SECURITY CHECK:")
    passed, issues = check_security()
    if passed:
        print("   ✅ No security vulnerabilities detected")
    else:
        print(f"   ⚠️  {len(issues)} potential security issues:")
        for issue in issues[:3]:
            print(f"      - {issue}")
        all_passed = False
    
    # 6. Performance Check
    print("\n6. PERFORMANCE FEATURES CHECK:")
    passed, results = check_performance_features()
    if passed:
        print("   ✅ All performance optimizations in place:")
        for feature in results:
            print(f"      - {feature}")
    else:
        print(f"   ⚠️  Some optimizations missing:")
        for missing in results[:3]:
            print(f"      - {missing}")
    
    # Final Summary
    print("\n" + "="*60)
    if all_passed:
        print("✅ VERIFICATION PASSED - SYSTEM IS 100% FUNCTIONAL!")
        print("   AutoResolve is ready for production deployment.")
        return 0
    else:
        print("⚠️  VERIFICATION FAILED - Issues need attention")
        print("   Please fix the issues above before deployment.")
        return 1

if __name__ == "__main__":
    sys.exit(main())