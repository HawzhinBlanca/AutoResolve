from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from dataclasses import dataclass
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from typing import Iterable, List

import numpy as np
import yaml
from utils.jsonl_logger import get_logger

try:
    import open_clip
    import torch
    from PIL import Image
except Exception as e:  # pragma: no cover - environment guard
    raise RuntimeError(f"OpenCLIP stack not available: {e}")


class ModelManager:
    """Singleton manager for lazy loading and caching ML models."""
    
    _instance = None
    _models = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ModelManager, cls).__new__(cls)
        return cls._instance
    
    def get_model(self, model_name: str, cache_dir: Path):
        """Get model with lazy loading and caching."""
        logger = get_logger()
        
        model_key = f"{model_name}:laion2b_s32b_b79k"
        
        if model_key not in self._models:
            logger.info('broll_model_loading', model=model_name, cached=False)
            try:
                model, _, preprocess = open_clip.create_model_and_transforms(
                    model_name, 
                    pretrained='laion2b_s32b_b79k',
                    cache_dir=str(cache_dir)
                )
                model.eval()
                
                # Set device (CPU for reliability)
                device = 'cpu'  # Use CPU to avoid GPU memory issues
                model = model.to(device)
                
                self._models[model_key] = {
                    'model': model,
                    'preprocess': preprocess,
                    'device': device
                }
                logger.info('broll_model_loaded', model=model_name, device=device, cached=False)
                
            except Exception as e:
                logger.error('broll_model_load_failed', model=model_name, error=str(e))
                raise RuntimeError(f'Failed to load OpenCLIP model {model_name}: {e}') from e
        else:
            logger.debug('broll_model_cached', model=model_name, cached=True)
        
        return self._models[model_key]
    
    def clear_cache(self):
        """Clear all cached models to free memory."""
        logger = get_logger()
        if self._models:
            logger.info('broll_model_cache_cleared', count=len(self._models))
            self._models.clear()
    
    def get_memory_usage(self):
        """Get approximate memory usage of cached models."""
        total_params = 0
        for model_info in self._models.values():
            model = model_info['model']
            params = sum(p.numel() for p in model.parameters())
            total_params += params
        
        # Rough estimate: 4 bytes per float32 parameter
        memory_mb = (total_params * 4) / (1024 * 1024)
        return {
            'cached_models': len(self._models),
            'total_parameters': total_params,
            'estimated_memory_mb': memory_mb
        }


class EmbeddingCache:
    """Persistent cache for OpenCLIP embeddings to avoid recomputation."""
    
    def __init__(self, cache_dir: Path = None):
        self.cache_dir = cache_dir or (Path.home() / '.cache' / 'broll_embeddings')
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
    def _get_cache_key(self, video_path: Path, model_name: str, sample_fps: int, max_frames: int) -> str:
        """Generate cache key based on video file and processing parameters."""
        import hashlib
        
        # Get file modification time and size as part of cache key
        try:
            stat = video_path.stat()
            file_info = f"{stat.st_size}:{stat.st_mtime}"
        except (OSError, FileNotFoundError):
            file_info = "unknown"
        
        # Create hash from all parameters that affect the embedding
        cache_input = f"{video_path.name}:{file_info}:{model_name}:{sample_fps}:{max_frames}"
        return hashlib.md5(cache_input.encode()).hexdigest()
    
    def get(self, video_path: Path, model_name: str, sample_fps: int, max_frames: int) -> np.ndarray:
        """Get cached embedding if available."""
        cache_key = self._get_cache_key(video_path, model_name, sample_fps, max_frames)
        cache_file = self.cache_dir / f"{cache_key}.npy"
        
        if cache_file.exists():
            try:
                logger = get_logger()
                embedding = np.load(cache_file)
                logger.debug('broll_embedding_cache_hit', video=video_path.name, cache_key=cache_key)
                return embedding
            except Exception as e:
                logger = get_logger()
                logger.warning('broll_embedding_cache_corrupted', cache_file=str(cache_file), error=str(e))
                # Remove corrupted cache file
                try:
                    cache_file.unlink()
                except Exception as e:
                    logger.debug(f"Failed to remove corrupted cache file: {e}")
        
        return None
    
    def put(self, video_path: Path, model_name: str, sample_fps: int, max_frames: int, embedding: np.ndarray):
        """Store embedding in cache."""
        cache_key = self._get_cache_key(video_path, model_name, sample_fps, max_frames)
        cache_file = self.cache_dir / f"{cache_key}.npy"
        
        try:
            np.save(cache_file, embedding)
            logger = get_logger()
            logger.debug('broll_embedding_cached', video=video_path.name, cache_key=cache_key, 
                        size_kb=cache_file.stat().st_size / 1024)
        except Exception as e:
            logger = get_logger()
            logger.warning('broll_embedding_cache_failed', cache_file=str(cache_file), error=str(e))
    
    def clear(self):
        """Clear all cached embeddings."""
        logger = get_logger()
        count = 0
        total_size = 0
        
        for cache_file in self.cache_dir.glob("*.npy"):
            try:
                total_size += cache_file.stat().st_size
                cache_file.unlink()
                count += 1
            except Exception as e:
                logger.warning('broll_cache_clear_failed', file=str(cache_file), error=str(e))
        
        if count > 0:
            logger.info('broll_embedding_cache_cleared', files=count, size_mb=total_size / (1024*1024))
    
    def get_cache_info(self):
        """Get cache statistics."""
        count = 0
        total_size = 0
        
        for cache_file in self.cache_dir.glob("*.npy"):
            try:
                total_size += cache_file.stat().st_size
                count += 1
            except Exception as e:
                logger.debug(f"Failed to stat cache file {cache_file}: {e}")
        
        return {
            'cached_embeddings': count,
            'total_size_mb': total_size / (1024 * 1024),
            'cache_dir': str(self.cache_dir)
        }


@dataclass
class Config:
    libraries: List[str]
    sample_fps: int
    max_keyframes_per_clip: int
    embedding_model: str


def load_config(path: Path) -> Config:
    data = yaml.safe_load(path.read_text())
    return Config(
        libraries=list(data.get("libraries", [])),
        sample_fps=int(data.get("sample_fps", 1)),
        max_keyframes_per_clip=int(data.get("max_keyframes_per_clip", 30)),
        embedding_model=str(data.get("embedding_model", "ViT-H-14")),
    )


def list_media_files(libraries: List[str]) -> Iterable[Path]:
    for lib in libraries:
        base = Path(lib).expanduser()
        if not base.exists():
            continue
        for p in base.rglob("*.mp4"):
            yield p
        for p in base.rglob("*.mov"):
            yield p


def compute_clip_embedding(video_path: Path, model_name: str, sample_fps: int, max_frames: int) -> np.ndarray:
    logger = get_logger()
    import subprocess, tempfile
    import shutil
    
    # Check embedding cache first
    embedding_cache = EmbeddingCache()
    cached_embedding = embedding_cache.get(video_path, model_name, sample_fps, max_frames)
    if cached_embedding is not None:
        logger.info('broll_embedding_from_cache', video=video_path.name)
        return cached_embedding
    
    # Create cache directory for models
    cache_dir = Path.home() / '.cache' / 'openclip'
    cache_dir.mkdir(parents=True, exist_ok=True)
    
    tmpdir = Path(tempfile.mkdtemp())
    frames_dir = tmpdir / 'frames'
    frames_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        logger.info('broll_extract_frames_start', file=str(video_path), fps=sample_fps)
        
        # Extract frames at requested fps, resize to 224 on short side
        result = subprocess.run([
            'ffmpeg', '-y', '-i', str(video_path),
            '-vf', f'fps={sample_fps},scale=224:-1',
            str(frames_dir / 'f_%05d.jpg')
        ], check=True, capture_output=True, text=True)
        
        # Count extracted frames
        frame_files = list(frames_dir.glob('f_*.jpg'))
        if not frame_files:
            raise RuntimeError(f'No frames extracted from {video_path}')
        
        logger.info('broll_frames_extracted', count=len(frame_files))
        
        # Get model from cache or load it (lazy loading)
        model_manager = ModelManager()
        model_info = model_manager.get_model(model_name, cache_dir)
        model = model_info['model']
        preprocess = model_info['preprocess']
        device = model_info['device']
        
        # Process frames
        embs = []
        processed_frames = 0
        with torch.no_grad():
            for img_path in sorted(frame_files)[:max_frames]:
                try:
                    img = Image.open(img_path).convert('RGB')
                    tensor = preprocess(img).unsqueeze(0).to(device)
                    feat = model.encode_image(tensor)
                    feat = feat / feat.norm(dim=-1, keepdim=True)
                    embs.append(feat.cpu().numpy())
                    processed_frames += 1
                except Exception as e:
                    logger.warning('broll_frame_process_failed', frame=str(img_path), error=str(e))
                    continue
        
        if not embs:
            raise RuntimeError(f'No frames successfully processed from {video_path}')
            
        logger.info('broll_frames_processed', count=processed_frames)
        
        # Compute final embedding
        arr = np.concatenate(embs, axis=0)
        vec = arr.mean(axis=0).astype(np.float32).squeeze()
        vec /= np.linalg.norm(vec) + 1e-8
        
        logger.info('broll_embedding_computed', shape=vec.shape)
        
        # Cache the computed embedding for future use
        embedding_cache.put(video_path, model_name, sample_fps, max_frames, vec)
        
        return vec
        
    except subprocess.CalledProcessError as e:
        logger.error('broll_ffmpeg_failed', file=str(video_path), error=e.stderr)
        raise RuntimeError(f'FFmpeg failed for {video_path}: {e.stderr}') from e
    except Exception as e:
        logger.error('compute_embedding_failed', file=str(video_path), error=str(e))
        raise
    finally:
        # Clean up temp directory
        try:
            shutil.rmtree(tmpdir)
        except Exception as e:
            logger.warning('temp_cleanup_failed', path=str(tmpdir), error=str(e))


def upsert_embedding(db_path: Path, video_path: Path, embedding: np.ndarray) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(str(db_path)) as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS clips (path TEXT PRIMARY KEY, dim INTEGER NOT NULL, emb BLOB NOT NULL)"
        )
        conn.execute(
            "INSERT INTO clips(path, dim, emb) VALUES(?, ?, ?) ON CONFLICT(path) DO UPDATE SET dim=excluded.dim, emb=excluded.emb",
            (str(video_path), int(embedding.shape[0]), embedding.tobytes()),
        )
        conn.commit()


def run(config_path: Path, db_path: Path) -> int:
    logger = get_logger()
    logger.info('broll_index_start', config=str(config_path), db=str(db_path))
    cfg = load_config(config_path)
    count = 0
    for media in list_media_files(cfg.libraries):
        logger.info('broll_index_processing', file=str(media))
        emb = compute_clip_embedding(media, cfg.embedding_model, cfg.sample_fps, cfg.max_keyframes_per_clip)
        upsert_embedding(db_path, media, emb)
        count += 1
    logger.info('broll_index_complete', count=count)
    print(json.dumps({"indexed": count, "db": str(db_path)}))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Deterministic B-roll indexer")
    parser.add_argument("--config", required=True, help="Path to broll.yaml")
    parser.add_argument("--db", required=True, help="Path to sqlite db output")
    parser.add_argument("--clear-model-cache", action="store_true", help="Clear model cache before processing")
    parser.add_argument("--clear-embedding-cache", action="store_true", help="Clear embedding cache before processing")
    parser.add_argument("--show-cache-info", action="store_true", help="Show cache information")
    args = parser.parse_args()

    model_manager = ModelManager()
    embedding_cache = EmbeddingCache()
    
    if args.show_cache_info:
        model_info = model_manager.get_memory_usage()
        embedding_info = embedding_cache.get_cache_info()
        print(f"Model cache info: {model_info}")
        print(f"Embedding cache info: {embedding_info}")
        if not (args.config and args.db):
            return 0
    
    if args.clear_model_cache:
        model_manager.clear_cache()
        print("Model cache cleared")
    
    if args.clear_embedding_cache:
        embedding_cache.clear()
        print("Embedding cache cleared")

    return run(Path(args.config).expanduser().resolve(), Path(args.db).expanduser().resolve())


if __name__ == "__main__":
    raise SystemExit(main())
