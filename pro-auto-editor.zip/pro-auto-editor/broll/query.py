from __future__ import annotations
import json
from pathlib import Path
from typing import List
import spacy
import open_clip
import torch
import numpy as np


def extract_phrases(transcript_json: Path) -> List[str]:
    data = json.loads(transcript_json.read_text())
    text = ' '.join(seg.get('text','') for seg in data.get('segments', []))
    nlp = spacy.load('en_core_web_sm')
    doc = nlp(text)
    phrases = set()
    for np in doc.noun_chunks:
        t = np.text.strip()
        if len(t.split()) >= 1:
            phrases.add(t)
    # proper nouns as well
    for tok in doc:
        if tok.pos_ == 'PROPN':
            phrases.add(tok.text.strip())
    return list(phrases)


def encode_text_embeddings(phrases: List[str], model_name: str = 'ViT-H-14', pretrained: str = 'laion2b_s32b_b79k') -> np.ndarray:
    model, _, preprocess = open_clip.create_model_and_transforms(model_name, pretrained=pretrained)
    tokenizer = open_clip.get_tokenizer(model_name)
    model.eval()
    with torch.no_grad():
        tokens = tokenizer(phrases)
        text_features = model.encode_text(tokens)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)
    return text_features.cpu().numpy()
