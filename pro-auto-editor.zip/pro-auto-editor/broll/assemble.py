from __future__ import annotations
from pathlib import Path
from typing import List, Dict
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from resolve_api.core import ensure_absolute_path
from utils.jsonl_logger import get_logger


def load_selection(selection_json: Path) -> Dict:
    return json.loads(selection_json.read_text())


def assemble_v2(project: object, timeline: object, selection_json: Path) -> None:
    """Place B-roll on V2 via AppendToTimeline(recordFrame) as per Blueprint.md spec."""
    logger = get_logger()
    logger.info('broll_assemble_start', path=str(selection_json))
    
    # Load selection data
    sel = load_selection(selection_json)
    window_start = float(sel.get('window_start', 0.0))
    window_duration = float(sel.get('window_duration', 60.0))
    clips: List[Dict] = sel.get('clips', [])
    cross_dissolve_frames = int(sel.get('cross_dissolve_frames', 6))
    per_clip_seconds = float(sel.get('per_clip_seconds', 3.0))
    no_repeat_window = int(sel.get('no_repeat_window', 3))
    
    if not clips:
        logger.info('broll_assemble_no_clips')
        return
    
    # Get media pool and timeline settings
    media_pool = project.GetMediaPool()
    fps = float(timeline.GetSetting('timelineFrameRate') or 30)
    record_start_frame = int(round(window_start * fps))
    
    # Prepare clips for V2 placement
    to_append = []
    current_frame = record_start_frame
    window_end_frame = record_start_frame + int(window_duration * fps)
    last_paths: List[str] = []
    
    for idx, c in enumerate(clips):
        media_path = ensure_absolute_path(c['path'])
        
        # No-repeat window: avoid placing the same path consecutively
        if media_path in last_paths:
            continue
            
        # Import media
        items = media_pool.ImportMedia([media_path]) or []
        if not items:
            continue
        mpi = items[0]
        
        # Calculate placement on V2 with recordFrame
        record_frame = current_frame
        advance = int(fps * max(0.0, per_clip_seconds))
        current_frame = record_frame + max(1, advance - cross_dissolve_frames)
        
        if current_frame >= window_end_frame:
            break
            
        # Build AppendToTimeline entry with V2 placement via recordFrame
        to_append.append({
            'mediaPoolItem': mpi,
            'trackType': 'Video',
            'trackIndex': 2,  # V2 track
            'recordFrame': record_frame,  # Blueprint spec: place via recordFrame
        })
        
        # Maintain no-repeat history
        last_paths.append(media_path)
        if len(last_paths) > max(1, no_repeat_window):
            last_paths.pop(0)
    
    # Ensure V2 track exists
    if to_append:
        try:
            tracks = timeline.GetTrackCount('video') if hasattr(timeline, 'GetTrackCount') else 0
        except Exception:
            tracks = 0
        if tracks and tracks < 2:
            try:
                timeline.AddTrack('video')
            except Exception as e:
                logger.warning('add_video_track_failed', error=str(e))
        
        # Place B-roll on V2 via AppendToTimeline(recordFrame)
        ok = media_pool.AppendToTimeline(to_append)
        if not ok:
            raise RuntimeError('AppendToTimeline failed for B-roll V2 placement')
        
        logger.info('broll_assemble_complete', clips_placed=len(to_append))


def assemble_to_json(selection_json: Path) -> Path:
    return selection_json
