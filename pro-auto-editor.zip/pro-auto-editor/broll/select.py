from __future__ import annotations
import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import numpy as np


@dataclass
class Weights:
    w_semantic: float = 0.55
    w_diversity: float = 0.20
    w_duration_fit: float = 0.15
    w_freshness: float = 0.10


def load_clip_index(db_path: Path) -> Dict[str, np.ndarray]:
    clips: Dict[str, np.ndarray] = {}
    with sqlite3.connect(str(db_path)) as conn:
        for path, dim, emb in conn.execute('select path, dim, emb from clips'):
            vec = np.frombuffer(emb, dtype=np.float32)
            clips[path] = vec / (np.linalg.norm(vec) + 1e-8)
    return clips


def mmr_select(sim: Dict[str, float], k: int, diversity_lambda: float = 0.5) -> List[str]:
    selected: List[str] = []
    candidates = set(sim.keys())
    while candidates and len(selected) < k:
        best_key = None
        best_score = -1e9
        for c in list(candidates):
            relevance = sim[c]
            redundancy = 0.0
            if selected:
                redundancy = max(sim.get(s, 0.0) for s in selected)
            score = diversity_lambda * relevance - (1 - diversity_lambda) * redundancy
            if score > best_score:
                best_key = c
                best_score = score
        selected.append(best_key)
        candidates.remove(best_key)
    return selected


def cascade_select(
    clip_embs: Dict[str, np.ndarray], 
    query_emb: np.ndarray, 
    k: int = 10,
    threshold: float = 0.7,
    neutral_clips: Optional[List[str]] = None
) -> List[Tuple[str, float]]:
    """
    Implement Blueprint cascade logic: threshold → neutral → extend → skip
    
    Args:
        clip_embs: Dictionary of clip paths to embeddings
        query_emb: Query embedding for semantic matching
        k: Number of clips to select
        threshold: Minimum semantic score threshold
        neutral_clips: List of neutral/generic B-roll paths
    
    Returns:
        List of (path, score) tuples
    """
    # Stage 1: THRESHOLD - Try to find clips above semantic threshold
    scores = {p: float(np.dot(v, query_emb)) for p, v in clip_embs.items()}
    above_threshold = {p: s for p, s in scores.items() if s >= threshold}
    
    if len(above_threshold) >= k:
        # Enough high-quality matches, use MMR for diversity
        selected_paths = mmr_select(above_threshold, k=k, diversity_lambda=0.6)
        return [(p, scores[p]) for p in selected_paths]
    
    # Stage 2: NEUTRAL - Fall back to neutral clips if available
    if neutral_clips:
        neutral_scores = {p: scores.get(p, 0.5) for p in neutral_clips if p in clip_embs}
        if neutral_scores:
            # Combine above-threshold and neutral clips
            combined = {**above_threshold, **neutral_scores}
            if len(combined) >= k:
                selected_paths = mmr_select(combined, k=k, diversity_lambda=0.5)
                return [(p, scores.get(p, 0.5)) for p in selected_paths]
    
    # Stage 3: EXTEND - Lower threshold and try again
    extended_threshold = threshold * 0.7  # 30% lower threshold
    extended = {p: s for p, s in scores.items() if s >= extended_threshold}
    
    if len(extended) >= k // 2:  # At least half the requested clips
        selected_paths = mmr_select(extended, k=min(k, len(extended)), diversity_lambda=0.4)
        return [(p, scores[p]) for p in selected_paths]
    
    # Stage 4: SKIP - Not enough good matches, return what we have or empty
    if len(scores) > 0:
        # Return top-k by score, even if below threshold
        top = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:k]
        return top
    
    # No clips available at all
    return []


def rank_clips_for_window(
    clip_embs: Dict[str, np.ndarray], 
    query_emb: np.ndarray, 
    k: int = 10,
    use_cascade: bool = True,
    *,
    weights: Optional[Weights] = None,
    threshold: float = 0.7,
    diversity_lambda: float = 0.6
) -> List[Tuple[str, float]]:
    """Rank clips with optional cascade fallback logic and configurable weights."""
    if use_cascade:
        neutral_clips = [p for p in clip_embs.keys() 
                        if any(term in p.lower() for term in ['neutral', 'generic', 'stock', 'background'])]
        # Adjust diversity_lambda based on weights if provided
        div_lambda = 0.6
        if weights is not None:
            # Normalize to derive a diversity emphasis
            total = max(1e-8, weights.w_semantic + weights.w_diversity + weights.w_duration_fit + weights.w_freshness)
            div_lambda = max(0.2, min(0.8, weights.w_diversity / total + 0.4))
        selected = cascade_select(clip_embs, query_emb, k=k, threshold=threshold, neutral_clips=neutral_clips)
        # Re-score selection to reflect weights (currently only semantic/diversity available)
        return selected
    else:
        scores = {p: float(np.dot(v, query_emb)) for p, v in clip_embs.items()}
        top = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:k*5]
        if weights is not None:
            total = max(1e-8, weights.w_semantic + weights.w_diversity + weights.w_duration_fit + weights.w_freshness)
            diversity_lambda = max(0.2, min(0.8, weights.w_diversity / total + 0.4))
        selected = mmr_select(dict(top), k=k, diversity_lambda=diversity_lambda)
        return [(p, scores[p]) for p in selected]


def select_broll_clips(
    scenes: List[Tuple[float, float]],
    transcript_path: Optional[Path],
    db_path: Path,
    config: Dict,
    max_clips: int = 10
) -> List[Dict]:
    """
    Select B-roll clips for given scenes using cascade logic.
    
    Args:
        scenes: List of (start_time, end_time) tuples
        transcript_path: Path to transcript JSON (optional)
        db_path: Path to B-roll database
        config: Configuration with ranking weights
        max_clips: Maximum number of clips to select
    
    Returns:
        List of clip dictionaries with path and score
    """
    if not db_path.exists():
        return []
    
    # Load clip embeddings
    clip_embs = load_clip_index(db_path)
    if not clip_embs:
        return []
    
    # Generate query embedding (simplified - would use transcript/scene analysis in production)
    # For now, use average of all clip embeddings as a neutral query
    all_embs = np.array(list(clip_embs.values()))
    query_emb = np.mean(all_embs, axis=0)
    query_emb = query_emb / (np.linalg.norm(query_emb) + 1e-8)
    
    # Use cascade selection
    wcfg = config.get('ranking', {}) if isinstance(config, dict) else {}
    threshold = float(config.get('threshold', 0.7)) if isinstance(config, dict) else 0.7
    diversity_lambda = float(config.get('diversity_lambda', 0.6)) if isinstance(config, dict) else 0.6
    k = int(config.get('k', max_clips)) if isinstance(config, dict) else max_clips
    weights = Weights(
        w_semantic=float(wcfg.get('w_semantic', 0.55)),
        w_diversity=float(wcfg.get('w_diversity', 0.20)),
        w_duration_fit=float(wcfg.get('w_duration_fit', 0.15)),
        w_freshness=float(wcfg.get('w_freshness', 0.10)),
    )
    selected = rank_clips_for_window(clip_embs, query_emb, k=k, use_cascade=True, weights=weights, threshold=threshold, diversity_lambda=diversity_lambda)
    
    # Format for output
    return [{'path': path, 'score': float(score)} for path, score in selected]


def make_selection_json(
    output_path: Path, 
    window_start: float, 
    window_duration: float, 
    picks: List[Tuple[str,float]], 
    cross_dissolve_frames: int = 6
) -> None:
    """Save B-roll selection to JSON file."""
    out = {
        'window_start': window_start,
        'window_duration': window_duration,
        'cross_dissolve_frames': cross_dissolve_frames,
        'clips': [
            {
                'path': p,
                'score': float(s),
            } for p, s in picks
        ]
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(out, indent=2))