#!/usr/bin/env python3
"""
Pro Auto Editor - Production-Ready Application
Hardened, scalable video automation pipeline with enterprise features
"""

import asyncio
import json
import logging
import os
import sys
import time
import traceback
import uuid
import hashlib
import sqlite3
import signal
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import subprocess
import tempfile
import shutil

# Third-party imports
import aiohttp
from aiohttp import web
import aiohttp_cors
import psutil
import yaml
from aiofiles import open as aio_open
import aiofiles.os

# Local imports
from utils.file_validator import validate_video_file, get_file_info
from utils.constants import *

# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/production.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Constants imported from utils.constants
# Note: MAX_VIDEO_FILE_SIZE, ALLOWED_VIDEO_EXTENSIONS, UPLOAD_CHUNK_SIZE,
# MAX_CONCURRENT_JOBS, JOB_TIMEOUT, HEALTH_CHECK_INTERVAL, DB_PATH, 
# TEMP_DIR, UPLOAD_DIR are all imported from utils.constants

# Ensure directories exist
for dir_path in [DB_PATH.parent, TEMP_DIR, UPLOAD_DIR, Path('logs'), Path('artifacts')]:
    dir_path.mkdir(parents=True, exist_ok=True)

# Utility functions
def _parse_frame_rate(frame_rate_str: str) -> float:
    """Safely parse frame rate string from ffprobe (e.g., '30/1', '29.97/1')."""
    if not frame_rate_str or not isinstance(frame_rate_str, str):
        return 0.0
    
    frame_rate_str = frame_rate_str.strip()
    if not frame_rate_str:
        return 0.0
    
    try:
        # Handle fraction format (e.g., "30/1", "29.97/1")
        if '/' in frame_rate_str:
            numerator_str, denominator_str = frame_rate_str.split('/', 1)
            numerator = float(numerator_str.strip())
            denominator = float(denominator_str.strip())
            if denominator == 0:
                return 0.0
            return numerator / denominator
        else:
            # Handle direct number format
            return float(frame_rate_str)
    except (ValueError, ZeroDivisionError):
        logger.warning(f"Failed to parse frame rate: {frame_rate_str}")
        return 0.0

# Job States
class JobStatus(Enum):
    QUEUED = "queued"
    VALIDATING = "validating"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class Job:
    id: str
    status: JobStatus
    input_file: str
    options: Dict[str, Any]
    created_at: datetime
    updated_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress: float = 0.0
    current_stage: Optional[str] = None
    error: Optional[str] = None
    outputs: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None

class DatabaseManager:
    """Manages job persistence and tracking"""
    
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.init_database()
        
    def init_database(self):
        """Initialize database schema"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY,
                    status TEXT NOT NULL,
                    input_file TEXT NOT NULL,
                    options TEXT NOT NULL,
                    created_at TIMESTAMP NOT NULL,
                    updated_at TIMESTAMP NOT NULL,
                    started_at TIMESTAMP,
                    completed_at TIMESTAMP,
                    progress REAL DEFAULT 0.0,
                    current_stage TEXT,
                    error TEXT,
                    outputs TEXT,
                    metadata TEXT
                )
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_status ON jobs(status)
            ''')
            conn.execute('''
                CREATE INDEX IF NOT EXISTS idx_created_at ON jobs(created_at)
            ''')
            conn.commit()
            
    def create_job(self, job: Job) -> str:
        """Create a new job"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                INSERT INTO jobs VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                job.id,
                job.status.value,
                job.input_file,
                json.dumps(job.options),
                job.created_at.isoformat(),
                job.updated_at.isoformat(),
                job.started_at.isoformat() if job.started_at else None,
                job.completed_at.isoformat() if job.completed_at else None,
                job.progress,
                job.current_stage,
                job.error,
                json.dumps(job.outputs) if job.outputs else None,
                json.dumps(job.metadata) if job.metadata else None
            ))
            conn.commit()
        return job.id
        
    def update_job(self, job_id: str, **kwargs):
        """Update job fields"""
        updates = []
        values = []
        
        for key, value in kwargs.items():
            if key == 'status' and isinstance(value, JobStatus):
                value = value.value
            elif key in ['options', 'outputs', 'metadata'] and value is not None:
                value = json.dumps(value)
            elif key in ['created_at', 'updated_at', 'started_at', 'completed_at'] and value is not None:
                value = value.isoformat()
            updates.append(f"{key} = ?")
            values.append(value)
            
        updates.append("updated_at = ?")
        values.append(datetime.now().isoformat())
        values.append(job_id)
        
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(f'''
                UPDATE jobs SET {', '.join(updates)} WHERE id = ?
            ''', values)
            conn.commit()
            
    def get_job(self, job_id: str) -> Optional[Job]:
        """Get job by ID"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute('SELECT * FROM jobs WHERE id = ?', (job_id,)).fetchone()
            
        if row:
            return self._row_to_job(row)
        return None
        
    def get_active_jobs(self) -> List[Job]:
        """Get all active jobs"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute('''
                SELECT * FROM jobs 
                WHERE status IN ('queued', 'validating', 'processing')
                ORDER BY created_at ASC
            ''').fetchall()
            
        return [self._row_to_job(row) for row in rows]
        
    def _row_to_job(self, row) -> Job:
        """Convert database row to Job object"""
        return Job(
            id=row['id'],
            status=JobStatus(row['status']),
            input_file=row['input_file'],
            options=json.loads(row['options']),
            created_at=datetime.fromisoformat(row['created_at']),
            updated_at=datetime.fromisoformat(row['updated_at']),
            started_at=datetime.fromisoformat(row['started_at']) if row['started_at'] else None,
            completed_at=datetime.fromisoformat(row['completed_at']) if row['completed_at'] else None,
            progress=row['progress'],
            current_stage=row['current_stage'],
            error=row['error'],
            outputs=json.loads(row['outputs']) if row['outputs'] else None,
            metadata=json.loads(row['metadata']) if row['metadata'] else None
        )

class ValidationError(Exception):
    """Custom exception for validation errors"""
    
    def __init__(self, message: str, field: str = None, value: Any = None):
        super().__init__(message)
        self.message = message
        self.field = field
        self.value = value
        
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        result = {'error': self.message}
        if self.field:
            result['field'] = self.field
        if self.value is not None:
            result['invalid_value'] = str(self.value)
        return result
        
    def __str__(self) -> str:
        if self.field:
            return f"Validation error in field '{self.field}': {self.message}"
        return f"Validation error: {self.message}"

class FileValidator:
    """Validates input files and options"""
    
    @staticmethod
    def validate_file(file_path: Path) -> Dict[str, Any]:
        """Validate video file"""
        try:
            # Use common file validation utility
            basic_validation = validate_video_file(file_path, MAX_VIDEO_FILE_SIZE)
            file_size = basic_validation['size']
        except Exception as e:
            raise ValidationError(str(e))
            
        # Use ffprobe to validate video
        try:
            result = subprocess.run([
                'ffprobe', '-v', 'error', '-select_streams', 'v:0',
                '-count_packets', '-show_entries', 
                'stream=codec_type,codec_name,width,height,duration,bit_rate,r_frame_rate',
                '-of', 'json', str(file_path)
            ], capture_output=True, text=True, timeout=10)
            
            if result.returncode != 0:
                raise ValidationError(f"Invalid video file: {result.stderr}")
                
            probe_data = json.loads(result.stdout)
            if not probe_data.get('streams'):
                raise ValidationError("No video streams found")
                
            stream = probe_data['streams'][0]
            
            return {
                'valid': True,
                'codec': stream.get('codec_name'),
                'width': int(stream.get('width', 0)),
                'height': int(stream.get('height', 0)),
                'duration': float(stream.get('duration', 0)),
                'bitrate': int(stream.get('bit_rate', 0)),
                'fps': _parse_frame_rate(stream.get('r_frame_rate', '0/1')),
                'size': file_size,
                'path': str(file_path)
            }
            
        except subprocess.TimeoutExpired:
            raise ValidationError("File validation timeout")
        except Exception as e:
            raise ValidationError(f"Validation failed: {str(e)}")
            
    @staticmethod
    def validate_options(options: Dict[str, Any]) -> Dict[str, Any]:
        """Validate processing options"""
        validated = {}
        
        # Boolean options
        bool_opts = [
            'removeSilence', 'detectScenes', 'enableBroll', 
            'enableCaptions', 'voiceIsolation', 'dialogueLeveler',
            'exportYoutube', 'exportTiktok', 'exportInstagram', 'smartCrop'
        ]
        for opt in bool_opts:
            validated[opt] = bool(options.get(opt, True))
            
        # Numeric options with bounds
        silence_threshold = options.get('silenceThreshold', -30)
        validated['silenceThreshold'] = max(-60, min(-10, int(silence_threshold)))
        
        broll_coverage = options.get('brollCoverage', 0.3)
        validated['brollCoverage'] = max(0.1, min(0.6, float(broll_coverage)))
        
        # String options with validation
        caption_styles = ['modern', 'classic', 'minimal', 'bold']
        caption_style = options.get('captionStyle', 'modern')
        validated['captionStyle'] = caption_style if caption_style in caption_styles else 'modern'
        
        return validated

class JobProcessor:
    """Processes video jobs with error recovery"""
    
    def __init__(self, db: DatabaseManager, app=None):
        self.db = db
        self.app = app  # Reference to main app for WebSocket broadcasting
        self.executor = ProcessPoolExecutor(max_workers=MAX_CONCURRENT_JOBS)
        self.active_processes = {}
        
    async def process_job(self, job: Job):
        """Process a single job with full error handling"""
        try:
            # Update job status
            self.db.update_job(
                job.id,
                status=JobStatus.PROCESSING,
                started_at=datetime.now(),
                current_stage='initialization'
            )
            
            # Validate file
            logger.info(f"Processing job {job.id}: {job.input_file}")
            file_info = FileValidator.validate_file(Path(job.input_file))
            
            # Update with file metadata
            self.db.update_job(
                job.id,
                metadata=file_info,
                current_stage='validated',
                progress=0.05
            )
            
            # Create working directory
            work_dir = TEMP_DIR / job.id
            work_dir.mkdir(exist_ok=True)
            
            # Run pipeline stages
            stages = self._get_pipeline_stages(job.options)
            total_stages = len(stages)
            
            for i, stage in enumerate(stages, 1):
                try:
                    self.db.update_job(
                        job.id,
                        current_stage=stage['name'],
                        progress=(i - 0.5) / total_stages
                    )
                    
                    # Broadcast progress update via WebSocket if app is available
                    if self.app and hasattr(self.app, 'broadcast_to_websockets'):
                        await self.app.broadcast_to_websockets({
                            'type': 'job_update',
                            'data': {
                                'job_id': job.id,
                                'stage': stage['name'],
                                'progress': (i - 0.5) / total_stages,
                                'message': f"Processing: {stage['name']}"
                            }
                        })
                    
                    await self._run_stage(job, stage, work_dir)
                    
                    self.db.update_job(
                        job.id,
                        progress=i / total_stages
                    )
                    
                    # Broadcast stage completion if app is available
                    if self.app and hasattr(self.app, 'broadcast_to_websockets'):
                        await self.app.broadcast_to_websockets({
                            'type': 'job_update',
                            'data': {
                                'job_id': job.id,
                                'stage': stage['name'],
                                'progress': i / total_stages,
                                'message': f"Completed: {stage['name']}"
                            }
                        })
                    
                except Exception as e:
                    logger.error(f"Stage {stage['name']} failed: {e}")
                    if stage.get('required', True):
                        raise
                    # Continue if stage is optional
                    
            # Collect outputs
            outputs = self._collect_outputs(job.id)
            
            # Update job as completed
            self.db.update_job(
                job.id,
                status=JobStatus.COMPLETED,
                completed_at=datetime.now(),
                progress=1.0,
                outputs=outputs,
                current_stage='completed'
            )
            
            # Broadcast job completion if app is available
            if self.app and hasattr(self.app, 'broadcast_to_websockets'):
                await self.app.broadcast_to_websockets({
                    'type': 'job_completed',
                    'data': {
                        'job_id': job.id,
                        'outputs': outputs,
                        'message': 'Processing completed successfully'
                    }
                })
            
            # Cleanup temp files
            shutil.rmtree(work_dir, ignore_errors=True)
            
            logger.info(f"Job {job.id} completed successfully")
            
        except Exception as e:
            logger.error(f"Job {job.id} failed: {e}\n{traceback.format_exc()}")
            
            self.db.update_job(
                job.id,
                status=JobStatus.FAILED,
                error=str(e),
                completed_at=datetime.now()
            )
            
            # Broadcast job failure if app is available
            if self.app and hasattr(self.app, 'broadcast_to_websockets'):
                await self.app.broadcast_to_websockets({
                    'type': 'job_failed',
                    'data': {
                        'job_id': job.id,
                        'error': str(e),
                        'message': f'Processing failed: {str(e)}'
                    }
                })
            
    def _get_pipeline_stages(self, options: Dict[str, Any]) -> List[Dict]:
        """Get pipeline stages based on options"""
        stages = []
        
        if options.get('removeSilence'):
            stages.append({
                'name': 'silence_removal',
                'command': ['make', 'cuts'],
                'required': True
            })
            
        if options.get('detectScenes'):
            stages.append({
                'name': 'scene_detection',
                'command': ['make', 'scenes'],
                'required': False
            })
            
        if options.get('enableCaptions'):
            stages.append({
                'name': 'transcription',
                'command': ['make', 'transcript'],
                'required': False
            })
            
        if options.get('enableBroll'):
            stages.append({
                'name': 'broll_indexing',
                'command': ['make', 'index-broll'],
                'required': False
            })
            
        # Main processing
        stages.append({
            'name': 'main_pipeline',
            'command': self._build_main_command(options),
            'required': True
        })
        
        # Quality check
        stages.append({
            'name': 'quality_check',
            'command': ['make', 'qc'],
            'required': False
        })
        
        return stages
        
    def _build_main_command(self, options: Dict[str, Any]) -> List[str]:
        """Build main pipeline command"""
        cmd = ['python3', '-m', 'pipelines.shortsify', '--artifacts', './artifacts']
        
        if options.get('smartCrop'):
            cmd.append('--enable_smart_crop')
        if not options.get('enableBroll'):
            cmd.append('--disable_broll')
        if not options.get('enableCaptions'):
            cmd.append('--disable_captions')
        if not options.get('voiceIsolation') or not options.get('dialogueLeveler'):
            cmd.append('--disable_audio_polish')
            
        return cmd
        
    async def _run_stage(self, job: Job, stage: Dict, work_dir: Path):
        """Run a single pipeline stage with timeout and retry"""
        max_retries = DEFAULT_MAX_RETRIES
        retry_delay = PIPELINE_RETRY_DELAY
        
        for attempt in range(max_retries):
            try:
                # Prepare command
                cmd = stage['command'].copy()
                if 'INPUT' in ' '.join(cmd):
                    cmd = [c.replace('INPUT', job.input_file) for c in cmd]
                else:
                    cmd.append(f'INPUT={job.input_file}')
                    
                # Run command with timeout
                # Use project root directory for Makefile commands
                project_root = Path(__file__).parent
                cwd_path = project_root if cmd[0] == 'make' else work_dir
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(cwd_path)
                )
                
                # Store process for potential cancellation
                self.active_processes[job.id] = process
                
                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(),
                        timeout=JOB_TIMEOUT
                    )
                except asyncio.TimeoutError:
                    process.kill()
                    raise Exception(f"Stage {stage['name']} timeout after {JOB_TIMEOUT}s")
                finally:
                    self.active_processes.pop(job.id, None)
                    
                if process.returncode != 0:
                    error_msg = stderr.decode() if stderr else 'Unknown error'
                    if attempt < max_retries - 1:
                        logger.warning(f"Stage {stage['name']} attempt {attempt + 1} failed, retrying...")
                        await asyncio.sleep(retry_delay * (attempt + 1))
                        continue
                    raise Exception(f"Stage {stage['name']} failed: {error_msg}")
                    
                # Success
                logger.info(f"Stage {stage['name']} completed for job {job.id}")
                return
                
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                    
    def _collect_outputs(self, job_id: str) -> List[str]:
        """Collect output files"""
        outputs = []
        renders_dir = Path('artifacts/renders')
        
        if renders_dir.exists():
            # Find files created after job start
            for file in renders_dir.glob('*.mp4'):
                outputs.append(str(file))
                
        return outputs
        
    async def cancel_job(self, job_id: str):
        """Cancel a running job"""
        if job_id in self.active_processes:
            process = self.active_processes[job_id]
            process.kill()
            
        self.db.update_job(
            job_id,
            status=JobStatus.CANCELLED,
            completed_at=datetime.now()
        )

class HealthMonitor:
    """Monitors system health and resources"""
    
    def __init__(self):
        self.last_check = datetime.now()
        self.status = {'healthy': True, 'services': {}, 'resources': {}}
        
    async def check_health(self) -> Dict[str, Any]:
        """Perform health check"""
        self.status['timestamp'] = datetime.now().isoformat()
        
        # Check system resources
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        self.status['resources'] = {
            'cpu_percent': cpu_percent,
            'memory_percent': memory.percent,
            'memory_available_gb': memory.available / (1024**3),
            'disk_percent': disk.percent,
            'disk_free_gb': disk.free / (1024**3)
        }
        
        # Check critical services
        services = {
            'ffmpeg': self._check_command(['ffmpeg', '-version']),
            'resolve': self._check_resolve(),
            'database': self._check_database(),
            'disk_space': disk.free > 1024**3  # At least 1GB free
        }
        
        self.status['services'] = services
        self.status['healthy'] = all(services.values())
        
        # Warnings
        warnings = []
        if cpu_percent > 90:
            warnings.append('High CPU usage')
        if memory.percent > 90:
            warnings.append('High memory usage')
        if disk.percent > 90:
            warnings.append('Low disk space')
            
        self.status['warnings'] = warnings
        
        return self.status
        
    def _check_command(self, cmd: List[str]) -> bool:
        """Check if command is available"""
        try:
            subprocess.run(cmd, capture_output=True, timeout=5)
            return True
        except:
            return False
            
    def _check_resolve(self) -> bool:
        """Check if DaVinci Resolve is running"""
        for proc in psutil.process_iter(['name']):
            if 'Resolve' in proc.info['name']:
                return True
        return False
        
    def _check_database(self) -> bool:
        """Check database connectivity"""
        try:
            with sqlite3.connect(DB_PATH, timeout=5) as conn:
                conn.execute('SELECT 1')
            return True
        except:
            return False

class ProductionApp:
    """Main production application"""
    
    def __init__(self):
        self.app = web.Application()
        self.db = DatabaseManager(DB_PATH)
        self.processor = JobProcessor(self.db, self)  # Pass self for WebSocket broadcasting
        self.health_monitor = HealthMonitor()
        self.websockets = set()
        
        self.setup_routes()
        self.setup_cors()
        self.setup_middleware()
        self.setup_background_tasks()
        
    def setup_routes(self):
        """Setup HTTP routes"""
        # Static files
        self.app.router.add_static('/static', 'static', show_index=True)
        
        # API routes
        self.app.router.add_get('/', self.index)
        self.app.router.add_get('/health', self.health_check)
        self.app.router.add_post('/api/upload', self.upload_file)
        self.app.router.add_post('/api/process', self.create_job)
        self.app.router.add_get('/api/job/{job_id}', self.get_job_status)
        self.app.router.add_delete('/api/job/{job_id}', self.cancel_job)
        self.app.router.add_get('/api/jobs', self.list_jobs)
        self.app.router.add_get('/api/download/{job_id}/{file}', self.download_output)
        self.app.router.add_get('/ws', self.websocket_handler)
        
    def setup_cors(self):
        """Setup CORS for API access"""
        cors = aiohttp_cors.setup(self.app, defaults={
            "*": aiohttp_cors.ResourceOptions(
                allow_credentials=True,
                expose_headers="*",
                allow_headers="*",
                allow_methods="*"
            )
        })
        
        for route in list(self.app.router.routes()):
            cors.add(route)
            
    def setup_middleware(self):
        """Setup middleware for security and logging"""
        
        @web.middleware
        async def error_middleware(request, handler):
            try:
                response = await handler(request)
                return response
            except web.HTTPException as ex:
                return web.json_response({'error': ex.reason}, status=ex.status)
            except ValidationError as e:
                return web.json_response({'error': str(e)}, status=400)
            except Exception as e:
                logger.error(f"Unhandled error: {e}\n{traceback.format_exc()}")
                return web.json_response({'error': 'Internal server error'}, status=500)
                
        @web.middleware
        async def logging_middleware(request, handler):
            start_time = time.time()
            try:
                response = await handler(request)
                duration = time.time() - start_time
                logger.info(f"{request.method} {request.path} - {response.status} ({duration:.3f}s)")
                return response
            except Exception as e:
                duration = time.time() - start_time
                logger.error(f"{request.method} {request.path} - Error ({duration:.3f}s): {e}")
                raise
                
        self.app.middlewares.append(error_middleware)
        self.app.middlewares.append(logging_middleware)
        
    def setup_background_tasks(self):
        """Setup background tasks"""
        
        async def start_background_tasks(app):
            app['health_checker'] = asyncio.create_task(self.health_check_loop())
            app['job_processor'] = asyncio.create_task(self.job_processing_loop())
            
        async def cleanup_background_tasks(app):
            app['health_checker'].cancel()
            app['job_processor'].cancel()
            await app['health_checker']
            await app['job_processor']
            
        self.app.on_startup.append(start_background_tasks)
        self.app.on_cleanup.append(cleanup_background_tasks)
        
    async def health_check_loop(self):
        """Periodic health check"""
        while True:
            try:
                await asyncio.sleep(HEALTH_CHECK_INTERVAL)
                status = await self.health_monitor.check_health()
                
                # Broadcast to WebSocket clients
                await self.broadcast_to_websockets({
                    'type': 'health',
                    'data': status
                })
                
                # Log warnings
                if status['warnings']:
                    logger.warning(f"Health warnings: {status['warnings']}")
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Health check error: {e}")
                
    async def job_processing_loop(self):
        """Process queued jobs"""
        while True:
            try:
                await asyncio.sleep(5)
                
                # Get queued jobs
                jobs = self.db.get_active_jobs()
                
                for job in jobs:
                    if job.status == JobStatus.QUEUED:
                        asyncio.create_task(self.processor.process_job(job))
                        
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Job processing loop error: {e}")
                
    async def broadcast_to_websockets(self, message: Dict):
        """Broadcast message to all WebSocket clients"""
        if self.websockets:
            await asyncio.gather(
                *[ws.send_json(message) for ws in self.websockets],
                return_exceptions=True
            )
            
    # HTTP Handlers
    
    async def index(self, request):
        """Serve main UI"""
        html_path = Path('static/index.html')
        if html_path.exists():
            return web.FileResponse(html_path)
        return web.Response(text="Pro Auto Editor API", content_type='text/plain')
        
    async def health_check(self, request):
        """Health check endpoint"""
        status = await self.health_monitor.check_health()
        return web.json_response(status)
        
    async def upload_file(self, request):
        """Handle file upload with chunking"""
        reader = await request.multipart()
        
        field = await reader.next()
        if field.name != 'file':
            raise ValidationError('No file field in request')
            
        filename = field.filename
        if not filename:
            raise ValidationError('No filename provided')
            
        # Validate extension using utility
        from utils.file_validator import DEFAULT_ALLOWED_VIDEO_EXTENSIONS
        file_ext = Path(filename).suffix.lower()
        if file_ext not in ALLOWED_VIDEO_EXTENSIONS:
            raise ValidationError(f'Unsupported file type: {file_ext}. Allowed: {", ".join(sorted(ALLOWED_VIDEO_EXTENSIONS))}')
            
        # Generate unique filename
        file_id = str(uuid.uuid4())
        file_path = UPLOAD_DIR / f"{file_id}{file_ext}"
        
        # Stream to file with size limit
        size = 0
        async with aio_open(file_path, 'wb') as f:
            while True:
                chunk = await field.read_chunk(UPLOAD_CHUNK_SIZE)
                if not chunk:
                    break
                    
                size += len(chunk)
                if size > MAX_VIDEO_FILE_SIZE:
                    await aiofiles.os.remove(file_path)
                    raise ValidationError(f'File too large (max {MAX_VIDEO_FILE_SIZE / (1024**3)}GB)')
                    
                await f.write(chunk)
                
        # Validate uploaded file
        try:
            file_info = FileValidator.validate_file(file_path)
        except ValidationError as e:
            await aiofiles.os.remove(file_path)
            raise
            
        return web.json_response({
            'file_id': file_id,
            'filename': filename,
            'path': str(file_path),
            'info': file_info
        })
        
    async def create_job(self, request):
        """Create a new processing job"""
        data = await request.json()
        
        if not data.get('file_path'):
            raise ValidationError('No file path provided')
            
        # Validate options
        options = FileValidator.validate_options(data.get('options', {}))
        
        # Create job
        job = Job(
            id=str(uuid.uuid4()),
            status=JobStatus.QUEUED,
            input_file=data['file_path'],
            options=options,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
        job_id = self.db.create_job(job)
        
        # Broadcast job creation
        await self.broadcast_to_websockets({
            'type': 'job_created',
            'data': {'job_id': job_id}
        })
        
        return web.json_response({
            'job_id': job_id,
            'status': 'queued'
        })
        
    async def get_job_status(self, request):
        """Get job status"""
        job_id = request.match_info['job_id']
        job = self.db.get_job(job_id)
        
        if not job:
            raise web.HTTPNotFound(reason='Job not found')
            
        return web.json_response({
            'id': job.id,
            'status': job.status.value,
            'progress': job.progress,
            'current_stage': job.current_stage,
            'error': job.error,
            'outputs': job.outputs,
            'created_at': job.created_at.isoformat(),
            'completed_at': job.completed_at.isoformat() if job.completed_at else None
        })
        
    async def cancel_job(self, request):
        """Cancel a job"""
        job_id = request.match_info['job_id']
        await self.processor.cancel_job(job_id)
        
        return web.json_response({'status': 'cancelled'})
        
    async def list_jobs(self, request):
        """List all jobs"""
        jobs = self.db.get_active_jobs()
        
        return web.json_response({
            'jobs': [
                {
                    'id': job.id,
                    'status': job.status.value,
                    'progress': job.progress,
                    'created_at': job.created_at.isoformat()
                }
                for job in jobs
            ]
        })
        
    async def download_output(self, request):
        """Download output file"""
        job_id = request.match_info['job_id']
        filename = request.match_info['file']
        
        job = self.db.get_job(job_id)
        if not job or not job.outputs:
            raise web.HTTPNotFound(reason='Output not found')
            
        # Find matching output
        for output in job.outputs:
            if Path(output).name == filename:
                return web.FileResponse(output)
                
        raise web.HTTPNotFound(reason='File not found')
        
    async def websocket_handler(self, request):
        """WebSocket handler for real-time updates"""
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        
        self.websockets.add(ws)
        logger.info(f"WebSocket client connected. Total clients: {len(self.websockets)}")
        
        try:
            # Send initial connection confirmation
            await ws.send_json({
                'type': 'connected',
                'message': 'WebSocket connected'
            })
            
            async for msg in ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    
                    if data.get('type') == 'ping':
                        await ws.send_json({'type': 'pong'})
                        
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(f'WebSocket error: {ws.exception()}')
                    
        finally:
            self.websockets.discard(ws)
            
        return ws
        
    def run(self, host='0.0.0.0', port=8080):
        """Run the application"""
        logger.info(f"Starting Production App on http://{host}:{port}")
        
        # Setup signal handlers
        def signal_handler(sig, frame):
            logger.info("Shutting down gracefully...")
            sys.exit(0)
            
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        # Run app
        web.run_app(self.app, host=host, port=port, access_log=None)

if __name__ == '__main__':
    app = ProductionApp()
    app.run()