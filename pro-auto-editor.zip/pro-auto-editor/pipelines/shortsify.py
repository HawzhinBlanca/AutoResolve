from __future__ import annotations
import argparse
import json
import sys
import time
from datetime import datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from resolve_api.core import connect, hash8
from utils.jsonl_logger import get_logger
from resolve_api.timeline_ops import import_fcpxml, duplicate_timeline, transform_timeline_roi, append_broll_v2
from resolve_api.render_ops import set_render_settings, add_render_job_with_retry, start_and_poll
from resolve_api.captions_ops import transcribe_audio_and_create_subtitles
from resolve_api.audio_ops import set_voice_isolation, set_dialogue_leveler
from utils.config import load_project_config
from utils.error_handler import setup_error_handler


def _setup_shortsify_pipeline(args) -> tuple:
    """Initialize pipeline setup and validate required files."""
    logger = get_logger()
    artifacts_root = Path(args.artifacts)
    artifacts = artifacts_root / 'editdata'
    renders = Path(args.renders)
    renders.mkdir(parents=True, exist_ok=True)
    
    logger.info('shortsify_setup', input=args.input, artifacts=str(artifacts))

    # Load project config (best-effort)
    proj_cfg_path = Path(__file__).resolve().parents[1] / 'conf' / 'project.yaml'
    project_cfg = load_project_config(proj_cfg_path)

    cuts = artifacts / 'cuts.fcpxml'
    scenes = artifacts / 'scenes.otio'
    broll_sel = ensure_file(artifacts / 'broll_selection.json', {"selected": []})
    caption_cfg = ensure_file(artifacts / 'caption_settings.json', {"lang": "en"})
    transform_cfg = ensure_file(artifacts / 'transform_params.json', {"roi": "center"})

    if not cuts.exists() or not scenes.exists():
        raise SystemExit('cuts.fcpxml and scenes.otio are required. Run make cuts/scenes first.')

    fingerprint = hash8(
        cuts_fcpxml=cuts,
        scenes_otio=scenes,
        broll_selection_json=broll_sel,
        caption_settings_json=caption_cfg,
        transform_params_json=transform_cfg,
    )
    logger.info('shortsify_fingerprint', hash8=fingerprint)
    
    return (artifacts_root, artifacts, renders, project_cfg, cuts, scenes, 
            broll_sel, caption_cfg, transform_cfg, fingerprint)


def _create_fallback_timeline(handles, input_path) -> object:
    """Create a fallback timeline from input clip."""
    mp = handles.project.GetMediaPool()
    clip_path = str(Path(input_path).expanduser().resolve())
    items = []
    try:
        items = mp.ImportMedia([clip_path]) or []
    except Exception:
        items = []
    
    if items:
        tl_name = Path(input_path).stem
        try:
            tl = mp.CreateTimelineFromClips(tl_name, items)
        except Exception:
            tl = None
        if not tl:
            tl = handles.project.GetCurrentTimeline()
    else:
        tl = handles.project.GetCurrentTimeline()
    
    return tl


def _setup_timeline_import(args, handles, cuts, project_cfg) -> object:
    """Handle timeline import with fallback strategies."""
    logger = get_logger()
    
    # Preflight: Media Storage path check
    try:
        media_storage = handles.resolve.GetMediaStorage()
        ms_paths = media_storage.GetMountedVolumes() if hasattr(media_storage, 'GetMountedVolumes') else []
        repo_root = str(Path(__file__).resolve().parents[1].parent)
        if ms_paths and not any(str(repo_root).startswith(p) or str(p).startswith(repo_root) for p in ms_paths):
            logger.warning('media_storage_missing_repo_root', repo_root=repo_root)
    except Exception as e:
        logger.warning('media_storage_check_failed', error=str(e))
    
    logger.info('shortsify_importing_fcpxml')
    
    # Use project config for media paths if available
    media_root = None
    pcfg = {}
    proj_cfg_file = Path(__file__).resolve().parents[1] / 'conf' / 'project.yaml'
    if proj_cfg_file.exists():
        try:
            import yaml
            pcfg = yaml.safe_load(proj_cfg_file.read_text()) or {}
            media_root = pcfg.get('media_root') or project_cfg.media_root
        except Exception:
            pcfg = {}
            media_root = project_cfg.media_root
    
    # Use input media directory for relink/watch folder to avoid import failures
    input_dir = str(Path(args.input).expanduser().resolve().parent)
    
    if args.skip_import:
        tl = handles.project.GetCurrentTimeline()
        if not tl:
            raise SystemExit('No current timeline. Import cuts.fcpxml in Resolve, then rerun with --skip_import.')
        logger.info('shortsify_using_current_timeline', name=tl.GetName())
    else:
        # Pre-import input media to help Resolve relink without UI prompts
        try:
            handles.project.GetMediaPool().ImportMedia([str(Path(args.input).expanduser().resolve())])
        except Exception as e:
            logger.warning('media_import_failed', error=str(e))
        
        try:
            tl = import_fcpxml(handles.project, str(cuts), source_clips_path=media_root or input_dir)
        except Exception:
            # Robust fallback: create a fresh timeline from the input clip
            tl = _create_fallback_timeline(handles, args.input)
            if not tl:
                raise SystemExit('Failed to import FCPXML and no current timeline available; could not create a timeline from input clip')
            logger.info('shortsify_using_current_timeline', name=tl.GetName())
    
    logger.info('shortsify_timeline_imported', name=tl.GetName())
    return tl


def _prepare_timeline(handles, tl, args, caption_cfg, project_cfg):
    """Prepare timeline with base content, captions, and audio processing."""
    logger = get_logger()
    
    # Guarantee base V1 content exists
    from resolve_api.timeline_ops import ensure_base_clip, purge_overlay_tracks
    try:
        ensure_base_clip(handles.project, tl, args.input)
    except Exception as e:
        logger.warning('ensure_base_clip_failed', error=str(e))
    try:
        purge_overlay_tracks(tl)
    except Exception as e:
        logger.warning('purge_overlay_tracks_failed', error=str(e))

    # Add captions/subtitles
    logger.info('shortsify_adding_captions')
    _cap_ok = True
    if not args.disable_captions:
        _cap_ok = transcribe_audio_and_create_subtitles(handles.project, tl)
    
    # Apply caption styling
    try:
        cap_cfg = json.loads(caption_cfg.read_text())
    except Exception:
        cap_cfg = {}
    
    try:
        from resolve_api.captions_ops import apply_subtitle_style
        default_style = {
            'font': cap_cfg.get('font', 'Arial'),
            'size': cap_cfg.get('size', 60),
            'color': cap_cfg.get('color', '#FFFFFF'),
            'outline_color': cap_cfg.get('outline_color', '#000000'),
            'outline_width': cap_cfg.get('outline_width', 2),
            'box_opacity': cap_cfg.get('box_opacity', 0.75),
            'box_color': cap_cfg.get('box_color', '#000000'),
            'max_lines': cap_cfg.get('max_lines', 2),
            'align': cap_cfg.get('align', 'bottom'),
            'safe_margin_percent': cap_cfg.get('safe_margin_percent', 10.0),
            'fade_frames': cap_cfg.get('fade_frames', 6),
        }
        apply_subtitle_style(tl, default_style)
    except Exception as e:
        logger.warning('subtitle_style_application_failed', error=str(e))
    logger.info('shortsify_captions_added')
    
    # Apply audio processing
    logger.info('shortsify_audio_processing')
    if not args.disable_audio_polish:
        vi_percent = project_cfg.audio.voice_isolation_percent
        set_voice_isolation(tl, True, percent=vi_percent)
        try:
            set_dialogue_leveler(tl, bool(project_cfg.audio.dialogue_leveler))
        except Exception as e:
            logger.warning('dialogue_leveler_failed', error=str(e))
        logger.info('shortsify_voice_isolation_applied')


def _generate_broll_selection(artifacts_root, scenes, artifacts, project_cfg) -> dict:
    """Generate B-roll selection from scenes and database."""
    logger = get_logger()
    db_path = artifacts_root / 'broll.db'
    
    if not scenes.exists() or not db_path.exists():
        logger.info('shortsify_broll_skipped', reason='no_database_or_scenes')
        return {'clips': []}
    
    try:
        # Load scenes for timing
        import opentimelineio as otio
        scenes_tl = otio.adapters.read_from_file(str(scenes))
        
        # Extract scene timings
        scene_list = []
        for track in scenes_tl.tracks:
            if track.kind == otio.schema.TrackKind.Video:
                for clip in track:
                    start = float(clip.source_range.start_time.to_seconds())
                    duration = float(clip.source_range.duration.to_seconds())
                    scene_list.append((start, start + duration))
        
        # Query and select B-roll for the first 60 seconds
        if scene_list:
            from broll import select
            selected_clips = select.select_broll_clips(
                scenes=scene_list[:5],  # First 5 scenes
                transcript_path=artifacts / 'transcript.json' if (artifacts / 'transcript.json').exists() else None,
                db_path=db_path,
                config={'ranking': {'w_semantic': 0.55, 'w_diversity': 0.20, 'w_duration_fit': 0.15, 'w_freshness': 0.10},
                        'threshold': project_cfg.broll.score_threshold,
                        'k': project_cfg.broll.k,
                        'diversity_lambda': project_cfg.broll.diversity_lambda}
            )
            
            # Create selection data
            selection_data = {
                'window_start': 0.0,
                'window_duration': float(project_cfg.render.duration_s),
                'clips': selected_clips,
                'cross_dissolve_frames': int(project_cfg.broll.cross_dissolve_frames),
                'no_repeat_window': int(project_cfg.broll.no_repeat_window),
                'per_clip_seconds': float(project_cfg.broll.per_clip_seconds)
            }
            logger.info('shortsify_broll_selection_generated', clips=len(selected_clips))
            return selection_data
        else:
            logger.info('shortsify_broll_skipped', reason='no_scenes')
            return {'clips': []}
            
    except Exception as e:
        logger.error('shortsify_broll_generation_failed', error=str(e))
        return {'clips': []}


def _process_broll(args, artifacts_root, scenes, artifacts, broll_sel, project_cfg, handles, tl):
    """Process B-roll selection and append to timeline."""
    logger = get_logger()
    logger.info('shortsify_generating_broll_selection')
    
    if not args.disable_broll:
        # Generate B-roll selection
        selection_data = _generate_broll_selection(artifacts_root, scenes, artifacts, project_cfg)
        broll_sel.write_text(json.dumps(selection_data, indent=2))
        
        # Append B-roll if selection has clips
        if selection_data.get('clips'):
            logger.info('shortsify_adding_broll', count=len(selection_data['clips']))
            append_broll_v2(handles.project, tl, str(broll_sel))
            logger.info('shortsify_broll_added')
        else:
            logger.info('shortsify_broll_empty')
    else:
        # Create empty selection
        broll_sel.write_text(json.dumps({'clips': []}))
        logger.info('shortsify_broll_disabled')


def _create_timeline_variants(handles, tl, args) -> tuple:
    """Create timeline variants for different aspect ratios."""
    logger = get_logger()
    logger.info('shortsify_creating_variants')
    
    # Capture original resolution to restore if we fallback to in-place transforms
    try:
        orig_w = tl.GetSetting('timelineResolutionWidth')
        orig_h = tl.GetSetting('timelineResolutionHeight')
    except Exception:
        orig_w = None
        orig_h = None
    
    # Try 9x16 duplicate
    tl9 = None
    try:
        tl9 = duplicate_timeline(handles.project, tl, f"{tl.GetName()}_9x16")
        ok = transform_timeline_roi(tl9, "9x16")
        if not ok:
            from resolve_api.timeline_ops import apply_clip_level_roi
            if args.enable_smart_crop:
                apply_clip_level_roi(tl9, '9x16')
    except Exception:
        # Fallback: keep base timeline and apply clip-level ROI to 9x16
        from resolve_api.timeline_ops import apply_clip_level_roi
        if args.enable_smart_crop:
            apply_clip_level_roi(tl, '9x16')
        tl9 = tl
    
    # Try 1x1 duplicate
    tl1 = None
    try:
        tl1 = duplicate_timeline(handles.project, tl, f"{tl.GetName()}_1x1")
        ok = transform_timeline_roi(tl1, "1x1")
        if not ok:
            from resolve_api.timeline_ops import apply_clip_level_roi
            if args.enable_smart_crop:
                apply_clip_level_roi(tl1, '1x1')
    except Exception:
        # Fallback: clip-level ROI for 1x1
        from resolve_api.timeline_ops import apply_clip_level_roi
        if args.enable_smart_crop:
            apply_clip_level_roi(tl, '1x1')
        tl1 = tl
    
    logger.info('shortsify_variants_created', count=3)
    return tl9, tl1, orig_w, orig_h


def _calculate_render_window(tl, scenes, project_cfg, args) -> tuple:
    """Calculate render window (In/Out frames) based on scenes and config."""
    logger = get_logger()
    
    try:
        fps = float(tl.GetSetting('timelineFrameRate') or 30.0)
    except Exception:
        fps = 30.0
    
    window_start_s = None
    window_dur_s = float(project_cfg.render.duration_s if project_cfg.render.duration_s is not None else getattr(args, 'duration', 90.0) or 90.0)
    
    if getattr(args, 'start', None) is not None:
        window_start_s = float(args.start)
    elif project_cfg.render.start_s is not None:
        window_start_s = float(project_cfg.render.start_s)
    else:
        # Heuristic best-window from scenes.otio if present
        try:
            import opentimelineio as otio
            scenes_tl = otio.adapters.read_from_file(str(scenes))
            vtrack = next((t for t in scenes_tl.tracks if t.kind == otio.schema.TrackKind.Video), None)
            cut_times = []
            if vtrack:
                current = 0.0
                for item in vtrack:
                    if hasattr(item, 'source_range') and item.source_range:
                        dur = float(item.source_range.duration.to_seconds())
                        cut_times.append(current)
                        current += dur
                        cut_times.append(current)
            # pick start with most cuts inside window
            best_s = 0.0
            best_cnt = -1
            for s0 in cut_times or [0.0]:
                s1 = s0 + window_dur_s
                cnt = sum(1 for t in cut_times if s0 <= t <= s1)
                if cnt > best_cnt:
                    best_cnt = cnt
                    best_s = s0
            window_start_s = float(best_s)
        except Exception:
            window_start_s = 0.0
    
    mark_in = int(round(window_start_s * fps))
    mark_out = int(round((window_start_s + window_dur_s) * fps))
    
    return mark_in, mark_out


def _render_all_profiles(handles, tl, tl9, tl1, mark_in, mark_out, renders, fingerprint, orig_w, orig_h) -> list:
    """Render all profile variants and return job list."""
    logger = get_logger()
    
    ts = datetime.now().strftime('%Y%m%d-%H%M%S')
    project_name = handles.project.GetName()
    
    profiles = [
        ('YouTube_1080p', tl),
        ('TikTok_1080x1920', tl9),
        ('Square_1080', tl1),
    ]

    jobs = []
    for profile_name, profile_tl in profiles:
        handles.project.SetCurrentTimeline(profile_tl)
        custom_name = f"{project_name}_{profile_tl.GetName()}_{profile_name}_{ts}_{fingerprint}"
        settings = {
            'TargetDir': str(renders),
            'CustomName': custom_name,
            'RenderInOutRange': True,
            'MarkIn': mark_in,
            'MarkOut': mark_out,
        }
        # Optionally merge preset json if exists
        preset_path = Path(__file__).resolve().parents[1] / 'presets' / 'render' / f'{profile_name}.json'
        if preset_path.exists():
            try:
                preset = json.loads(preset_path.read_text())
                settings.update(preset)
            except Exception as e:
                logger.warning('preset_load_failed', preset=profile_name, error=str(e))
        
        logger.info('queue_render_profile', profile=profile_name, name=custom_name)
        set_render_settings(handles, settings)
        job_id = add_render_job_with_retry(handles)
        jobs.append((profile_name, custom_name, job_id))

    # Execute renders
    for profile_name, custom_name, job_id in jobs:
        logger.info('start_render_profile', profile=profile_name, job_id=job_id)
        start_and_poll(handles, job_id)
        logger.info('render_complete_profile', profile=profile_name, name=custom_name)
        
        # If we used in-place transforms on base timeline, restore resolution for next profile
        if (profile_name in ('TikTok_1080x1920', 'Square_1080')) and (tl9 is tl or tl1 is tl) and orig_w and orig_h:
            try:
                tl.SetSetting('timelineResolutionWidth', str(orig_w))
                tl.SetSetting('timelineResolutionHeight', str(orig_h))
            except Exception as e:
                logger.warning('timeline_resolution_restore_failed', error=str(e))
    
    return jobs


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True, help='Input video path (for naming)')
    ap.add_argument('--artifacts', default=str(Path(__file__).resolve().parents[1] / 'artifacts'))
    ap.add_argument('--renders', default=str(Path(__file__).resolve().parents[1] / 'artifacts' / 'renders'))
    ap.add_argument('--skip_import', action='store_true', help='Skip FCPXML import and use current timeline')
    ap.add_argument('--no_render', action='store_true', help='Create timelines, captions, audio polish, and variants without rendering')
    # Feature flags (Blueprint: experimental default off)
    ap.add_argument('--enable_smart_crop', action='store_true', help='Enable subject-centric smart crop for vertical/square framing')
    ap.add_argument('--disable_captions', action='store_true', help='Skip auto transcription and subtitle creation')
    ap.add_argument('--disable_broll', action='store_true', help='Skip semantic B-roll selection and append')
    ap.add_argument('--disable_audio_polish', action='store_true', help='Skip voice isolation and dialogue leveler')
    # Render window controls (Resolve-only)
    ap.add_argument('--duration', type=float, default=90.0, help='Render duration in seconds (default 90)')
    ap.add_argument('--start', type=float, default=None, help='Render window start in seconds (optional)')
    return ap.parse_args()


def ensure_file(path: Path, default_obj) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps(default_obj))
    return path


def main() -> int:
    setup_error_handler()
    logger = get_logger()
    logger.info('shortsify_start')
    
    args = parse_args()
    
    # Setup pipeline and validate files
    (artifacts_root, artifacts, renders, project_cfg, cuts, scenes, 
     broll_sel, caption_cfg, transform_cfg, fingerprint) = _setup_shortsify_pipeline(args)

    handles = connect()
    logger.info('shortsify_connected', project=handles.project.GetName())
    
    # Import and setup timeline
    tl = _setup_timeline_import(args, handles, cuts, project_cfg)
    
    # Prepare timeline with base content and captions
    _prepare_timeline(handles, tl, args, caption_cfg, project_cfg)
    
    # Process B-roll if enabled
    _process_broll(args, artifacts_root, scenes, artifacts, broll_sel, project_cfg, handles, tl)
    # Create timeline variants for different aspect ratios
    tl9, tl1, orig_w, orig_h = _create_timeline_variants(handles, tl, args)

    # Optionally stop here without rendering
    if args.no_render:
        created = [tl.GetName(), tl9.GetName() if tl9 else None, tl1.GetName() if tl1 else None]
        created = [n for n in created if n]
        # Healthcheck: write success marker
        (artifacts / 'fingerprint.json').write_text(json.dumps({'hash8': fingerprint}, indent=2))
        (artifacts_root / 'pipeline.ok').write_text(json.dumps({'ts': time.time(), 'timelines': created, 'hash8': fingerprint}))
        logger.info('shortsify_complete_no_render', hash8=fingerprint, timelines=created)
        print(json.dumps({'timelines': created, 'hash8': fingerprint, 'rendered': False}))
        return 0

    # Calculate render window (In/Out frames)
    mark_in, mark_out = _calculate_render_window(tl, scenes, project_cfg, args)

    # Render all profiles
    jobs = _render_all_profiles(handles, tl, tl9, tl1, mark_in, mark_out, renders, fingerprint, orig_w, orig_h)
    
    (artifacts / 'fingerprint.json').write_text(json.dumps({'hash8': fingerprint}, indent=2))
    
    logger.info('shortsify_complete', hash8=fingerprint, renders=[j[1] for j in jobs])
    print(json.dumps({'renders': [j[1] for j in jobs], 'hash8': fingerprint}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
