#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import List, Tuple
import opentimelineio as otio
from datetime import datetime

from utils.jsonl_logger import get_logger
from utils.config import load_project_config
from utils.error_handler import setup_error_handler
from resolve_api.core import hash8


def load_cut_times(otio_path: Path) -> List[float]:
    tl = otio.adapters.read_from_file(str(otio_path))
    track = next((t for t in tl.tracks if t.kind == otio.schema.TrackKind.Video), None)
    if not track:
        return []
    cuts = []
    for clip in track:
        sr = clip.source_range
        start_s = float(sr.start_time.to_seconds())
        dur_s = float(sr.duration.to_seconds())
        cuts.append(start_s)
        cuts.append(start_s + dur_s)
    return sorted(set(cuts))


def best_window(cut_times: List[float], duration_s: float) -> Tuple[float, float]:
    if not cut_times:
        return 0.0, duration_s
    best_start = 0.0
    best_count = -1
    for s in cut_times:
        e = s + duration_s
        count = sum(1 for t in cut_times if s <= t <= e)
        if count > best_count:
            best_count = count
            best_start = s
    return best_start, duration_s


def run_ffmpeg_ratio(input_path: Path, output_path: Path, start_s: float, dur_s: float, ratio: str, srt: Path | None) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if ratio == '9x16':
        vf_parts = ["crop=ih*9/16:ih:(iw-ih*9/16)/2:0", "scale=1080:1920"]
    elif ratio == '1x1':
        vf_parts = ["crop=ih:ih:(iw-ih)/2:0", "scale=1080:1080"]
    else:
        raise ValueError('unsupported ratio')
    if srt is not None and srt.exists():
        safe_srt = srt
        if ' ' in str(srt):
            safe_srt = srt.parent / 'subs.srt'
            shutil.copyfile(srt, safe_srt)
        # Use single quotes inside filter args so commas are parsed correctly by libass
        vf_parts.append(f"subtitles={safe_srt.as_posix()}:force_style='Fontsize=28,Outline=2,Shadow=1'")
    vf = ",".join(vf_parts)
    cmd = [
        'ffmpeg','-y',
        '-ss', f'{start_s:.3f}', '-t', f'{dur_s:.3f}',
        '-i', str(input_path),
        '-vf', vf,
        '-c:v','libx264','-preset','veryfast','-crf','20',
        '-c:a','aac','-b:a','160k',
        str(output_path)
    ]
    subprocess.run(cmd, check=True)


def main() -> int:
    setup_error_handler()
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--artifacts', default=str(Path(__file__).resolve().parents[1] / 'artifacts'))
    ap.add_argument('--renders', default=str(Path(__file__).resolve().parents[1] / 'artifacts' / 'renders'))
    ap.add_argument('--duration', type=float, default=60.0)
    ap.add_argument('--start', type=float, default=None)
    ap.add_argument('--burn_subs', action='store_true')
    args = ap.parse_args()

    logger = get_logger()
    logger.info('shortsify_multi_start')
    # Optional project config for duration/start defaults
    proj_cfg_path = Path(__file__).resolve().parents[1] / 'conf' / 'project.yaml'
    project_cfg = load_project_config(proj_cfg_path)
    artifacts_root = Path(args.artifacts)
    editdata = artifacts_root / 'editdata'
    scenes = editdata / 'scenes.otio'
    if not scenes.exists():
        raise SystemExit('scenes.otio missing; run make scenes first.')

    cut_times = load_cut_times(scenes)
    if getattr(args, 'start', None) is not None:
        start_s = float(args.start)
        dur_s = float(args.duration)
    else:
        default_dur = float(project_cfg.render.duration_s or args.duration)
        start_s, dur_s = best_window(cut_times, default_dur)

    input_path = Path(args.input).expanduser().resolve()
    base = input_path.stem

    # Ensure required files for fingerprint exist
    caption_cfg = editdata / 'caption_settings.json'
    transform_cfg = editdata / 'transform_params.json'
    sel_json = editdata / 'broll_selection.json'
    if not caption_cfg.exists():
        caption_cfg.write_text(json.dumps({"lang": "en"}))
    if not transform_cfg.exists():
        transform_cfg.write_text(json.dumps({"roi": "center"}))
    if not sel_json.exists():
        sel_json.write_text(json.dumps({'window_start': start_s, 'window_duration': args.duration, 'clips': []}))

    # Compute hash8 fingerprint per Blueprint
    fp = hash8(
        cuts_fcpxml=editdata / 'cuts.fcpxml',
        scenes_otio=scenes,
        broll_selection_json=sel_json,
        caption_settings_json=caption_cfg,
        transform_params_json=transform_cfg,
    )
    ts = datetime.now().strftime('%Y%m%d-%H%M%S')

    srt_path = None
    if args.burn_subs:
        transcript = editdata / 'transcript.json'
        if not transcript.exists():
            try:
                subprocess.run([
                    'python3', str(Path(__file__).resolve().parents[1] / 'tools' / 'transcribe_fastwhisper.py'),
                    '--input', str(input_path), '--output', str(transcript)
                ], check=True)
            except Exception as e:
                logger = get_logger()
                logger.warning('transcription_failed', input=str(input_path), error=str(e))
        if transcript.exists():
            srt_path = editdata / 'transcript.srt'
            subprocess.run([
                'python3', str(Path(__file__).resolve().parents[1] / 'tools' / 'transcript_to_srt.py'),
                '--input', str(transcript), '--output', str(srt_path)
            ], check=True)

    out9 = Path(args.renders) / f"{base}_9x16_{int(args.duration)}s_{ts}_{fp}.mp4"
    out1 = Path(args.renders) / f"{base}_1x1_{int(args.duration)}s_{ts}_{fp}.mp4"

    with ThreadPoolExecutor(max_workers=2) as ex:
        f1 = ex.submit(run_ffmpeg_ratio, input_path, out9, start_s, dur_s, '9x16', srt_path)
        f2 = ex.submit(run_ffmpeg_ratio, input_path, out1, start_s, dur_s, '1x1', srt_path)
        f1.result(); f2.result()

    logger.info('shortsify_multi_complete', outputs=[str(out9), str(out1)], start=start_s, duration=dur_s, subs=bool(srt_path), hash8=fp)
    print(json.dumps({'outputs': [str(out9), str(out1)], 'start': start_s, 'duration': dur_s, 'subs': bool(srt_path), 'hash8': fp}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
