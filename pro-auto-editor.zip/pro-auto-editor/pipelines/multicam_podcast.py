from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any
import yaml

from resolve_api import core
from utils.error_handler import setup_error_handler
from utils.jsonl_logger import get_logger
from resolve_api import timeline_ops
from resolve_api import render_ops
from resolve_api.audio_ops import set_voice_isolation, set_dialogue_leveler
from resolve_api.captions_ops import transcribe_audio_and_create_subtitles


def create_multicam_from_clips(handles: core.ResolveHandles, input_dir: Path) -> Optional[object]:
    """Create multicam clip from camera files in input directory with enhanced sync detection."""
    project = handles.project
    media_pool = project.GetMediaPool()
    root_folder = media_pool.GetRootFolder()
    logger = get_logger()
    
    # Import all camera files (support more formats)
    camera_files = (sorted(input_dir.glob('*.mp4')) + 
                   sorted(input_dir.glob('*.mov')) + 
                   sorted(input_dir.glob('*.mxf')) + 
                   sorted(input_dir.glob('*.avi')))
    if not camera_files:
        logger.error('multicam_no_files', input_dir=str(input_dir))
        print(f"ERROR: No camera files found in {input_dir}")
        return None
    
    logger.info('multicam_files_found', count=len(camera_files), files=[f.name for f in camera_files])
    print(f"Found {len(camera_files)} camera files")
    
    # Import to media pool
    clips = []
    for cam_file in camera_files:
        abs_path = cam_file.resolve()
        imported = media_pool.ImportMedia([str(abs_path)])
        if imported:
            clips.extend(imported)
            print(f"Imported: {cam_file.name}")
    
    if len(clips) < 2:
        logger = get_logger()
        logger.error('multicam_insufficient_clips', count=len(clips))
        print("ERROR: Need at least 2 clips for multicam")
        return None
    
    # Create multicam clip with enhanced sync options
    sync_settings = {
        'SyncMode': 'Audio',  # Primary sync method
        'AutoSequence': True,  # Auto-sequence angles
        'FrameSync': False,    # Disable frame sync initially
        'TimecodeSync': False  # Disable timecode sync initially
    }
    
    # Try different sync methods if audio fails
    sync_methods = ['Audio', 'Timecode', 'FirstClipAngle']
    multicam_clip = None
    
    for sync_mode in sync_methods:
        try:
            sync_settings['SyncMode'] = sync_mode
            logger.info('multicam_sync_attempt', mode=sync_mode)
            multicam_clip = media_pool.CreateMulticamClip(clips, sync_settings)
            if multicam_clip:
                logger.info('multicam_sync_success', mode=sync_mode)
                print(f"Multicam sync successful using: {sync_mode}")
                break
        except Exception as e:
            logger.warning('multicam_sync_failed', mode=sync_mode, error=str(e))
            continue
    
    if not multicam_clip:
        logger.error('multicam_creation_failed', clips_count=len(clips))
        print("ERROR: Failed to create multicam clip with any sync method")
        return None
    
    logger.info('multicam_created', angles=len(clips), name=multicam_clip.GetName() if hasattr(multicam_clip, 'GetName') else 'unknown')
    print(f"Created multicam clip with {len(clips)} angles")
    return multicam_clip


def create_timeline_with_multicam(handles: core.ResolveHandles, multicam_clip: object, timeline_name: str) -> Optional[object]:
    """Create timeline and add multicam clip."""
    project = handles.project
    media_pool = project.GetMediaPool()
    
    # Create timeline
    timeline = media_pool.CreateEmptyTimeline(timeline_name)
    if not timeline:
        logger = get_logger()
        logger.error('timeline_creation_failed', name=timeline_name)
        print(f"ERROR: Failed to create timeline {timeline_name}")
        return None
    
    # Add multicam to timeline
    if not media_pool.AppendToTimeline([multicam_clip]):
        logger = get_logger()
        logger.error('multicam_append_failed', timeline=timeline_name)
        print("ERROR: Failed to add multicam to timeline")
        return None
    
    print(f"Created timeline: {timeline_name}")
    return timeline


def apply_automated_smartswitch(timeline: object) -> bool:
    """Attempt automated SmartSwitch using API if available, fallback to manual instructions."""
    logger = get_logger()
    
    # Try automated SmartSwitch via API
    try:
        # Get multicam clips in timeline
        track_count = timeline.GetTrackCount('video')
        multicam_items = []
        
        for track_idx in range(1, track_count + 1):
            items = timeline.GetItemListInTrack('video', track_idx)
            for item in items:
                # Check if item is multicam
                if hasattr(item, 'GetMediaPoolItem'):
                    media_item = item.GetMediaPoolItem()
                    if media_item and hasattr(media_item, 'GetClipProperty'):
                        clip_type = media_item.GetClipProperty('Type')
                        if clip_type and 'multicam' in clip_type.lower():
                            multicam_items.append(item)
        
        if not multicam_items:
            logger.warning('smartswitch_no_multicam_items')
            print("No multicam items found in timeline")
            return False
        
        # Apply SmartSwitch to each multicam item
        success_count = 0
        for item in multicam_items:
            try:
                # Try different SmartSwitch API methods
                if hasattr(item, 'ApplySmartSwitch'):
                    # Method 1: Direct SmartSwitch API
                    result = item.ApplySmartSwitch({
                        'Mode': 'Auto',
                        'Sensitivity': 'Medium',
                        'MinDuration': 2.0,  # Minimum 2 seconds per cut
                        'UseAudio': True,
                        'UseMotion': True
                    })
                    if result:
                        success_count += 1
                        logger.info('smartswitch_applied', item=item.GetName() if hasattr(item, 'GetName') else 'unknown')
                
                elif hasattr(item, 'SetProperty'):
                    # Method 2: Property-based approach
                    item.SetProperty('SmartSwitchMode', 'Auto')
                    item.SetProperty('SmartSwitchSensitivity', 50)  # 0-100 scale
                    item.SetProperty('SmartSwitchMinDuration', 60)  # 60 frames @ 30fps = 2 seconds
                    success_count += 1
                    logger.info('smartswitch_properties_set', item=item.GetName() if hasattr(item, 'GetName') else 'unknown')
                
                elif hasattr(timeline, 'ApplyMulticamSmartSwitch'):
                    # Method 3: Timeline-level SmartSwitch
                    result = timeline.ApplyMulticamSmartSwitch(item, {
                        'algorithm': 'ai_enhanced',
                        'min_cut_duration': 2.0,
                        'use_audio_analysis': True,
                        'use_motion_analysis': True,
                        'speaker_detection': True
                    })
                    if result:
                        success_count += 1
                        logger.info('timeline_smartswitch_applied')
                        
            except Exception as e:
                logger.warning('smartswitch_item_failed', error=str(e))
                continue
        
        if success_count > 0:
            logger.info('smartswitch_automated_success', count=success_count, total=len(multicam_items))
            print(f"Automated SmartSwitch applied to {success_count}/{len(multicam_items)} multicam clips")
            return True
        else:
            logger.warning('smartswitch_automation_failed')
            print("Automated SmartSwitch failed, showing manual instructions...")
            return False
            
    except Exception as e:
        logger.warning('smartswitch_automation_error', error=str(e))
        print(f"SmartSwitch automation error: {e}")
        return False


def apply_smartswitch_reminder(timeline: object) -> None:
    """Print instructions for manual SmartSwitch step."""
    print("\n" + "=" * 60)
    print("MANUAL STEP REQUIRED: AI Multicam SmartSwitch")
    print("=" * 60)
    print("1. Select the multicam clip in the timeline")
    print("2. Right-click and choose 'Multicam SmartSwitch'")
    print("3. Configure AI settings and apply")
    print("4. Save the project")
    print("5. Re-run this command with --continue to proceed")
    print("=" * 60 + "\n")


def save_state(artifacts_dir: Path, state: Dict[str, Any]) -> None:
    """Save pipeline state for continuation."""
    state_file = artifacts_dir / 'multicam_state.json'
    state_file.parent.mkdir(parents=True, exist_ok=True)
    with open(state_file, 'w') as f:
        json.dump(state, f, indent=2)
    print(f"State saved to: {state_file}")


def load_state(artifacts_dir: Path) -> Optional[Dict[str, Any]]:
    """Load saved pipeline state."""
    state_file = artifacts_dir / 'multicam_state.json'
    if not state_file.exists():
        logger = get_logger()
        logger.warning('multicam_state_not_found', state_file=str(state_file))
        return None
    with open(state_file) as f:
        return json.load(f)


def continue_after_smartswitch(handles: core.ResolveHandles, artifacts_dir: Path, timeline_name: str = None) -> int:
    """Continue pipeline after SmartSwitch (manual or automated)."""
    logger = get_logger()
    
    if timeline_name is None:
        # Load from saved state (manual continuation)
        state = load_state(artifacts_dir)
        if not state:
            logger.error('multicam_no_state')
            print("ERROR: No saved state found. Run initial multicam creation first.")
            return 1
        timeline_name = state.get('timeline_name')
    
    logger.info('multicam_continuing', timeline=timeline_name)
    project = handles.project
    
    # Find the timeline
    timeline_count = project.GetTimelineCount()
    timeline = None
    for i in range(1, timeline_count + 1):
        tl = project.GetTimelineByIndex(i)
        if tl and tl.GetName() == timeline_name:
            timeline = tl
            break
    
    if not timeline:
        print(f"ERROR: Timeline '{timeline_name}' not found")
        return 1
    
    project.SetCurrentTimeline(timeline)
    print(f"Continuing with timeline: {timeline_name}")
    
    # Captions → B-roll V2 (optional) → audio processing → variants → render
    print("\nAdding captions...")
    try:
        transcribe_audio_and_create_subtitles(project, timeline)
        print("Captions added")
    except Exception as e:
        print(f"Captioning note: {e}")

    print("\nApplying audio processing...")
    try:
        set_voice_isolation(timeline, True)
        set_dialogue_leveler(timeline, True)
    except Exception as e:
        print(f"Audio processing note: {e}")
    # Also run per-item enhancements when supported
    apply_audio_processing(timeline)
    
    # Create format variations
    print("\nCreating format variations...")
    formats = ['YouTube_1080p', 'TikTok_1080x1920', 'Square_1080']
    variants = []
    for fmt in formats:
        new_name = f"{timeline_name}_{fmt}"
        v = timeline_ops.duplicate_timeline(project, timeline, new_name)
        try:
            if fmt == 'TikTok_1080x1920':
                timeline_ops.transform_timeline_roi(v, '9x16')
            elif fmt == 'Square_1080':
                timeline_ops.transform_timeline_roi(v, '1x1')
        except Exception as e:
            print(f"Transform failed for {fmt}: {e}")
        variants.append(v)
        print(f"Created: {fmt}")
    
    # Set up render queue
    print("\nSetting up render queue...")
    render_count = 0
    for tl in variants:
        project.SetCurrentTimeline(tl)
        settings = {'TargetDir': str(artifacts_dir / 'renders'), 'CustomName': tl.GetName()}
        try:
            render_ops.set_render_settings(handles, settings)
            job_id = render_ops.add_render_job_with_retry(handles)
        except Exception as e:
            print(f"Render queue error: {e}")
            continue
        if job_id:
            render_count += 1
            print(f"Added to render queue: {tl.GetName()}")
    
    print(f"\n{render_count} jobs added to render queue")
    print("Run 'make render' to start rendering")
    
    # Clean up state
    state_file = artifacts_dir / 'multicam_state.json'
    if state_file.exists():
        state_file.unlink()
    
    return 0


def apply_audio_processing(timeline: object) -> None:
    """Apply Voice Isolation, Dialogue Leveler, and ducking."""
    # Get audio tracks
    track_count = timeline.GetTrackCount('audio')
    if track_count == 0:
        return
    
    # Process first 2 audio tracks (typically dialogue tracks)
    for track_idx in range(1, min(track_count + 1, 3)):
        items = timeline.GetItemListInTrack('audio', track_idx)
        for item in items:
            try:
                # Apply Voice Isolation (percentage-based)
                if hasattr(item, 'SetProperty'):
                    item.SetProperty('AudioVoiceIsolation', 80)  # 80% isolation
                    item.SetProperty('AudioDialogueLeveler', True)
                    
                # Apply Fairlight effects if available
                if hasattr(item, 'AddFairlightFX'):
                    # Voice Isolation effect
                    voice_fx = item.AddFairlightFX('Voice Isolation')
                    if voice_fx:
                        voice_fx.SetParam('Amount', 0.8)  # 80% isolation
                    
                    # Dialogue Leveler effect
                    leveler_fx = item.AddFairlightFX('Dialogue Leveler')
                    if leveler_fx:
                        leveler_fx.SetParam('Enable', True)
                        leveler_fx.SetParam('Amount', 0.7)  # 70% leveling
                        
                # Alternative API approach for newer Resolve versions
                elif hasattr(item, 'EnableVoiceIsolation'):
                    item.EnableVoiceIsolation(True, 80)  # Enable with 80% strength
                    item.EnableDialogueLeveler(True)
                    
            except Exception as e:
                # Log but continue processing other items
                print(f"Audio processing note for item {track_idx}: {e}")
    
    # Apply ducking to music/SFX tracks (track 3+)
    if track_count >= 3:
        for track_idx in range(3, min(track_count + 1, 5)):
            try:
                # Get track object for sidechain setup
                track = timeline.GetTrack('audio', track_idx)
                if track and hasattr(track, 'SetSidechain'):
                    # Duck against track 1 (main dialogue)
                    track.SetSidechain(source_track=1, ratio=4, threshold=-20, attack=10, release=100)
                    
                # Apply compressor for ducking
                items = timeline.GetItemListInTrack('audio', track_idx)
                for item in items:
                    if hasattr(item, 'AddFairlightFX'):
                        comp_fx = item.AddFairlightFX('Compressor')
                        if comp_fx:
                            comp_fx.SetParam('Ratio', 4.0)
                            comp_fx.SetParam('Threshold', -20)
                            comp_fx.SetParam('SidechainSource', 1)  # Track 1 as key
            except Exception as e:
                print(f"Ducking setup note for track {track_idx}: {e}")
    
    print("Audio processing applied (Voice Isolation, Dialogue Leveler, Ducking)")


def main() -> int:
    setup_error_handler()
    ap = argparse.ArgumentParser()
    ap.add_argument('--input-dir', required=True, type=Path)
    ap.add_argument('--artifacts', type=Path, 
                    default=Path(__file__).resolve().parents[1] / 'artifacts')
    ap.add_argument('--continue', dest='continue_pipeline', action='store_true',
                    help='Continue after manual SmartSwitch')
    args = ap.parse_args()
    
    # Ensure absolute paths
    input_dir = args.input_dir.resolve()
    artifacts_dir = args.artifacts.resolve()
    
    if not input_dir.exists():
        print(f"ERROR: Input directory not found: {input_dir}")
        return 1
    
    # Connect to Resolve
    try:
        handles = core.connect()
    except Exception as e:
        print(f"ERROR: Failed to connect to Resolve: {e}")
        return 1
    
    if args.continue_pipeline:
        # Continue after SmartSwitch
        return continue_after_smartswitch(handles, artifacts_dir)
    else:
        # Initial multicam creation
        multicam_clip = create_multicam_from_clips(handles, input_dir)
        if not multicam_clip:
            return 1
        
        timeline_name = f"multicam_{input_dir.name}"
        timeline = create_timeline_with_multicam(handles, multicam_clip, timeline_name)
        if not timeline:
            return 1
        
        # Try automated SmartSwitch first
        logger = get_logger()
        logger.info('multicam_attempting_smartswitch', timeline=timeline_name)
        
        smartswitch_success = apply_automated_smartswitch(timeline)
        
        if smartswitch_success:
            # SmartSwitch worked, continue with full pipeline
            logger.info('multicam_smartswitch_automated', timeline=timeline_name)
            print("\nSmartSwitch applied automatically, continuing with full pipeline...")
            
            # Continue directly to post-processing
            return continue_after_smartswitch(handles, artifacts_dir, timeline_name=timeline_name)
        else:
            # Save state for manual continuation
            state = {
                'timeline_name': timeline_name,
                'input_dir': str(input_dir),
                'artifacts_dir': str(artifacts_dir)
            }
            save_state(artifacts_dir, state)
            
            # Show SmartSwitch instructions
            apply_smartswitch_reminder(timeline)
            logger.info('multicam_manual_smartswitch_required', timeline=timeline_name)
            
            return 0


if __name__ == '__main__':
    raise SystemExit(main())
