#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
import subprocess
from pathlib import Path
import opentimelineio as otio


def pick_segments(otio_path: Path, max_duration_s: float = 60.0):
    tl = otio.adapters.read_from_file(str(otio_path))
    # Assume first video track
    track = next((t for t in tl.tracks if t.kind == otio.schema.TrackKind.Video), None)
    if not track:
        return []
    segments = []
    total = 0.0
    for clip in track:
        sr = clip.source_range
        start_s = float(sr.start_time.to_seconds())
        dur_s = float(sr.duration.to_seconds())
        if dur_s <= 0:
            continue
        if total + dur_s > max_duration_s:
            dur_s = max(0.0, max_duration_s - total)
        if dur_s > 0:
            segments.append((start_s, dur_s))
            total += dur_s
        if total >= max_duration_s:
            break
    return segments


def run_ffmpeg_vertical(input_path: Path, output_path: Path, start_s: float, dur_s: float) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    vf = "crop=ih*9/16:ih:(iw-ih*9/16)/2:0,scale=1080:1920"
    cmd = [
        'ffmpeg','-y',
        '-ss', f'{start_s:.3f}', '-t', f'{dur_s:.3f}',
        '-i', str(input_path),
        '-vf', vf,
        '-c:v','libx264','-preset','veryfast','-crf','20',
        '-c:a','aac','-b:a','160k',
        str(output_path)
    ]
    subprocess.run(cmd, check=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--artifacts', default=str(Path(__file__).resolve().parents[1] / 'artifacts'))
    ap.add_argument('--renders', default=str(Path(__file__).resolve().parents[1] / 'artifacts' / 'renders'))
    ap.add_argument('--duration', type=float, default=60.0)
    args = ap.parse_args()

    artifacts_root = Path(args.artifacts)
    editdata = artifacts_root / 'editdata'
    scenes = editdata / 'scenes.otio'
    if not scenes.exists():
        raise SystemExit('scenes.otio missing; run make scenes first.')

    segments = pick_segments(scenes)
    if not segments:
        raise SystemExit('no segments found in scenes.otio')

    # Accumulate consecutive scenes up to target duration
    target = float(getattr(args, 'duration', 60.0))
    start_s = segments[0][0]
    dur_s = 0.0
    for seg_start, seg_dur in segments:
        if dur_s + seg_dur > target:
            seg_dur = max(0.0, target - dur_s)
        dur_s += seg_dur
        if dur_s >= target:
            break
    input_path = Path(args.input).expanduser().resolve()
    base = input_path.stem
    out = Path(args.renders) / f"{base}_9x16_short.mp4"
    run_ffmpeg_vertical(input_path, out, start_s, dur_s)
    print(json.dumps({'output': str(out), 'start': start_s, 'duration': dur_s}))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
