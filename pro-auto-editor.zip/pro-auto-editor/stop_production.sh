#!/bin/bash

# Stop production services

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Stopping production services...${NC}"

# Stop production app
if [ -f ".production.pid" ]; then
    PID=$(cat .production.pid)
    if kill -0 $PID 2>/dev/null; then
        kill -TERM $PID
        echo -e "${GREEN}✓ Stopped production app (PID: $PID)${NC}"
    fi
    rm -f .production.pid
fi

# Stop any remaining processes
pkill -f "production_app.py" 2>/dev/null || true
pkill -f "backend_service.py" 2>/dev/null || true
pkill -f "web_gui.py" 2>/dev/null || true

echo -e "${GREEN}✓ All services stopped${NC}"