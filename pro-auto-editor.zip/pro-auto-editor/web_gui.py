#!/usr/bin/env python3
"""
Pro Auto Editor Web GUI
Browser-based interface for the video automation pipeline
"""

from aiohttp import web
import aiohttp_cors
import json
import os
import subprocess
import asyncio
from pathlib import Path
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# HTML Template
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pro Auto Editor - Professional Video Automation</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }
        
        .content {
            padding: 30px;
        }
        
        .section {
            margin-bottom: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        
        .section h2 {
            color: #333;
            margin-bottom: 15px;
            font-size: 1.4em;
        }
        
        .file-input {
            position: relative;
            display: inline-block;
            cursor: pointer;
            width: 100%;
        }
        
        .file-input input[type=file] {
            position: absolute;
            left: -9999px;
        }
        
        .file-input label {
            display: block;
            padding: 20px;
            background: white;
            border: 2px dashed #667eea;
            border-radius: 10px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .file-input label:hover {
            background: #f0f0ff;
            border-color: #764ba2;
        }
        
        .file-input.has-file label {
            background: #e8f4f8;
            border-color: #4CAF50;
            border-style: solid;
        }
        
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 2px solid #e0e0e0;
        }
        
        .tab {
            padding: 10px 20px;
            cursor: pointer;
            background: none;
            border: none;
            font-size: 1em;
            color: #666;
            transition: all 0.3s;
        }
        
        .tab.active {
            color: #667eea;
            border-bottom: 3px solid #667eea;
            margin-bottom: -2px;
        }
        
        .tab-content {
            display: none;
            padding: 20px 0;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .option-group {
            margin-bottom: 15px;
        }
        
        .option-group label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 5px;
        }
        
        .option-group input[type="checkbox"] {
            width: 20px;
            height: 20px;
        }
        
        .slider-group {
            margin: 15px 0;
        }
        
        .slider-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        
        .slider {
            width: 100%;
            -webkit-appearance: none;
            height: 6px;
            border-radius: 3px;
            background: #ddd;
            outline: none;
        }
        
        .slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: #667eea;
            cursor: pointer;
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin: 30px 0;
        }
        
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            font-size: 1em;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 600;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }
        
        .btn-secondary:hover {
            background: #f0f0ff;
        }
        
        .progress-section {
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
            margin: 20px 0;
        }
        
        .progress-bar {
            width: 100%;
            height: 30px;
            background: #e0e0e0;
            border-radius: 15px;
            overflow: hidden;
            margin: 15px 0;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            transition: width 0.5s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .status {
            text-align: center;
            color: #666;
            margin: 10px 0;
        }
        
        .log-area {
            background: #1e1e1e;
            color: #00ff00;
            padding: 15px;
            border-radius: 10px;
            height: 200px;
            overflow-y: auto;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
        }
        
        .log-entry {
            margin: 5px 0;
        }
        
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        
        .processing {
            animation: pulse 2s infinite;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎬 Pro Auto Editor</h1>
            <p>Professional Video Automation for DaVinci Resolve</p>
        </div>
        
        <div class="content">
            <!-- File Input Section -->
            <div class="section">
                <h2>Select Video</h2>
                <div class="file-input" id="fileInputContainer">
                    <input type="file" id="videoFile" accept="video/*">
                    <label for="videoFile">
                        <div id="fileLabel">
                            📁 Click to select or drag and drop your video here
                        </div>
                    </label>
                </div>
            </div>
            
            <!-- Options Section -->
            <div class="section">
                <h2>Pipeline Options</h2>
                <div class="tabs">
                    <button class="tab active" onclick="showTab('editing')">Editing</button>
                    <button class="tab" onclick="showTab('broll')">B-Roll</button>
                    <button class="tab" onclick="showTab('captions')">Captions</button>
                    <button class="tab" onclick="showTab('audio')">Audio</button>
                    <button class="tab" onclick="showTab('export')">Export</button>
                </div>
                
                <div id="editing" class="tab-content active">
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="removeSilence" checked>
                            <span>Remove Silence</span>
                        </label>
                    </div>
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="detectScenes" checked>
                            <span>Detect Scenes</span>
                        </label>
                    </div>
                    <div class="slider-group">
                        <label>Silence Threshold: <span id="silenceValue">-30</span> dB</label>
                        <input type="range" class="slider" id="silenceThreshold" min="-60" max="-10" value="-30">
                    </div>
                </div>
                
                <div id="broll" class="tab-content">
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="enableBroll" checked>
                            <span>Add B-Roll Footage</span>
                        </label>
                    </div>
                    <div class="slider-group">
                        <label>Coverage Ratio: <span id="coverageValue">30</span>%</label>
                        <input type="range" class="slider" id="brollCoverage" min="10" max="60" value="30">
                    </div>
                </div>
                
                <div id="captions" class="tab-content">
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="enableCaptions" checked>
                            <span>Generate Captions</span>
                        </label>
                    </div>
                    <div class="option-group">
                        <label>Style:</label>
                        <select id="captionStyle">
                            <option value="modern">Modern</option>
                            <option value="classic">Classic</option>
                            <option value="minimal">Minimal</option>
                            <option value="bold">Bold</option>
                        </select>
                    </div>
                </div>
                
                <div id="audio" class="tab-content">
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="voiceIsolation" checked>
                            <span>Voice Isolation</span>
                        </label>
                    </div>
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="dialogueLeveler" checked>
                            <span>Dialogue Leveler</span>
                        </label>
                    </div>
                </div>
                
                <div id="export" class="tab-content">
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="exportYoutube" checked>
                            <span>YouTube (16:9)</span>
                        </label>
                    </div>
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="exportTiktok" checked>
                            <span>TikTok (9:16)</span>
                        </label>
                    </div>
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="exportInstagram" checked>
                            <span>Instagram (1:1)</span>
                        </label>
                    </div>
                    <div class="option-group">
                        <label>
                            <input type="checkbox" id="smartCrop" checked>
                            <span>Smart AI Crop</span>
                        </label>
                    </div>
                </div>
            </div>
            
            <!-- Action Buttons -->
            <div class="button-group">
                <button class="btn btn-primary" onclick="processVideo()">
                    ▶️ Process Video
                </button>
                <button class="btn btn-secondary" onclick="validateConfig()">
                    ✓ Validate
                </button>
                <button class="btn btn-secondary" onclick="openRenders()">
                    📁 Open Renders
                </button>
            </div>
            
            <!-- Progress Section -->
            <div class="progress-section">
                <h2>Progress</h2>
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill" style="width: 0%">0%</div>
                </div>
                <div class="status" id="status">Ready</div>
            </div>
            
            <!-- Log Section -->
            <div class="section">
                <h2>Output Log</h2>
                <div class="log-area" id="logArea">
                    <div class="log-entry">System ready. Select a video to begin.</div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let selectedFile = null;
        let ws = null;
        
        // File handling
        document.getElementById('videoFile').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                selectedFile = file;
                document.getElementById('fileLabel').textContent = `✅ ${file.name}`;
                document.getElementById('fileInputContainer').classList.add('has-file');
                addLog(`Selected: ${file.name}`);
            }
        });
        
        // Drag and drop
        const fileInput = document.getElementById('fileInputContainer');
        fileInput.addEventListener('dragover', (e) => {
            e.preventDefault();
            fileInput.style.background = '#f0f0ff';
        });
        
        fileInput.addEventListener('dragleave', (e) => {
            e.preventDefault();
            fileInput.style.background = '';
        });
        
        fileInput.addEventListener('drop', (e) => {
            e.preventDefault();
            fileInput.style.background = '';
            const file = e.dataTransfer.files[0];
            if (file && file.type.startsWith('video/')) {
                selectedFile = file;
                document.getElementById('fileLabel').textContent = `✅ ${file.name}`;
                fileInput.classList.add('has-file');
                addLog(`Selected: ${file.name}`);
            }
        });
        
        // Tab switching
        function showTab(tabName) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            event.target.classList.add('active');
            document.getElementById(tabName).classList.add('active');
        }
        
        // Slider updates
        document.getElementById('silenceThreshold').addEventListener('input', function() {
            document.getElementById('silenceValue').textContent = this.value;
        });
        
        document.getElementById('brollCoverage').addEventListener('input', function() {
            document.getElementById('coverageValue').textContent = this.value;
        });
        
        // WebSocket connection
        function connectWebSocket() {
            ws = new WebSocket('ws://localhost:8080/ws');
            
            ws.onopen = () => {
                addLog('Connected to backend service');
            };
            
            ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                if (data.progress !== undefined) {
                    updateProgress(data.progress * 100, data.message || 'Processing...');
                }
                if (data.log) {
                    addLog(data.log);
                }
            };
            
            ws.onerror = () => {
                addLog('WebSocket error - backend may not be running');
            };
            
            ws.onclose = () => {
                addLog('Disconnected from backend');
                setTimeout(connectWebSocket, 5000);
            };
        }
        
        // Process video
        async function processVideo() {
            if (!selectedFile) {
                alert('Please select a video file first');
                return;
            }
            
            addLog('Starting video processing...');
            updateProgress(0, 'Initializing...');
            
            const formData = new FormData();
            formData.append('video', selectedFile);
            formData.append('options', JSON.stringify({
                removeSilence: document.getElementById('removeSilence').checked,
                detectScenes: document.getElementById('detectScenes').checked,
                enableBroll: document.getElementById('enableBroll').checked,
                enableCaptions: document.getElementById('enableCaptions').checked,
                voiceIsolation: document.getElementById('voiceIsolation').checked,
                dialogueLeveler: document.getElementById('dialogueLeveler').checked,
                exportYoutube: document.getElementById('exportYoutube').checked,
                exportTiktok: document.getElementById('exportTiktok').checked,
                exportInstagram: document.getElementById('exportInstagram').checked,
                smartCrop: document.getElementById('smartCrop').checked,
                silenceThreshold: document.getElementById('silenceThreshold').value,
                brollCoverage: document.getElementById('brollCoverage').value / 100,
                captionStyle: document.getElementById('captionStyle').value
            }));
            
            try {
                const response = await fetch('/api/process', {
                    method: 'POST',
                    body: formData
                });
                
                if (response.ok) {
                    const result = await response.json();
                    addLog(`✅ Processing complete! Task ID: ${result.task_id}`);
                    updateProgress(100, 'Complete!');
                } else {
                    addLog('❌ Processing failed');
                }
            } catch (error) {
                addLog(`Error: ${error.message}`);
            }
        }
        
        // Validate configuration
        async function validateConfig() {
            addLog('Running validation checks...');
            
            try {
                const response = await fetch('/api/validate');
                const result = await response.json();
                
                if (result.errors.length === 0) {
                    addLog('✅ Configuration valid');
                } else {
                    result.errors.forEach(err => addLog(`❌ ${err}`));
                }
                
                result.warnings.forEach(warn => addLog(`⚠️ ${warn}`));
                
            } catch (error) {
                addLog(`Validation error: ${error.message}`);
            }
        }
        
        // Open renders folder
        async function openRenders() {
            try {
                const response = await fetch('/api/open-renders', { method: 'POST' });
                if (response.ok) {
                    addLog('Opened renders folder');
                }
            } catch (error) {
                addLog(`Error: ${error.message}`);
            }
        }
        
        // Update progress
        function updateProgress(percent, message) {
            document.getElementById('progressFill').style.width = percent + '%';
            document.getElementById('progressFill').textContent = Math.round(percent) + '%';
            document.getElementById('status').textContent = message;
        }
        
        // Add log entry
        function addLog(message) {
            const logArea = document.getElementById('logArea');
            const entry = document.createElement('div');
            entry.className = 'log-entry';
            entry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
            logArea.appendChild(entry);
            logArea.scrollTop = logArea.scrollHeight;
        }
        
        // Initialize
        connectWebSocket();
    </script>
</body>
</html>
'''

class WebGUI:
    def __init__(self):
        self.app = web.Application()
        self.setup_routes()
        self.setup_cors()
        
    def setup_routes(self):
        self.app.router.add_get('/', self.index)
        self.app.router.add_post('/api/process', self.process_video)
        self.app.router.add_get('/api/validate', self.validate_config)
        self.app.router.add_post('/api/open-renders', self.open_renders)
        self.app.router.add_get('/ws', self.websocket_handler)
        
    def setup_cors(self):
        cors = aiohttp_cors.setup(self.app, defaults={
            "*": aiohttp_cors.ResourceOptions(
                allow_credentials=True,
                expose_headers="*",
                allow_headers="*",
                allow_methods="*"
            )
        })
        
        for route in list(self.app.router.routes()):
            cors.add(route)
            
    async def index(self, request):
        return web.Response(text=HTML_TEMPLATE, content_type='text/html')
        
    async def process_video(self, request):
        try:
            reader = await request.multipart()
            video_file = None
            options = {}
            
            async for part in reader:
                if part.name == 'video':
                    # Save uploaded file
                    filename = part.filename
                    video_path = Path('inputs') / filename
                    video_path.parent.mkdir(exist_ok=True)
                    
                    with open(video_path, 'wb') as f:
                        async for chunk in part:
                            f.write(chunk)
                    video_file = str(video_path)
                    
                elif part.name == 'options':
                    text = await part.text()
                    options = json.loads(text)
                    
            if video_file:
                # Start processing in background
                task_id = await self.start_processing(video_file, options)
                return web.json_response({'status': 'started', 'task_id': task_id})
            else:
                return web.json_response({'error': 'No video file provided'}, status=400)
                
        except Exception as e:
            logger.error(f"Process error: {e}")
            return web.json_response({'error': str(e)}, status=500)
            
    async def start_processing(self, video_file, options):
        """Start video processing pipeline"""
        import uuid
        task_id = str(uuid.uuid4())
        
        async def run_pipeline():
            try:
                # Build command
                cmd = ['python3', '-m', 'pipelines.shortsify',
                       '--input', video_file,
                       '--artifacts', './artifacts']
                       
                if options.get('smartCrop'):
                    cmd.append('--enable_smart_crop')
                if not options.get('enableBroll'):
                    cmd.append('--disable_broll')
                if not options.get('enableCaptions'):
                    cmd.append('--disable_captions')
                    
                # Run command
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                stdout, stderr = await process.communicate()
                logger.info(f"Pipeline output: {stdout.decode()}")
                
            except Exception as e:
                logger.error(f"Pipeline error: {e}")
                
        asyncio.create_task(run_pipeline())
        return task_id
        
    async def validate_config(self, request):
        """Validate configuration"""
        errors = []
        warnings = []
        
        # Check if Resolve is running
        result = subprocess.run(['pgrep', '-x', 'Resolve'], capture_output=True)
        if result.returncode != 0:
            warnings.append("DaVinci Resolve is not running")
            
        # Check B-roll folder
        broll_path = Path('inputs/broll')
        if not broll_path.exists():
            warnings.append("B-roll folder not found")
        else:
            broll_count = len(list(broll_path.glob('*.mp4')))
            if broll_count == 0:
                warnings.append("No B-roll clips found")
                
        return web.json_response({
            'errors': errors,
            'warnings': warnings
        })
        
    async def open_renders(self, request):
        """Open renders folder"""
        renders_path = Path('artifacts/renders')
        renders_path.mkdir(parents=True, exist_ok=True)
        subprocess.run(['open', str(renders_path)])
        return web.json_response({'status': 'opened'})
        
    async def websocket_handler(self, request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        
        await ws.send_json({
            'status': 'connected',
            'message': 'WebSocket connected'
        })
        
        async for msg in ws:
            if msg.type == web.WSMsgType.TEXT:
                # Echo back for now
                await ws.send_str(msg.data)
            elif msg.type == web.WSMsgType.ERROR:
                logger.error(f'WebSocket error: {ws.exception()}')
                
        return ws
        
    def run(self, host='0.0.0.0', port=8081):
        logger.info(f"Starting Web GUI on http://{host}:{port}")
        web.run_app(self.app, host=host, port=port)

if __name__ == '__main__':
    gui = WebGUI()
    gui.run()