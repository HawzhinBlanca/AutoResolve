# Requirements (REQ)

- REQ-1: Repo layout and files match Blueprint frozen structure.
- REQ-2: Makefile targets: setup, cuts, scenes, transcript, index-broll, shortsify, podcast, qc, clean.
- REQ-3: Scripts: ae_silence.sh exports FCPXML; psd_scenes.sh produces OTIO.
- REQ-4: Tools: transcribe_fastwhisper.py outputs transcript.json.
- REQ-5: resolve_api/core.py provides connect(), path guards, hash8().
- REQ-6: resolve_api/render_ops.py implements SetRenderSettings, AddRenderJob retry, Start+poll.
- REQ-7: resolve_api/timeline_ops.py: import FCPXML, duplicate timeline, Transform(ROI), append(V2) B-roll.
- REQ-8: resolve_api/captions_ops.py: TranscribeAudio() → CreateSubtitlesFromAudio() on timeline.
- REQ-9: resolve_api/audio_ops.py: Voice Isolation / Dialogue Leveler toggles; sidechain template.
- REQ-10: broll/index.py: keyframes → OpenCLIP embedding (avg) → sqlite db.
- REQ-11: broll/query.py: transcript.json → noun-phrases + embeddings.
- REQ-12: broll/select.py: ranking + diversity + duration fit + cascade.
- REQ-13: broll/assemble.py: place B‑roll on V2 via AppendToTimeline(recordFrame).
- REQ-14: pipelines/shortsify.py: A→Z orchestration; duplicate to 9:16 & 1:1 and render with hash8 in name.
- REQ-15: pipelines/multicam_podcast.py: Multicam + SmartSwitch (manual) + continue.
- REQ-16: presets: render profiles and fairlight_template.drp.
- REQ-17: tests: verify_cuts_match.py, verify_broll_bounds.py, smoke_render.py (QC gates).
- REQ-18: Deterministic fingerprint hash8 over artifacts saved and appended to filenames.
