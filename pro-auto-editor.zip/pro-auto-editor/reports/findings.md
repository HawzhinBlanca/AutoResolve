# Findings Report (initial)

- Critical Gaps:
  - Resolve timeline ops (duplicate/Transform(ROI)/append[V2]) not implemented; needs Resolve API coding.
  - Captions and audio ops pending.
  - Multicam podcast path pending.
  - QC gates need stronger checks and idempotence proof.

- Forced Blueprint Changes Proposed (minimal):
  - Remove pydavinci pin; use DaVinciResolveScript directly (pydavinci wheel unavailable on Python 3.11+).
  - Do not pin OpenTimelineIO build in requirements; rely on existing `opentimelineio` or use a wheel version; building 0.15.0 from sdist fails in this environment.

- Proofs available:
  - Scenes and cuts generated; Resolve render completed; 60s 9:16 and 1:1 exports produced.
  - Environment probe: Resolve connectivity confirmed earlier; package/version details captured where available.
