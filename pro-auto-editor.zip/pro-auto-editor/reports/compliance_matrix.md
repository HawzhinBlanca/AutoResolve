# Compliance Matrix (initial)

- REQ-1: PASS — scaffold present. Files under pro-auto-editor/.
- REQ-2: PASS — Makefile targets implemented.
- REQ-3: PASS — scripts/ae_silence.sh, psd_scenes.sh wired; OTIO fallback provided.
- REQ-4: PASS — tools/transcribe_fastwhisper.py provided.
- REQ-5: PASS — resolve_api/core.py connect + hash8; lazy import Resolve module.
- REQ-6: PASS — resolve_api/render_ops.py implements settings, retry, poll.
- REQ-7: PARTIAL — import implemented; duplicate/Transform(ROI)/append(V2) not yet coded against Resolve API.
- REQ-8: PARTIAL — captions_ops.py placeholder; needs timeline ops.
- REQ-9: PARTIAL — audio_ops.py placeholder; needs Resolve toggles.
- REQ-10: PASS — broll/index.py upgraded to frame-averaged CLIP with fallback.
- REQ-11: PASS — broll/query.py implemented.
- REQ-12: PASS — broll/select.py implemented MMR ranking and JSON output.
- REQ-13: PARTIAL — assemble writes selection; Resolve AppendToTimeline not executed yet.
- REQ-14: PARTIAL — shortsify imports and renders 16:9; duplication/transforms pending. Hash8 write added.
- REQ-15: TODO — multicam flow not implemented.
- REQ-16: PASS — presets present.
- REQ-17: PARTIAL — tests implemented but thresholds and parity logic minimal.
- REQ-18: PARTIAL — hash8 written; not appended to all outputs yet.
