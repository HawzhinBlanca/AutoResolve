import SwiftUI
import Combine
import AVKit
import UniformTypeIdentifiers

// MARK: - Main App

@main
struct ProAutoEditorApp: App {
    @StateObject private var appState = AppState()
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
                .frame(minWidth: 1200, minHeight: 800)
                .onAppear {
                    NSWindow.allowsAutomaticWindowTabbing = false
                }
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unified(showsTitle: true))
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("New Project") {
                    appState.createNewProject()
                }
                .keyboardShortcut("n", modifiers: .command)
            }
        }
        
        Settings {
            SettingsView()
                .environmentObject(appState)
        }
    }
}

class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        // Start backend service
        BackendManager.shared.startBackendService()
    }
}

// MARK: - Main Content View

struct ContentView: View {
    @EnvironmentObject var appState: AppState
    @State private var showingFilePicker = false
    @State private var isDragging = false
    
    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                colors: [Color(NSColor.controlBackgroundColor), Color(NSColor.windowBackgroundColor)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            if appState.currentProject == nil {
                WelcomeView()
                    .transition(.opacity.combined(with: .scale(scale: 0.95)))
            } else {
                ProjectView()
                    .transition(.opacity.combined(with: .scale(scale: 1.05)))
            }
        }
        .animation(.spring(response: 0.5, dampingFraction: 0.8), value: appState.currentProject)
        .toolbar {
            ToolbarContent()
        }
    }
}

// MARK: - Welcome View

struct WelcomeView: View {
    @EnvironmentObject var appState: AppState
    @State private var isDragging = false
    @State private var showingFilePicker = false
    
    var body: some View {
        VStack(spacing: 40) {
            // Logo and Title
            VStack(spacing: 16) {
                Image(systemName: "film.circle.fill")
                    .font(.system(size: 80))
                    .foregroundStyle(
                        LinearGradient(colors: [.blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .shadow(color: .blue.opacity(0.3), radius: 20)
                
                Text("Pro Auto Editor")
                    .font(.system(size: 42, weight: .bold, design: .rounded))
                
                Text("Professional Video Automation for DaVinci Resolve")
                    .font(.title3)
                    .foregroundColor(.secondary)
            }
            
            // Drop Zone
            RoundedRectangle(cornerRadius: 20)
                .strokeBorder(
                    isDragging ? Color.accentColor : Color.secondary.opacity(0.3),
                    style: StrokeStyle(lineWidth: 2, dash: isDragging ? [] : [10])
                )
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .fill(isDragging ? Color.accentColor.opacity(0.1) : Color.clear)
                )
                .frame(width: 600, height: 300)
                .overlay(
                    VStack(spacing: 20) {
                        Image(systemName: "arrow.down.doc.fill")
                            .font(.system(size: 60))
                            .foregroundColor(isDragging ? .accentColor : .secondary)
                        
                        Text("Drop your video here")
                            .font(.title2)
                            .fontWeight(.medium)
                        
                        Text("or")
                            .foregroundColor(.secondary)
                        
                        Button(action: { showingFilePicker = true }) {
                            Label("Choose File", systemImage: "folder")
                                .padding(.horizontal, 24)
                                .padding(.vertical, 12)
                                .background(Color.accentColor)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                        }
                        .buttonStyle(.plain)
                    }
                )
                .onDrop(of: [.movie, .quickTimeMovie], isTargeted: $isDragging) { providers in
                    handleDrop(providers: providers)
                    return true
                }
                .animation(.spring(response: 0.3), value: isDragging)
            
            // Recent Projects
            if !appState.recentProjects.isEmpty {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Recent Projects")
                        .font(.headline)
                        .foregroundColor(.secondary)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(appState.recentProjects) { project in
                                RecentProjectCard(project: project)
                            }
                        }
                    }
                }
                .frame(maxWidth: 800)
            }
        }
        .padding(40)
        .fileImporter(
            isPresented: $showingFilePicker,
            allowedContentTypes: [.movie, .quickTimeMovie, .mpeg4Movie],
            allowsMultipleSelection: false
        ) { result in
            switch result {
            case .success(let urls):
                if let url = urls.first {
                    appState.createProject(from: url)
                }
            case .failure(let error):
                print("Error selecting file: \(error)")
            }
        }
    }
    
    func handleDrop(providers: [NSItemProvider]) {
        for provider in providers {
            provider.loadFileRepresentation(forTypeIdentifier: UTType.movie.identifier) { url, error in
                if let url = url {
                    DispatchQueue.main.async {
                        appState.createProject(from: url)
                    }
                }
            }
        }
    }
}

// MARK: - Project View

struct ProjectView: View {
    @EnvironmentObject var appState: AppState
    @State private var selectedTab = 0
    
    var body: some View {
        HSplitView {
            // Sidebar
            ProjectSidebar()
                .frame(minWidth: 280, maxWidth: 350)
            
            // Main Content
            VStack(spacing: 0) {
                // Tab Bar
                CustomTabBar(selectedTab: $selectedTab)
                
                Divider()
                
                // Tab Content
                TabView(selection: $selectedTab) {
                    EditingView()
                        .tag(0)
                    
                    BRollView()
                        .tag(1)
                    
                    CaptionsView()
                        .tag(2)
                    
                    AudioView()
                        .tag(3)
                    
                    ExportView()
                        .tag(4)
                }
                .tabViewStyle(.automatic)
            }
        }
    }
}

// MARK: - Custom Tab Bar

struct CustomTabBar: View {
    @Binding var selectedTab: Int
    
    let tabs = [
        ("film", "Editing"),
        ("photo.on.rectangle.angled", "B-Roll"),
        ("captions.bubble", "Captions"),
        ("waveform", "Audio"),
        ("square.and.arrow.up", "Export")
    ]
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(Array(tabs.enumerated()), id: \.offset) { index, tab in
                TabButton(
                    icon: tab.0,
                    title: tab.1,
                    isSelected: selectedTab == index
                ) {
                    withAnimation(.spring(response: 0.3)) {
                        selectedTab = index
                    }
                }
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(Color(NSColor.controlBackgroundColor))
    }
}

struct TabButton: View {
    let icon: String
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(isSelected ? .accentColor : .secondary)
                
                Text(title)
                    .font(.caption)
                    .foregroundColor(isSelected ? .primary : .secondary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(isSelected ? Color.accentColor.opacity(0.1) : Color.clear)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Project Sidebar

struct ProjectSidebar: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Project Info
            ProjectInfoCard()
                .padding()
            
            Divider()
            
            // Pipeline Status
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Pipeline Status")
                        .font(.headline)
                        .padding(.horizontal)
                        .padding(.top)
                    
                    ForEach(StageType.allCases) { stage in
                        PipelineStageRow(stage: stage)
                            .padding(.horizontal)
                    }
                }
                .padding(.bottom)
            }
            
            Divider()
            
            // Actions
            HStack(spacing: 12) {
                Button(action: { appState.validateConfiguration() }) {
                    Label("Validate", systemImage: "checkmark.shield")
                        .frame(maxWidth: .infinity)
                }
                .controlSize(.large)
                
                Button(action: { appState.startPipeline() }) {
                    Label("Start", systemImage: "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .controlSize(.large)
                .buttonStyle(.borderedProminent)
                .disabled(!appState.isValid)
            }
            .padding()
        }
        .background(Color(NSColor.controlBackgroundColor))
    }
}

// MARK: - Editing View

struct EditingView: View {
    @EnvironmentObject var appState: AppState
    @State private var silenceThreshold: Double = -30
    @State private var minSilenceDuration: Double = 0.5
    @State private var enableSceneDetection = true
    @State private var sceneThreshold: Double = 30.0
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                // Video Preview
                VideoPreviewCard()
                
                // Silence Removal Settings
                SettingsCard(title: "Silence Removal", icon: "waveform.circle") {
                    VStack(alignment: .leading, spacing: 16) {
                        SliderSetting(
                            title: "Silence Threshold",
                            value: $silenceThreshold,
                            range: -60...0,
                            unit: "dB"
                        )
                        
                        SliderSetting(
                            title: "Minimum Silence Duration",
                            value: $minSilenceDuration,
                            range: 0.1...2.0,
                            unit: "sec"
                        )
                    }
                }
                
                // Scene Detection Settings
                SettingsCard(title: "Scene Detection", icon: "rectangle.split.3x3") {
                    VStack(alignment: .leading, spacing: 16) {
                        Toggle("Enable Scene Detection", isOn: $enableSceneDetection)
                            .toggleStyle(.switch)
                        
                        if enableSceneDetection {
                            SliderSetting(
                                title: "Scene Change Threshold",
                                value: $sceneThreshold,
                                range: 10...100,
                                unit: "%"
                            )
                        }
                    }
                }
            }
            .padding()
        }
    }
}

// MARK: - B-Roll View

struct BRollView: View {
    @EnvironmentObject var appState: AppState
    @State private var enableBRoll = true
    @State private var brollFolders: [URL] = []
    @State private var coverageRatio: Double = 30.0
    @State private var crossDissolveFrames = 15
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                SettingsCard(title: "B-Roll Settings", icon: "photo.on.rectangle") {
                    VStack(alignment: .leading, spacing: 16) {
                        Toggle("Enable B-Roll", isOn: $enableBRoll)
                            .toggleStyle(.switch)
                        
                        if enableBRoll {
                            // B-Roll Folders
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Text("B-Roll Folders")
                                        .font(.headline)
                                    
                                    Spacer()
                                    
                                    Button(action: addBRollFolder) {
                                        Label("Add Folder", systemImage: "plus.circle")
                                    }
                                }
                                
                                ForEach(brollFolders, id: \.self) { folder in
                                    BRollFolderRow(url: folder) {
                                        removeBRollFolder(folder)
                                    }
                                }
                            }
                            
                            Divider()
                            
                            SliderSetting(
                                title: "Coverage Ratio",
                                value: $coverageRatio,
                                range: 10...50,
                                unit: "%"
                            )
                            
                            StepperSetting(
                                title: "Cross Dissolve",
                                value: $crossDissolveFrames,
                                range: 0...30,
                                unit: "frames"
                            )
                        }
                    }
                }
                
                // B-Roll Index Status
                if enableBRoll {
                    BRollIndexCard()
                }
            }
            .padding()
        }
    }
    
    func addBRollFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = true
        
        if panel.runModal() == .OK {
            brollFolders.append(contentsOf: panel.urls)
        }
    }
    
    func removeBRollFolder(_ url: URL) {
        brollFolders.removeAll { $0 == url }
    }
}

// MARK: - Export View

struct ExportView: View {
    @EnvironmentObject var appState: AppState
    @State private var selectedFormats = Set<ExportFormat>([.youtube, .tiktok, .instagram])
    @State private var renderQuality = RenderQuality.high
    @State private var enableSmartCrop = true
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                // Export Formats
                SettingsCard(title: "Export Formats", icon: "square.and.arrow.up") {
                    VStack(alignment: .leading, spacing: 16) {
                        ForEach(ExportFormat.allCases) { format in
                            ExportFormatRow(
                                format: format,
                                isSelected: selectedFormats.contains(format),
                                toggle: {
                                    if selectedFormats.contains(format) {
                                        selectedFormats.remove(format)
                                    } else {
                                        selectedFormats.insert(format)
                                    }
                                }
                            )
                        }
                    }
                }
                
                // Render Settings
                SettingsCard(title: "Render Settings", icon: "gearshape") {
                    VStack(alignment: .leading, spacing: 16) {
                        Picker("Quality", selection: $renderQuality) {
                            ForEach(RenderQuality.allCases) { quality in
                                Text(quality.rawValue).tag(quality)
                            }
                        }
                        .pickerStyle(.segmented)
                        
                        Toggle("Smart Crop (AI-powered)", isOn: $enableSmartCrop)
                            .toggleStyle(.switch)
                    }
                }
                
                // Render Queue
                RenderQueueCard()
            }
            .padding()
        }
    }
}

// MARK: - Supporting Views

struct VideoPreviewCard: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Source Video")
                .font(.headline)
            
            if let url = appState.currentProject?.sourceVideoURL {
                VideoPlayer(player: AVPlayer(url: url))
                    .frame(height: 400)
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.secondary.opacity(0.2), lineWidth: 1)
                    )
            } else {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.secondary.opacity(0.1))
                    .frame(height: 400)
                    .overlay(
                        Text("No video loaded")
                            .foregroundColor(.secondary)
                    )
            }
            
            // Video Info
            if let project = appState.currentProject {
                HStack(spacing: 20) {
                    Label("\(project.duration)", systemImage: "clock")
                    Label("\(project.resolution)", systemImage: "aspectratio")
                    Label("\(project.fileSize)", systemImage: "doc")
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
        }
    }
}

struct SettingsCard<Content: View>: View {
    let title: String
    let icon: String
    @ViewBuilder let content: Content
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(.accentColor)
                
                Text(title)
                    .font(.title3)
                    .fontWeight(.semibold)
            }
            
            content
        }
        .padding()
        .background(Color(NSColor.controlBackgroundColor))
        .cornerRadius(12)
    }
}

struct SliderSetting: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let unit: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(title)
                    .font(.subheadline)
                Spacer()
                Text(String(format: "%.1f %@", value, unit))
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .monospacedDigit()
            }
            
            Slider(value: $value, in: range)
        }
    }
}

struct StepperSetting: View {
    let title: String
    @Binding var value: Int
    let range: ClosedRange<Int>
    let unit: String
    
    var body: some View {
        HStack {
            Text(title)
                .font(.subheadline)
            
            Spacer()
            
            Stepper("\(value) \(unit)", value: $value, in: range)
                .labelsHidden()
            
            Text("\(value) \(unit)")
                .font(.subheadline)
                .foregroundColor(.secondary)
                .monospacedDigit()
                .frame(width: 80, alignment: .trailing)
        }
    }
}

// MARK: - Data Models

class AppState: ObservableObject {
    @Published var currentProject: Project?
    @Published var recentProjects: [Project] = []
    @Published var pipelineStatus: PipelineStatus?
    @Published var isValid = false
    @Published var validationErrors: [String] = []
    
    func createProject(from url: URL) {
        let project = Project(sourceVideoURL: url)
        currentProject = project
        BackendManager.shared.validateConfiguration()
    }
    
    func createNewProject() {
        currentProject = nil
    }
    
    func startPipeline() {
        guard let project = currentProject else { return }
        BackendManager.shared.startPipeline(for: project)
    }
    
    func validateConfiguration() {
        BackendManager.shared.validateConfiguration()
    }
}

struct Project: Identifiable {
    let id = UUID()
    let sourceVideoURL: URL
    let createdAt = Date()
    var duration: String { "00:00:00" }
    var resolution: String { "1920x1080" }
    var fileSize: String { "0 MB" }
}

struct PipelineStatus {
    let taskId: String
    let status: TaskStatus
    let stage: StageType?
    let progress: Double
    let message: String
}

enum TaskStatus: String {
    case queued, validating, running, completed, failed, retrying, cancelled
}

enum StageType: String, CaseIterable, Identifiable {
    case silenceRemoval = "Silence Removal"
    case sceneDetection = "Scene Detection"
    case transcription = "Transcription"
    case brollIndexing = "B-Roll Indexing"
    case timelineBuild = "Timeline Build"
    case brollSelection = "B-Roll Selection"
    case captionGeneration = "Caption Generation"
    case audioProcessing = "Audio Processing"
    case rendering = "Rendering"
    case qcCheck = "Quality Check"
    
    var id: String { rawValue }
    
    var icon: String {
        switch self {
        case .silenceRemoval: return "waveform"
        case .sceneDetection: return "rectangle.split.3x3"
        case .transcription: return "captions.bubble"
        case .brollIndexing: return "photo.stack"
        case .timelineBuild: return "timeline.selection"
        case .brollSelection: return "photo.on.rectangle"
        case .captionGeneration: return "text.bubble"
        case .audioProcessing: return "speaker.wave.3"
        case .rendering: return "film"
        case .qcCheck: return "checkmark.shield"
        }
    }
}

enum ExportFormat: String, CaseIterable, Identifiable {
    case youtube = "YouTube (16:9)"
    case tiktok = "TikTok (9:16)"
    case instagram = "Instagram (1:1)"
    case twitter = "Twitter (16:9)"
    case linkedin = "LinkedIn (1:1)"
    
    var id: String { rawValue }
    
    var icon: String {
        switch self {
        case .youtube: return "play.rectangle"
        case .tiktok: return "music.note"
        case .instagram: return "camera"
        case .twitter: return "bird"
        case .linkedin: return "briefcase"
        }
    }
    
    var resolution: String {
        switch self {
        case .youtube, .twitter: return "1920x1080"
        case .tiktok: return "1080x1920"
        case .instagram, .linkedin: return "1080x1080"
        }
    }
}

enum RenderQuality: String, CaseIterable, Identifiable {
    case low = "Low"
    case medium = "Medium"
    case high = "High"
    case maximum = "Maximum"
    
    var id: String { rawValue }
}

// MARK: - Additional Supporting Views

struct RecentProjectCard: View {
    let project: Project
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.accentColor.opacity(0.2))
                .frame(width: 150, height: 85)
                .overlay(
                    Image(systemName: "play.rectangle.fill")
                        .font(.title2)
                        .foregroundColor(.accentColor)
                )
            
            Text(project.sourceVideoURL.lastPathComponent)
                .font(.caption)
                .lineLimit(1)
            
            Text(project.createdAt, style: .relative)
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(width: 150)
    }
}

struct PipelineStageRow: View {
    let stage: StageType
    @State private var status: TaskStatus = .queued
    @State private var progress: Double = 0
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: stage.icon)
                .font(.title3)
                .foregroundColor(statusColor)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(stage.rawValue)
                    .font(.subheadline)
                
                if status == .running {
                    ProgressView(value: progress)
                        .progressViewStyle(.linear)
                        .scaleEffect(y: 0.5)
                }
            }
            
            Spacer()
            
            StatusBadge(status: status)
        }
        .padding(.vertical, 4)
    }
    
    var statusColor: Color {
        switch status {
        case .completed: return .green
        case .failed: return .red
        case .running, .retrying: return .orange
        default: return .secondary
        }
    }
}

struct StatusBadge: View {
    let status: TaskStatus
    
    var body: some View {
        Text(status.rawValue.capitalized)
            .font(.caption2)
            .fontWeight(.medium)
            .padding(.horizontal, 8)
            .padding(.vertical, 2)
            .background(backgroundColor)
            .foregroundColor(foregroundColor)
            .cornerRadius(4)
    }
    
    var backgroundColor: Color {
        switch status {
        case .completed: return .green.opacity(0.2)
        case .failed: return .red.opacity(0.2)
        case .running, .retrying: return .orange.opacity(0.2)
        default: return Color.secondary.opacity(0.2)
        }
    }
    
    var foregroundColor: Color {
        switch status {
        case .completed: return .green
        case .failed: return .red
        case .running, .retrying: return .orange
        default: return .secondary
        }
    }
}

struct ExportFormatRow: View {
    let format: ExportFormat
    let isSelected: Bool
    let toggle: () -> Void
    
    var body: some View {
        HStack {
            Image(systemName: format.icon)
                .font(.title3)
                .foregroundColor(isSelected ? .accentColor : .secondary)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(format.rawValue)
                    .font(.subheadline)
                
                Text(format.resolution)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Toggle("", isOn: .constant(isSelected))
                .toggleStyle(.switch)
                .labelsHidden()
                .onTapGesture { toggle() }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Backend Manager

class BackendManager: ObservableObject {
    static let shared = BackendManager()
    
    private var websocket: URLSessionWebSocketTask?
    private let baseURL = "http://localhost:8080"
    
    func startBackendService() {
        // Start Python backend service
        DispatchQueue.global().async {
            let task = Process()
            task.launchPath = "/usr/bin/python3"
            task.arguments = ["backend_service.py"]
            task.launch()
        }
        
        // Connect WebSocket
        connectWebSocket()
    }
    
    func connectWebSocket() {
        guard let url = URL(string: "ws://localhost:8080/ws") else { return }
        websocket = URLSession.shared.webSocketTask(with: url)
        websocket?.resume()
        receiveMessage()
    }
    
    func receiveMessage() {
        websocket?.receive { [weak self] result in
            switch result {
            case .success(let message):
                switch message {
                case .string(let text):
                    self?.handleMessage(text)
                default:
                    break
                }
                self?.receiveMessage()
            case .failure(let error):
                print("WebSocket error: \(error)")
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                    self?.connectWebSocket()
                }
            }
        }
    }
    
    func handleMessage(_ message: String) {
        // Parse and handle WebSocket messages
        guard let data = message.data(using: .utf8),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return
        }
        
        DispatchQueue.main.async {
            // Update UI based on message
            print("Received: \(json)")
        }
    }
    
    func validateConfiguration() {
        // Call validation endpoint
    }
    
    func startPipeline(for project: Project) {
        // Start pipeline via API
    }
}

// MARK: - Additional Views

struct CaptionsView: View {
    @State private var enableCaptions = true
    @State private var fontSize: Double = 48
    @State private var fontFamily = "SF Pro Display"
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                SettingsCard(title: "Caption Settings", icon: "captions.bubble") {
                    VStack(alignment: .leading, spacing: 16) {
                        Toggle("Enable Captions", isOn: $enableCaptions)
                            .toggleStyle(.switch)
                        
                        if enableCaptions {
                            SliderSetting(
                                title: "Font Size",
                                value: $fontSize,
                                range: 24...72,
                                unit: "pt"
                            )
                            
                            Picker("Font Family", selection: $fontFamily) {
                                Text("SF Pro Display").tag("SF Pro Display")
                                Text("SF Pro Text").tag("SF Pro Text")
                                Text("New York").tag("New York")
                                Text("Helvetica Neue").tag("Helvetica Neue")
                            }
                        }
                    }
                }
            }
            .padding()
        }
    }
}

struct AudioView: View {
    @State private var enableVoiceIsolation = true
    @State private var enableDialogueLeveler = true
    @State private var enableSidechainDucking = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                SettingsCard(title: "Audio Processing", icon: "waveform") {
                    VStack(alignment: .leading, spacing: 16) {
                        Toggle("Voice Isolation", isOn: $enableVoiceIsolation)
                            .toggleStyle(.switch)
                        
                        Toggle("Dialogue Leveler", isOn: $enableDialogueLeveler)
                            .toggleStyle(.switch)
                        
                        Toggle("Sidechain Ducking", isOn: $enableSidechainDucking)
                            .toggleStyle(.switch)
                    }
                }
            }
            .padding()
        }
    }
}

struct ProjectInfoCard: View {
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let project = appState.currentProject {
                Text(project.sourceVideoURL.lastPathComponent)
                    .font(.headline)
                    .lineLimit(1)
                
                VStack(alignment: .leading, spacing: 4) {
                    Label(project.duration, systemImage: "clock")
                    Label(project.resolution, systemImage: "aspectratio")
                    Label(project.fileSize, systemImage: "doc")
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct BRollFolderRow: View {
    let url: URL
    let onRemove: () -> Void
    
    var body: some View {
        HStack {
            Image(systemName: "folder.fill")
                .foregroundColor(.accentColor)
            
            Text(url.lastPathComponent)
                .font(.subheadline)
                .lineLimit(1)
            
            Spacer()
            
            Button(action: onRemove) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.secondary)
            }
            .buttonStyle(.plain)
        }
        .padding(.vertical, 4)
    }
}

struct BRollIndexCard: View {
    @State private var indexedCount = 0
    @State private var totalSize = "0 MB"
    
    var body: some View {
        SettingsCard(title: "B-Roll Index", icon: "photo.stack") {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("\(indexedCount) clips indexed")
                        .font(.subheadline)
                    Text(totalSize)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Button("Refresh Index") {
                    // Refresh index
                }
            }
        }
    }
}

struct RenderQueueCard: View {
    var body: some View {
        SettingsCard(title: "Render Queue", icon: "film.stack") {
            VStack(alignment: .leading, spacing: 12) {
                Text("No renders in queue")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
    }
}

struct SettingsView: View {
    var body: some View {
        TabView {
            GeneralSettingsView()
                .tabItem {
                    Label("General", systemImage: "gearshape")
                }
            
            ResolveSettingsView()
                .tabItem {
                    Label("DaVinci Resolve", systemImage: "film")
                }
        }
        .frame(width: 500, height: 400)
    }
}

struct GeneralSettingsView: View {
    var body: some View {
        Form {
            Text("General Settings")
        }
        .padding()
    }
}

struct ResolveSettingsView: View {
    var body: some View {
        Form {
            Text("DaVinci Resolve Settings")
        }
        .padding()
    }
}

// MARK: - Toolbar

struct ToolbarContent: ToolbarContent {
    @EnvironmentObject var appState: AppState
    
    var body: some ToolbarContent {
        ToolbarItem(placement: .navigation) {
            Button(action: {}) {
                Image(systemName: "sidebar.left")
            }
        }
        
        ToolbarItem(placement: .principal) {
            Text("Pro Auto Editor")
                .font(.headline)
        }
        
        ToolbarItem(placement: .primaryAction) {
            HStack(spacing: 12) {
                Button(action: { appState.validateConfiguration() }) {
                    Image(systemName: "checkmark.shield")
                }
                .help("Validate Configuration")
                
                Button(action: { appState.startPipeline() }) {
                    Image(systemName: "play.fill")
                }
                .disabled(!appState.isValid)
                .help("Start Pipeline")
            }
        }
    }
}