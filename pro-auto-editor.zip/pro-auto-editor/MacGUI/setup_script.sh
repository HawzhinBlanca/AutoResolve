#!/bin/bash

# Pro Auto Editor - Setup Script
# This script sets up the complete Pro Auto Editor environment on macOS

set -e  # Exit on error

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
print_header() {
    echo -e "${BLUE}================================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}================================================${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

check_command() {
    if command -v $1 &> /dev/null; then
        print_success "$1 is installed"
        return 0
    else
        print_error "$1 is not installed"
        return 1
    fi
}

# Main setup
print_header "Pro Auto Editor - Setup Script"

# Check system requirements
print_header "Checking System Requirements"

# Check macOS version
os_version=$(sw_vers -productVersion)
print_success "macOS version: $os_version"

# Check for Homebrew
if ! check_command brew; then
    print_warning "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# Check for Python 3.9+
if check_command python3; then
    python_version=$(python3 --version | cut -d' ' -f2)
    print_success "Python version: $python_version"
else
    print_warning "Installing Python 3.11..."
    brew install python@3.11
fi

# Check for DaVinci Resolve
if [ -d "/Applications/DaVinci Resolve" ]; then
    print_success "DaVinci Resolve is installed"
else
    print_error "DaVinci Resolve not found!"
    print_warning "Please install DaVinci Resolve from: https://www.blackmagicdesign.com/products/davinciresolve"
    exit 1
fi

# Install system dependencies
print_header "Installing System Dependencies"

# Install FFmpeg and other media tools
brew_packages=(
    "ffmpeg"
    "imagemagick"
    "sox"
    "git"
    "wget"
    "node"
)

for package in "${brew_packages[@]}"; do
    if brew list $package &>/dev/null; then
        print_success "$package already installed"
    else
        print_warning "Installing $package..."
        brew install $package
    fi
done

# Setup Python environment
print_header "Setting Up Python Environment"

# Create virtual environment
if [ ! -d "venv" ]; then
    print_warning "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip

# Install Python dependencies
print_header "Installing Python Dependencies"

cat > requirements_extended.txt << 'EOF'
# Core dependencies
auto-editor>=23.0.0
scenedetect[opencv]>=0.6
faster-whisper>=0.10.0

# Backend service
aiohttp>=3.9.0
aiohttp-cors>=0.7.0
psutil>=5.9.0
pyyaml>=6.0
websockets>=12.0

# AI/ML
torch>=2.0.0
torchvision>=0.15.0
open-clip-torch>=2.20.0
transformers>=4.30.0
sentence-transformers>=2.2.0

# Video processing
opencv-python>=4.8.0
moviepy>=1.0.3
Pillow>=10.0.0

# Database
sqlite3
sqlalchemy>=2.0.0

# Resolve API helpers
python-dotenv>=1.0.0
watchdog>=3.0.0

# Testing & QC
pytest>=7.4.0
pytest-asyncio>=0.21.0
ffmpeg-python>=0.2.0
EOF

print_warning "Installing Python packages (this may take a while)..."
pip install -r requirements_extended.txt

# Setup DaVinci Resolve Python API
print_header "Setting Up DaVinci Resolve Python API"

resolve_script_path="/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting"
if [ -d "$resolve_script_path" ]; then
    print_success "Resolve scripting modules found"
    
    # Create symbolic link for easier access
    if [ ! -L "resolve_api/DaVinciResolveScript.py" ]; then
        ln -s "$resolve_script_path/Modules/DaVinciResolveScript.py" "resolve_api/DaVinciResolveScript.py"
        print_success "Created symbolic link to Resolve API"
    fi
else
    print_error "Resolve scripting modules not found!"
    print_warning "Please enable scripting in DaVinci Resolve preferences"
fi

# Create necessary directories
print_header "Creating Project Structure"

directories=(
    "inputs"
    "artifacts/editdata"
    "artifacts/qc"
    "artifacts/renders"
    "artifacts/logs"
    "logs"
    "presets/render"
    "conf"
    ".cache/openclip"
    ".cache/whisper"
)

for dir in "${directories[@]}"; do
    if [ ! -d "$dir" ]; then
        mkdir -p "$dir"
        print_success "Created $dir"
    else
        print_success "$dir already exists"
    fi
done

# Create default configuration files
print_header "Creating Configuration Files"

# Create project.yaml
cat > conf/project.yaml << 'EOF'
# Pro Auto Editor - Project Configuration
project:
  name: "Default Project"
  version: "1.0.0"
  
silence_removal:
  enabled: true
  threshold: -30  # dB
  min_duration: 0.5  # seconds
  
scene_detection:
  enabled: true
  threshold: 30.0  # percentage
  
transcription:
  enabled: true
  model: "base"  # tiny, base, small, medium, large
  language: "auto"
  
captions:
  enabled: true
  font_size: 48
  font_family: "Arial"
  position: "bottom"
  
audio:
  voice_isolation: true
  dialogue_leveler: true
  sidechain_ducking: false
  
export:
  formats:
    - youtube
    - tiktok
    - instagram
  quality: "high"
  smart_crop: true
EOF

# Create broll.yaml
cat > conf/broll.yaml << 'EOF'
# Pro Auto Editor - B-Roll Configuration
broll:
  enabled: true
  folders:
    - "inputs/broll"
    - "/Volumes/Media/Stock Footage"
  
  selection:
    coverage_ratio: 0.3  # 30% of video covered with B-roll
    min_duration: 2.0  # seconds
    max_duration: 10.0  # seconds
    cross_dissolve_frames: 15
  
  matching:
    similarity_threshold: 0.7
    diversity_weight: 0.3
    
  index:
    batch_size: 32
    cache_embeddings: true
EOF

print_success "Configuration files created"

# Download models if needed
print_header "Downloading AI Models"

# Check for OpenCLIP model
if [ ! -f ".cache/openclip/ViT-B-32.pt" ]; then
    print_warning "Downloading OpenCLIP model..."
    python3 -c "import open_clip; open_clip.create_model_and_transforms('ViT-B/32', pretrained='openai')"
fi

# Setup macOS app
print_header "Setting Up macOS Application"

# Create Xcode project structure
if [ ! -d "ProAutoEditor.xcodeproj" ]; then
    print_warning "Creating Xcode project..."
    
    # Create project directories
    mkdir -p ProAutoEditor/ProAutoEditor
    mkdir -p ProAutoEditor/ProAutoEditor/Views
    mkdir -p ProAutoEditor/ProAutoEditor/Models
    mkdir -p ProAutoEditor/ProAutoEditor/Resources
    
    # Copy Swift files
    cp macos_swiftui_app.swift ProAutoEditor/ProAutoEditor/ContentView.swift
    
    # Create Info.plist
    cat > ProAutoEditor/ProAutoEditor/Info.plist << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleDevelopmentRegion</key>
    <string>$(DEVELOPMENT_LANGUAGE)</string>
    <key>CFBundleExecutable</key>
    <string>$(EXECUTABLE_NAME)</string>
    <key>CFBundleIdentifier</key>
    <string>$(PRODUCT_BUNDLE_IDENTIFIER)</string>
    <key>CFBundleInfoDictionaryVersion</key>
    <string>6.0</string>
    <key>CFBundleName</key>
    <string>$(PRODUCT_NAME)</string>
    <key>CFBundlePackageType</key>
    <string>$(PRODUCT_BUNDLE_PACKAGE_TYPE)</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0</string>
    <key>CFBundleVersion</key>
    <string>1</string>
    <key>LSMinimumSystemVersion</key>
    <string>$(MACOSX_DEPLOYMENT_TARGET)</string>
    <key>NSMainStoryboardFile</key>
    <string>Main</string>
    <key>NSPrincipalClass</key>
    <string>NSApplication</string>
</dict>
</plist>
EOF
    
    print_success "Xcode project structure created"
    print_warning "Open ProAutoEditor.xcodeproj in Xcode to build the app"
fi

# Create launch scripts
print_header "Creating Launch Scripts"

# Create backend launch script
cat > start_backend.sh << 'EOF'
#!/bin/bash
source venv/bin/activate
python3 backend_service.py
EOF
chmod +x start_backend.sh

# Create full pipeline launch script
cat > start_pro_auto_editor.sh << 'EOF'
#!/bin/bash

# Start backend service in background
./start_backend.sh &
BACKEND_PID=$!

# Wait for backend to start
sleep 3

# Open the macOS app
open ProAutoEditor.app 2>/dev/null || echo "Please build the app in Xcode first"

# Keep script running
wait $BACKEND_PID
EOF
chmod +x start_pro_auto_editor.sh

print_success "Launch scripts created"

# Setup Auto-Editor and PySceneDetect scripts
print_header "Setting Up Processing Scripts"

# Update ae_silence.sh
cat > scripts/ae_silence.sh << 'EOF'
#!/bin/bash
INPUT="$1"
OUTPUT="artifacts/editdata/cuts.fcpxml"

auto-editor "$INPUT" \
    --export fcpxml \
    --output "$OUTPUT" \
    --silent-threshold 0.04 \
    --frame-margin 3 \
    --min-clip-length 0.5

echo "Silence removal complete: $OUTPUT"
EOF
chmod +x scripts/ae_silence.sh

# Update psd_scenes.sh
cat > scripts/psd_scenes.sh << 'EOF'
#!/bin/bash
INPUT="$1"
OUTPUT="artifacts/editdata/scenes.otio"

scenedetect \
    --input "$INPUT" \
    --output artifacts/editdata \
    detect-content \
    --threshold 30.0 \
    list-scenes \
    export-html

echo "Scene detection complete: $OUTPUT"
EOF
chmod +x scripts/psd_scenes.sh

print_success "Processing scripts configured"

# Run initial tests
print_header "Running System Tests"

# Test Python imports
python3 -c "
import torch
import open_clip
import faster_whisper
import cv2
import aiohttp
print('✓ All Python modules imported successfully')
" || print_error "Some Python modules failed to import"

# Test FFmpeg
ffmpeg -version > /dev/null 2>&1 && print_success "FFmpeg working" || print_error "FFmpeg not working"

# Test Resolve API connection
python3 -c "
import sys
sys.path.append('/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules')
try:
    import DaVinciResolveScript as dvr
    print('✓ Resolve API modules accessible')
except:
    print('⚠ Resolve API not accessible - enable scripting in Resolve')
"

# Create test script
print_header "Creating Test Script"

cat > test_pipeline.py << 'EOF'
#!/usr/bin/env python3
"""Test script to verify pipeline components"""

import asyncio
import sys
from pathlib import Path

async def test_components():
    print("Testing Pro Auto Editor components...")
    
    # Test configuration
    from backend_service import ConfigValidator
    
    print("\n1. Testing configuration validation...")
    broll_validation = ConfigValidator.validate_broll_config()
    if broll_validation['errors']:
        print(f"   B-roll config errors: {broll_validation['errors']}")
    else:
        print("   ✓ B-roll configuration valid")
    
    print("\n2. Testing Resolve connection...")
    resolve_validation = ConfigValidator.validate_resolve_connection()
    if resolve_validation['errors']:
        print(f"   Resolve errors: {resolve_validation['errors']}")
    else:
        print("   ✓ Resolve connection valid")
    
    print("\n3. Testing sample video...")
    sample_video = "inputs/sample.mp4"
    if Path(sample_video).exists():
        input_validation = ConfigValidator.validate_input_file(sample_video)
        if input_validation['errors']:
            print(f"   Input errors: {input_validation['errors']}")
        else:
            print(f"   ✓ Sample video valid: {input_validation['info']}")
    else:
        print("   ⚠ No sample video found at inputs/sample.mp4")
    
    print("\nAll tests complete!")

if __name__ == "__main__":
    asyncio.run(test_components())
EOF
chmod +x test_pipeline.py

# Final summary
print_header "Setup Complete!"

echo -e "${GREEN}Pro Auto Editor has been successfully set up!${NC}"
echo ""
echo "Next steps:"
echo "1. Open DaVinci Resolve and enable scripting:"
echo "   Preferences > System > General > External scripting using"
echo ""
echo "2. Build the macOS app:"
echo "   Open ProAutoEditor.xcodeproj in Xcode and build"
echo ""
echo "3. Start the application:"
echo "   ./start_pro_auto_editor.sh"
echo ""
echo "4. Or run components individually:"
echo "   - Backend service: ./start_backend.sh"
echo "   - Process video: make cuts INPUT=your_video.mp4"
echo "   - Run tests: python3 test_pipeline.py"
echo ""
echo "Documentation:"
echo "   - Blueprint: Blueprint.md"
echo "   - Features: Features.md"
echo ""
print_success "Happy editing!"