"""
Pro-Auto-Editor Backend Service
Provides error recovery, progress monitoring, and config validation
"""

import asyncio
import json
import logging
import os
import sys
import time
import traceback
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional, Dict, Any, List, Callable
from concurrent.futures import ThreadPoolExecutor
import yaml
import subprocess
import hashlib

# For WebSocket communication with UI
from aiohttp import web
import aiohttp_cors
from aiohttp import WSMsgType
import psutil

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('artifacts/logs/backend.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    QUEUED = "queued"
    VALIDATING = "validating"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"
    CANCELLED = "cancelled"


class StageType(Enum):
    SILENCE_REMOVAL = "silence_removal"
    SCENE_DETECTION = "scene_detection"
    TRANSCRIPTION = "transcription"
    BROLL_INDEXING = "broll_indexing"
    BROLL_SELECTION = "broll_selection"
    TIMELINE_BUILD = "timeline_build"
    CAPTION_GENERATION = "caption_generation"
    AUDIO_PROCESSING = "audio_processing"
    RENDERING = "rendering"
    QC_CHECK = "qc_check"


@dataclass
class TaskProgress:
    task_id: str
    status: TaskStatus
    stage: Optional[StageType]
    progress: float  # 0.0 to 1.0
    message: str
    started_at: datetime
    updated_at: datetime
    eta_seconds: Optional[int] = None
    error: Optional[str] = None
    retry_count: int = 0
    metadata: Dict[str, Any] = None
    
    def to_dict(self):
        data = asdict(self)
        data['status'] = self.status.value
        data['stage'] = self.stage.value if self.stage else None
        data['started_at'] = self.started_at.isoformat()
        data['updated_at'] = self.updated_at.isoformat()
        return data


class ConfigValidator:
    """Validates configuration before pipeline execution"""
    
    @staticmethod
    def validate_broll_config(config_path: str = "conf/broll.yaml") -> Dict[str, List[str]]:
        """Validate B-roll configuration and paths"""
        errors = []
        warnings = []
        
        if not Path(config_path).exists():
            errors.append(f"Config file not found: {config_path}")
            return {"errors": errors, "warnings": warnings}
        
        try:
            with open(config_path, 'r') as f:
                config = yaml.safe_load(f)
        except Exception as e:
            errors.append(f"Failed to parse YAML: {str(e)}")
            return {"errors": errors, "warnings": warnings}
        
        # Check B-roll folders
        if 'broll_folders' in config:
            for folder in config['broll_folders']:
                path = Path(folder)
                if not path.exists():
                    errors.append(f"B-roll folder not found: {folder}")
                elif not path.is_dir():
                    errors.append(f"B-roll path is not a directory: {folder}")
                else:
                    # Check if folder has media files
                    media_extensions = {'.mp4', '.mov', '.avi', '.mkv', '.webm'}
                    media_files = [f for f in path.iterdir() 
                                 if f.suffix.lower() in media_extensions]
                    if not media_files:
                        warnings.append(f"No media files found in: {folder}")
        
        return {"errors": errors, "warnings": warnings}
    
    @staticmethod
    def validate_resolve_connection() -> Dict[str, Any]:
        """Check if DaVinci Resolve is running and API is accessible"""
        errors = []
        info = {}
        
        try:
            # Check if Resolve is running
            resolve_running = any('Resolve' in p.name() for p in psutil.process_iter(['name']))
            if not resolve_running:
                errors.append("DaVinci Resolve is not running")
            else:
                info['resolve_running'] = True
            
            # Try to import Resolve API
            sys.path.append('/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules')
            import DaVinciResolveScript as dvr
            resolve = dvr.scriptapp("Resolve")
            
            if resolve:
                info['api_connected'] = True
                project = resolve.GetProjectManager().GetCurrentProject()
                if project:
                    info['current_project'] = project.GetName()
                else:
                    warnings = ["No project is currently open in Resolve"]
            else:
                errors.append("Cannot connect to Resolve API (is scripting enabled?)")
        
        except ImportError:
            errors.append("Resolve scripting module not found")
        except Exception as e:
            errors.append(f"Resolve connection error: {str(e)}")
        
        return {"errors": errors, "info": info, "warnings": warnings if 'warnings' in locals() else []}
    
    @staticmethod
    def validate_input_file(filepath: str) -> Dict[str, Any]:
        """Validate input media file"""
        errors = []
        info = {}
        
        path = Path(filepath)
        if not path.exists():
            errors.append(f"Input file not found: {filepath}")
            return {"errors": errors, "info": info}
        
        if not path.is_file():
            errors.append(f"Input path is not a file: {filepath}")
            return {"errors": errors, "info": info}
        
        # Check file size
        size_mb = path.stat().st_size / (1024 * 1024)
        info['size_mb'] = round(size_mb, 2)
        
        if size_mb > 10000:  # 10GB warning
            info['warning'] = "Large file may take significant time to process"
        
        # Use ffprobe to get media info
        try:
            result = subprocess.run([
                'ffprobe', '-v', 'quiet', '-print_format', 'json',
                '-show_format', '-show_streams', str(path)
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                media_info = json.loads(result.stdout)
                
                # Extract relevant info
                if 'format' in media_info:
                    info['duration'] = float(media_info['format'].get('duration', 0))
                    info['format'] = media_info['format'].get('format_name', 'unknown')
                
                # Check for video and audio streams
                has_video = any(s['codec_type'] == 'video' for s in media_info.get('streams', []))
                has_audio = any(s['codec_type'] == 'audio' for s in media_info.get('streams', []))
                
                if not has_video:
                    errors.append("No video stream found in file")
                if not has_audio:
                    info['warning'] = "No audio stream found - silence removal will fail"
                
                info['has_video'] = has_video
                info['has_audio'] = has_audio
        
        except Exception as e:
            errors.append(f"Failed to analyze media file: {str(e)}")
        
        return {"errors": errors, "info": info}


class ResolveAPIManager:
    """Manages Resolve API connection with automatic reconnection"""
    
    def __init__(self, max_retries: int = 3, retry_delay: int = 5):
        self.resolve = None
        self.project = None
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self._setup_api_path()
    
    def _setup_api_path(self):
        """Add Resolve scripting path"""
        resolve_script_path = '/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules'
        if resolve_script_path not in sys.path:
            sys.path.append(resolve_script_path)
    
    def connect(self) -> bool:
        """Connect to Resolve with retry logic"""
        for attempt in range(self.max_retries):
            try:
                import DaVinciResolveScript as dvr
                self.resolve = dvr.scriptapp("Resolve")
                
                if self.resolve:
                    self.project = self.resolve.GetProjectManager().GetCurrentProject()
                    if self.project:
                        logger.info(f"Connected to Resolve project: {self.project.GetName()}")
                        return True
                    else:
                        logger.warning("Connected to Resolve but no project is open")
                        return False
            
            except Exception as e:
                logger.error(f"Resolve connection attempt {attempt + 1} failed: {str(e)}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)
        
        return False
    
    def ensure_connection(self) -> bool:
        """Ensure we have a valid connection, reconnect if needed"""
        if not self.resolve or not self.project:
            return self.connect()
        
        # Test if connection is still valid
        try:
            _ = self.project.GetName()
            return True
        except:
            logger.warning("Lost connection to Resolve, attempting reconnect...")
            return self.connect()
    
    def execute_with_retry(self, func: Callable, *args, **kwargs) -> Any:
        """Execute a Resolve API function with automatic retry on failure"""
        for attempt in range(self.max_retries):
            if not self.ensure_connection():
                raise Exception("Cannot establish connection to Resolve")
            
            try:
                return func(*args, **kwargs)
            except Exception as e:
                logger.error(f"Resolve API call failed (attempt {attempt + 1}): {str(e)}")
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)
                else:
                    raise


class PipelineExecutor:
    """Executes pipeline stages with progress tracking"""
    
    def __init__(self, websocket_manager=None):
        self.ws_manager = websocket_manager
        self.resolve_manager = ResolveAPIManager()
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.active_tasks = {}
    
    async def execute_pipeline(self, task_id: str, input_file: str, options: Dict[str, Any]):
        """Execute the full pipeline with progress tracking"""
        
        progress = TaskProgress(
            task_id=task_id,
            status=TaskStatus.VALIDATING,
            stage=None,
            progress=0.0,
            message="Validating configuration...",
            started_at=datetime.now(),
            updated_at=datetime.now(),
            metadata={"input": input_file, "options": options}
        )
        
        self.active_tasks[task_id] = progress
        await self._broadcast_progress(progress)
        
        # Validation phase
        validation_errors = []
        
        # Validate input
        input_validation = ConfigValidator.validate_input_file(input_file)
        validation_errors.extend(input_validation.get('errors', []))
        
        # Validate B-roll config if B-roll is enabled
        if options.get('enable_broll', True):
            broll_validation = ConfigValidator.validate_broll_config()
            validation_errors.extend(broll_validation.get('errors', []))
        
        # Validate Resolve connection
        resolve_validation = ConfigValidator.validate_resolve_connection()
        validation_errors.extend(resolve_validation.get('errors', []))
        
        if validation_errors:
            progress.status = TaskStatus.FAILED
            progress.error = "Validation failed: " + "; ".join(validation_errors)
            await self._broadcast_progress(progress)
            return
        
        # Start pipeline execution
        progress.status = TaskStatus.RUNNING
        progress.message = "Starting pipeline..."
        await self._broadcast_progress(progress)
        
        stages = [
            (StageType.SILENCE_REMOVAL, self._run_silence_removal, 0.15),
            (StageType.SCENE_DETECTION, self._run_scene_detection, 0.10),
            (StageType.TRANSCRIPTION, self._run_transcription, 0.10),
            (StageType.BROLL_INDEXING, self._run_broll_indexing, 0.10),
            (StageType.TIMELINE_BUILD, self._run_timeline_build, 0.15),
            (StageType.BROLL_SELECTION, self._run_broll_selection, 0.10),
            (StageType.CAPTION_GENERATION, self._run_caption_generation, 0.10),
            (StageType.AUDIO_PROCESSING, self._run_audio_processing, 0.05),
            (StageType.RENDERING, self._run_rendering, 0.10),
            (StageType.QC_CHECK, self._run_qc_check, 0.05)
        ]
        
        cumulative_progress = 0.0
        
        for stage_type, stage_func, stage_weight in stages:
            if progress.status == TaskStatus.CANCELLED:
                break
            
            progress.stage = stage_type
            progress.message = f"Running {stage_type.value.replace('_', ' ').title()}..."
            await self._broadcast_progress(progress)
            
            try:
                # Run stage with retry logic
                success = await self._run_with_retry(
                    stage_func, task_id, input_file, options, progress
                )
                
                if not success:
                    raise Exception(f"Stage {stage_type.value} failed")
                
                cumulative_progress += stage_weight
                progress.progress = cumulative_progress
                await self._broadcast_progress(progress)
            
            except Exception as e:
                logger.error(f"Stage {stage_type.value} failed: {str(e)}")
                progress.status = TaskStatus.FAILED
                progress.error = str(e)
                await self._broadcast_progress(progress)
                return
        
        # Pipeline completed
        progress.status = TaskStatus.COMPLETED
        progress.progress = 1.0
        progress.message = "Pipeline completed successfully!"
        await self._broadcast_progress(progress)
    
    async def _run_with_retry(self, func: Callable, *args, max_retries: int = 3) -> bool:
        """Run a function with retry logic"""
        progress = args[-1]  # Last argument is progress object
        
        for attempt in range(max_retries):
            try:
                result = await func(*args[:-1])  # Don't pass progress to function
                return result
            except Exception as e:
                logger.error(f"Attempt {attempt + 1} failed: {str(e)}")
                if attempt < max_retries - 1:
                    progress.status = TaskStatus.RETRYING
                    progress.retry_count = attempt + 1
                    progress.message = f"Retrying... (attempt {attempt + 2}/{max_retries})"
                    await self._broadcast_progress(progress)
                    await asyncio.sleep(5)  # Wait before retry
                else:
                    raise
        
        return False
    
    async def _run_silence_removal(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Run Auto-Editor for silence removal"""
        cmd = ['bash', 'scripts/ae_silence.sh', input_file]
        return await self._run_subprocess(cmd, task_id, "silence_removal")
    
    async def _run_scene_detection(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Run PySceneDetect"""
        cmd = ['bash', 'scripts/psd_scenes.sh', input_file]
        return await self._run_subprocess(cmd, task_id, "scene_detection")
    
    async def _run_transcription(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Run Whisper transcription if enabled"""
        if not options.get('enable_captions', True):
            return True
        
        cmd = ['python3', 'tools/transcribe_fastwhisper.py', input_file]
        return await self._run_subprocess(cmd, task_id, "transcription")
    
    async def _run_broll_indexing(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Index B-roll footage"""
        if not options.get('enable_broll', True):
            return True
        
        cmd = ['python3', '-m', 'broll.index']
        return await self._run_subprocess(cmd, task_id, "broll_indexing")
    
    async def _run_timeline_build(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Build timeline in Resolve"""
        # This would call your resolve_api modules
        # For now, simulate with a subprocess
        cmd = ['python3', '-m', 'resolve_api.timeline_ops', 'build', input_file]
        return await self._run_subprocess(cmd, task_id, "timeline_build")
    
    async def _run_broll_selection(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Select and place B-roll"""
        if not options.get('enable_broll', True):
            return True
        
        cmd = ['python3', '-m', 'broll.assemble', task_id]
        return await self._run_subprocess(cmd, task_id, "broll_selection")
    
    async def _run_caption_generation(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Generate captions in Resolve"""
        if not options.get('enable_captions', True):
            return True
        
        cmd = ['python3', '-m', 'resolve_api.captions_ops', 'generate', task_id]
        return await self._run_subprocess(cmd, task_id, "caption_generation")
    
    async def _run_audio_processing(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Apply audio processing"""
        if not options.get('enable_audio_enhancement', True):
            return True
        
        cmd = ['python3', '-m', 'resolve_api.audio_ops', 'process', task_id]
        return await self._run_subprocess(cmd, task_id, "audio_processing")
    
    async def _run_rendering(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Render all formats"""
        formats = options.get('export_formats', ['youtube', 'tiktok', 'instagram'])
        
        for format_name in formats:
            cmd = ['python3', '-m', 'resolve_api.render_ops', 'render', task_id, format_name]
            success = await self._run_subprocess(cmd, task_id, f"rendering_{format_name}")
            if not success:
                return False
        
        return True
    
    async def _run_qc_check(self, task_id: str, input_file: str, options: Dict) -> bool:
        """Run quality checks"""
        cmd = ['make', 'qc']
        return await self._run_subprocess(cmd, task_id, "qc_check")
    
    async def _run_subprocess(self, cmd: List[str], task_id: str, stage_name: str) -> bool:
        """Run a subprocess command with output capture"""
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                logger.error(f"Command failed: {' '.join(cmd)}")
                logger.error(f"Error: {stderr.decode()}")
                return False
            
            logger.info(f"Stage {stage_name} completed successfully")
            return True
        
        except Exception as e:
            logger.error(f"Failed to run command: {str(e)}")
            return False
    
    async def _broadcast_progress(self, progress: TaskProgress):
        """Send progress update to all connected clients"""
        if self.ws_manager:
            await self.ws_manager.broadcast(progress.to_dict())
    
    def cancel_task(self, task_id: str):
        """Cancel a running task"""
        if task_id in self.active_tasks:
            self.active_tasks[task_id].status = TaskStatus.CANCELLED


class WebSocketManager:
    """Manages WebSocket connections for real-time updates"""
    
    def __init__(self):
        self.websockets = set()
    
    def add_client(self, ws):
        self.websockets.add(ws)
    
    def remove_client(self, ws):
        self.websockets.discard(ws)
    
    async def broadcast(self, data: Dict):
        """Broadcast message to all connected clients"""
        if self.websockets:
            message = json.dumps(data)
            await asyncio.gather(
                *[ws.send_str(message) for ws in self.websockets],
                return_exceptions=True
            )


class BackendServer:
    """Main backend server with REST API and WebSocket support"""
    
    def __init__(self):
        self.app = web.Application()
        self.ws_manager = WebSocketManager()
        self.executor = PipelineExecutor(self.ws_manager)
        self.setup_routes()
        self.setup_cors()
    
    def setup_routes(self):
        """Setup REST API routes"""
        self.app.router.add_get('/ws', self.websocket_handler)
        self.app.router.add_post('/api/validate', self.validate_config)
        self.app.router.add_post('/api/pipeline/start', self.start_pipeline)
        self.app.router.add_post('/api/pipeline/cancel/{task_id}', self.cancel_pipeline)
        self.app.router.add_get('/api/pipeline/status/{task_id}', self.get_status)
        self.app.router.add_get('/api/projects', self.get_resolve_projects)
        self.app.router.add_get('/api/presets', self.get_presets)
        self.app.router.add_post('/api/presets', self.save_preset)
    
    def setup_cors(self):
        """Setup CORS for development"""
        cors = aiohttp_cors.setup(self.app, defaults={
            "*": aiohttp_cors.ResourceOptions(
                allow_credentials=True,
                expose_headers="*",
                allow_headers="*",
                allow_methods="*"
            )
        })
        
        for route in list(self.app.router.routes()):
            cors.add(route)
    
    async def websocket_handler(self, request):
        """Handle WebSocket connections"""
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        self.ws_manager.add_client(ws)
        
        try:
            async for msg in ws:
                if msg.type == WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    # Handle incoming messages if needed
                elif msg.type == WSMsgType.ERROR:
                    logger.error(f'WebSocket error: {ws.exception()}')
        finally:
            self.ws_manager.remove_client(ws)
        
        return ws
    
    async def validate_config(self, request):
        """Validate configuration endpoint"""
        data = await request.json()
        
        results = {
            'input': ConfigValidator.validate_input_file(data.get('input_file', '')),
            'broll': ConfigValidator.validate_broll_config(),
            'resolve': ConfigValidator.validate_resolve_connection()
        }
        
        return web.json_response(results)
    
    async def start_pipeline(self, request):
        """Start pipeline execution"""
        data = await request.json()
        
        task_id = hashlib.md5(f"{data['input_file']}_{time.time()}".encode()).hexdigest()[:8]
        
        # Start pipeline in background
        asyncio.create_task(
            self.executor.execute_pipeline(
                task_id,
                data['input_file'],
                data.get('options', {})
            )
        )
        
        return web.json_response({'task_id': task_id})
    
    async def cancel_pipeline(self, request):
        """Cancel running pipeline"""
        task_id = request.match_info['task_id']
        self.executor.cancel_task(task_id)
        return web.json_response({'status': 'cancelled'})
    
    async def get_status(self, request):
        """Get pipeline status"""
        task_id = request.match_info['task_id']
        
        if task_id in self.executor.active_tasks:
            return web.json_response(self.executor.active_tasks[task_id].to_dict())
        else:
            return web.json_response({'error': 'Task not found'}, status=404)
    
    async def get_resolve_projects(self, request):
        """Get list of Resolve projects"""
        # This would connect to Resolve and get project list
        # Simplified for now
        return web.json_response({
            'projects': ['Project 1', 'Project 2', 'Project 3']
        })
    
    async def get_presets(self, request):
        """Get available presets"""
        presets_dir = Path('presets/render')
        presets = []
        
        for preset_file in presets_dir.glob('*.json'):
            with open(preset_file) as f:
                preset = json.load(f)
                preset['id'] = preset_file.stem
                presets.append(preset)
        
        return web.json_response({'presets': presets})
    
    async def save_preset(self, request):
        """Save a new preset"""
        data = await request.json()
        preset_name = data.get('name', 'custom')
        
        preset_path = Path(f'presets/render/{preset_name}.json')
        with open(preset_path, 'w') as f:
            json.dump(data['settings'], f, indent=2)
        
        return web.json_response({'status': 'saved', 'path': str(preset_path)})
    
    def run(self, host='localhost', port=8080):
        """Start the server"""
        logger.info(f"Starting backend server on http://{host}:{port}")
        web.run_app(self.app, host=host, port=port)


if __name__ == '__main__':
    server = BackendServer()
    server.run()