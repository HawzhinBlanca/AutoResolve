"""JSONL structured logging for pro-auto-editor pipeline."""
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional


class JSONLLogger:
    """Structured logging to JSONL format."""
    
    def __init__(self, log_file: Optional[Path] = None):
        """Initialize logger with optional file output."""
        self.log_file = log_file
        if log_file:
            log_file.parent.mkdir(parents=True, exist_ok=True)
    
    def _format_entry(self, level: str, event: str, **kwargs) -> Dict[str, Any]:
        """Format a log entry."""
        entry = {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'level': level,
            'event': event
        }
        if kwargs:
            entry['data'] = kwargs
        return entry
    
    def _write(self, entry: Dict[str, Any]) -> None:
        """Write entry to file and/or stdout."""
        line = json.dumps(entry, separators=(',', ':'))
        
        # Always write to stdout
        print(line, file=sys.stderr)
        
        # Optionally write to file
        if self.log_file:
            with open(self.log_file, 'a') as f:
                f.write(line + '\n')
    
    def info(self, event: str, **kwargs) -> None:
        """Log info level event."""
        self._write(self._format_entry('INFO', event, **kwargs))
    
    def error(self, event: str, **kwargs) -> None:
        """Log error level event."""
        self._write(self._format_entry('ERROR', event, **kwargs))
    
    def debug(self, event: str, **kwargs) -> None:
        """Log debug level event."""
        self._write(self._format_entry('DEBUG', event, **kwargs))
    
    def metric(self, event: str, **kwargs) -> None:
        """Log metric/measurement event."""
        self._write(self._format_entry('METRIC', event, **kwargs))


# Global logger instance
_logger: Optional[JSONLLogger] = None


def get_logger() -> JSONLLogger:
    """Get or create global logger instance."""
    global _logger
    if _logger is None:
        # Default to logging to artifacts/logs/pipeline.jsonl
        log_dir = Path(__file__).resolve().parents[1] / 'artifacts' / 'logs'
        _logger = JSONLLogger(log_dir / 'pipeline.jsonl')
    return _logger


def set_logger(logger: JSONLLogger) -> None:
    """Set global logger instance."""
    global _logger
    _logger = logger