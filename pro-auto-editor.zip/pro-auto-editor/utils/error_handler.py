"""Comprehensive error handling for pro-auto-editor pipeline."""
from __future__ import annotations
import sys
import time
import asyncio
import traceback
from enum import Enum
from pathlib import Path
from typing import Optional, Any, Callable, Union
from functools import wraps

from .jsonl_logger import get_logger


class ErrorCategory(Enum):
    """Error categories for classification."""
    DEPENDENCY_MISSING = "dependency_missing"
    API_FAILURE = "api_failure"
    FILE_NOT_FOUND = "file_not_found"
    INVALID_FORMAT = "invalid_format"
    PERMISSION_DENIED = "permission_denied"
    RESOLVE_CONNECTION = "resolve_connection"
    MEDIA_IMPORT = "media_import"
    RENDER_FAILURE = "render_failure"
    PIPELINE_STATE = "pipeline_state"
    UNKNOWN = "unknown"


class PipelineError(Exception):
    """Base exception for pipeline errors."""
    
    def __init__(self, message: str, category: ErrorCategory = ErrorCategory.UNKNOWN, details: Optional[dict] = None):
        super().__init__(message)
        self.category = category
        self.details = details or {}
        self.log()
    
    def log(self):
        """Log the error to JSONL."""
        logger = get_logger()
        logger.error(
            'pipeline_error',
            category=self.category.value,
            message=str(self),
            details=self.details,
            traceback=traceback.format_exc()
        )


def handle_resolve_errors(func: Callable) -> Callable:
    """Decorator to handle Resolve API errors with proper logging."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ImportError as e:
            if 'pydavinci' in str(e) or 'DaVinciResolveScript' in str(e):
                raise PipelineError(
                    "DaVinci Resolve API not available. Ensure Resolve is installed and pydavinci==0.2.2 is installed.",
                    ErrorCategory.DEPENDENCY_MISSING,
                    {'missing': 'pydavinci or DaVinciResolveScript'}
                )
            raise
        except RuntimeError as e:
            if 'connect' in str(e).lower() or 'resolve' in str(e).lower():
                raise PipelineError(
                    f"Failed to connect to DaVinci Resolve: {e}",
                    ErrorCategory.RESOLVE_CONNECTION,
                    {'original_error': str(e)}
                )
            raise
        except Exception as e:
            logger = get_logger()
            logger.error(
                'resolve_api_error',
                function=func.__name__,
                error=str(e),
                traceback=traceback.format_exc()
            )
            raise PipelineError(
                f"Resolve API error in {func.__name__}: {e}",
                ErrorCategory.API_FAILURE
            )
    return wrapper


def handle_file_operations(func: Callable) -> Callable:
    """Decorator to handle file operation errors."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except FileNotFoundError as e:
            path = kwargs.get('path') or (args[0] if args else 'unknown')
            raise PipelineError(
                f"File not found: {path}",
                ErrorCategory.FILE_NOT_FOUND,
                {'path': str(path)}
            )
        except PermissionError as e:
            path = kwargs.get('path') or (args[0] if args else 'unknown')
            raise PipelineError(
                f"Permission denied: {path}",
                ErrorCategory.PERMISSION_DENIED,
                {'path': str(path)}
            )
        except (IOError, OSError) as e:
            logger = get_logger()
            logger.error(
                'file_operation_error',
                function=func.__name__,
                error=str(e)
            )
            raise
    return wrapper


def with_retry(max_retries: int = 3, delay: float = 1.0, exponential_backoff: bool = True, 
               exceptions: tuple = (Exception,)) -> Callable:
    """General-purpose retry decorator for any function.
    
    Args:
        max_retries: Maximum number of retry attempts
        delay: Base delay between retries in seconds
        exponential_backoff: Whether to use exponential backoff
        exceptions: Tuple of exception types to retry on
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            logger = get_logger()
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        retry_delay = delay * (2 ** attempt) if exponential_backoff else delay
                        logger.warning(
                            'function_retry_attempt',
                            function=func.__name__,
                            attempt=attempt + 1,
                            max_retries=max_retries,
                            error=str(e),
                            retry_delay=retry_delay
                        )
                        time.sleep(retry_delay)
                        continue
                    else:
                        logger.error(
                            'function_retry_exhausted',
                            function=func.__name__,
                            attempts=max_retries,
                            final_error=str(e)
                        )
                        break
            
            raise last_exception
        
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            logger = get_logger()
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        retry_delay = delay * (2 ** attempt) if exponential_backoff else delay
                        logger.warning(
                            'async_function_retry_attempt',
                            function=func.__name__,
                            attempt=attempt + 1,
                            max_retries=max_retries,
                            error=str(e),
                            retry_delay=retry_delay
                        )
                        await asyncio.sleep(retry_delay)
                        continue
                    else:
                        logger.error(
                            'async_function_retry_exhausted',
                            function=func.__name__,
                            attempts=max_retries,
                            final_error=str(e)
                        )
                        break
            
            raise last_exception
        
        # Return the appropriate wrapper based on whether the function is async
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


def with_pipeline_retry(max_retries: int = 3, delay: float = 5.0) -> Callable:
    """Specialized retry decorator for pipeline operations with proper error categorization."""
    return with_retry(
        max_retries=max_retries,
        delay=delay,
        exponential_backoff=True,
        exceptions=(Exception,)  # Catch all exceptions for pipeline operations
    )


def validate_requirements() -> bool:
    """Validate all required dependencies are available."""
    logger = get_logger()
    missing = []
    
    # Check critical imports
    try:
        import auto_editor
        version = getattr(auto_editor, '__version__', 'unknown')
        if version != '24.20.1':
            logger.error('dependency_version_mismatch', package='auto-editor', expected='24.20.1', actual=version)
    except ImportError:
        missing.append('auto-editor')
    
    try:
        import pydavinci
    except ImportError:
        logger.error('dependency_missing', package='pydavinci')
        missing.append('pydavinci')
    
    try:
        import opentimelineio
    except ImportError:
        missing.append('opentimelineio')
    
    try:
        import scenedetect
    except ImportError:
        missing.append('scenedetect')
    
    try:
        import faster_whisper
    except ImportError:
        missing.append('faster-whisper')
    
    try:
        import open_clip
    except ImportError:
        missing.append('open-clip-torch')
    
    if missing:
        raise PipelineError(
            f"Missing required dependencies: {', '.join(missing)}. Run: pip install -r requirements.txt",
            ErrorCategory.DEPENDENCY_MISSING,
            {'missing_packages': missing}
        )
    
    logger.info('dependencies_validated')
    return True


def safe_cleanup(artifacts_dir: Path) -> None:
    """Safely clean up temporary files with error handling."""
    logger = get_logger()
    
    try:
        # Clean up temporary state files
        temp_files = [
            artifacts_dir / 'multicam_state.json',
            artifacts_dir / '.pipeline_lock',
            artifacts_dir / 'temp' / '*'
        ]
        
        for pattern in temp_files:
            if '*' in str(pattern):
                # Glob pattern
                base_dir = pattern.parent
                if base_dir.exists():
                    for file in base_dir.glob(pattern.name):
                        try:
                            if file.is_file():
                                file.unlink()
                        except Exception as e:
                            logger.debug('cleanup_file_failed', file=str(file), error=str(e))
            else:
                # Single file
                if pattern.exists() and pattern.is_file():
                    try:
                        pattern.unlink()
                    except Exception as e:
                        logger.debug('cleanup_file_failed', file=str(pattern), error=str(e))
        
        logger.info('cleanup_completed')
    except Exception as e:
        logger.error('cleanup_failed', error=str(e))
        # Don't raise - cleanup failures shouldn't stop the pipeline


def format_error_message(error: Exception) -> str:
    """Format error message for user display."""
    if isinstance(error, PipelineError):
        msg = f"\n{'='*60}\n"
        msg += f"ERROR: {error.category.value.replace('_', ' ').title()}\n"
        msg += f"{'='*60}\n"
        msg += f"{str(error)}\n"
        
        if error.details:
            msg += "\nDetails:\n"
            for key, value in error.details.items():
                msg += f"  {key}: {value}\n"
        
        msg += f"{'='*60}\n"
        return msg
    else:
        return f"\nERROR: {str(error)}\n"


def setup_error_handler() -> None:
    """Setup global error handler for uncaught exceptions."""
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        
        logger = get_logger()
        logger.error(
            'uncaught_exception',
            type=exc_type.__name__,
            value=str(exc_value),
            traceback=''.join(traceback.format_tb(exc_traceback))
        )
        
        print(format_error_message(exc_value), file=sys.stderr)
    
    sys.excepthook = handle_exception