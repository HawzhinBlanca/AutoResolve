"""Common file validation utilities for pro-auto-editor pipeline."""
from __future__ import annotations
import os
from pathlib import Path
from typing import Dict, Any, Optional, Set
from .error_handler import PipelineError, ErrorCategory


# Default constraints
DEFAULT_MAX_FILE_SIZE = 5 * 1024 * 1024 * 1024  # 5GB
DEFAULT_ALLOWED_VIDEO_EXTENSIONS = {'.mp4', '.mov', '.avi', '.mkv', '.webm', '.m4v'}
DEFAULT_ALLOWED_AUDIO_EXTENSIONS = {'.wav', '.mp3', '.aac', '.m4a', '.flac'}
DEFAULT_ALLOWED_IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
DEFAULT_ALLOWED_TEXT_EXTENSIONS = {'.txt', '.csv', '.json', '.srt', '.vtt', '.otio'}


def validate_file_exists(file_path: Path, description: str = "File") -> None:
    """Validate that a file exists."""
    if not file_path.exists():
        raise PipelineError(
            f"{description} not found: {file_path}",
            ErrorCategory.FILE_NOT_FOUND,
            {'path': str(file_path)}
        )


def validate_file_type(file_path: Path, allowed_extensions: Set[str], 
                      description: str = "File") -> None:
    """Validate file extension against allowed types."""
    if file_path.suffix.lower() not in allowed_extensions:
        raise PipelineError(
            f"{description} has unsupported format: {file_path.suffix}. "
            f"Allowed: {', '.join(sorted(allowed_extensions))}",
            ErrorCategory.INVALID_FORMAT,
            {
                'path': str(file_path),
                'extension': file_path.suffix,
                'allowed_extensions': list(allowed_extensions)
            }
        )


def validate_file_size(file_path: Path, max_size: int = DEFAULT_MAX_FILE_SIZE,
                      description: str = "File") -> int:
    """Validate file size and return size in bytes."""
    file_size = file_path.stat().st_size
    if file_size > max_size:
        max_gb = max_size / (1024**3)
        actual_gb = file_size / (1024**3)
        raise PipelineError(
            f"{description} too large: {actual_gb:.2f}GB (max {max_gb:.1f}GB)",
            ErrorCategory.INVALID_FORMAT,
            {
                'path': str(file_path),
                'size_bytes': file_size,
                'max_size_bytes': max_size,
                'size_gb': actual_gb,
                'max_size_gb': max_gb
            }
        )
    return file_size


def validate_file_readable(file_path: Path, description: str = "File") -> None:
    """Validate that a file is readable."""
    try:
        with open(file_path, 'rb') as f:
            f.read(1)  # Try to read first byte
    except PermissionError:
        raise PipelineError(
            f"{description} permission denied: {file_path}",
            ErrorCategory.PERMISSION_DENIED,
            {'path': str(file_path)}
        )
    except (IOError, OSError) as e:
        raise PipelineError(
            f"{description} read error: {e}",
            ErrorCategory.FILE_NOT_FOUND,
            {'path': str(file_path), 'error': str(e)}
        )


def validate_directory_writable(dir_path: Path, description: str = "Directory") -> None:
    """Validate that a directory exists and is writable."""
    if not dir_path.exists():
        try:
            dir_path.mkdir(parents=True, exist_ok=True)
        except (PermissionError, OSError) as e:
            raise PipelineError(
                f"Cannot create {description.lower()}: {dir_path}",
                ErrorCategory.PERMISSION_DENIED,
                {'path': str(dir_path), 'error': str(e)}
            )
    
    if not dir_path.is_dir():
        raise PipelineError(
            f"{description} is not a directory: {dir_path}",
            ErrorCategory.INVALID_FORMAT,
            {'path': str(dir_path)}
        )
    
    # Test write permission
    test_file = dir_path / '.write_test'
    try:
        test_file.touch()
        test_file.unlink()
    except (PermissionError, OSError) as e:
        raise PipelineError(
            f"{description} is not writable: {dir_path}",
            ErrorCategory.PERMISSION_DENIED,
            {'path': str(dir_path), 'error': str(e)}
        )


def validate_video_file(file_path: Path, max_size: int = DEFAULT_MAX_FILE_SIZE) -> Dict[str, Any]:
    """Comprehensive validation for video files.
    
    Returns:
        Dict with validation results including file size
    """
    validate_file_exists(file_path, "Video file")
    validate_file_type(file_path, DEFAULT_ALLOWED_VIDEO_EXTENSIONS, "Video file")
    file_size = validate_file_size(file_path, max_size, "Video file")
    validate_file_readable(file_path, "Video file")
    
    return {
        'valid': True,
        'path': str(file_path),
        'size': file_size,
        'extension': file_path.suffix.lower()
    }


def validate_audio_file(file_path: Path, max_size: int = DEFAULT_MAX_FILE_SIZE) -> Dict[str, Any]:
    """Comprehensive validation for audio files."""
    validate_file_exists(file_path, "Audio file")
    validate_file_type(file_path, DEFAULT_ALLOWED_AUDIO_EXTENSIONS, "Audio file")
    file_size = validate_file_size(file_path, max_size, "Audio file")
    validate_file_readable(file_path, "Audio file")
    
    return {
        'valid': True,
        'path': str(file_path),
        'size': file_size,
        'extension': file_path.suffix.lower()
    }


def validate_text_file(file_path: Path, max_size: int = 50 * 1024 * 1024) -> Dict[str, Any]:
    """Comprehensive validation for text files (smaller default max size)."""
    validate_file_exists(file_path, "Text file")
    validate_file_type(file_path, DEFAULT_ALLOWED_TEXT_EXTENSIONS, "Text file")
    file_size = validate_file_size(file_path, max_size, "Text file")
    validate_file_readable(file_path, "Text file")
    
    return {
        'valid': True,
        'path': str(file_path),
        'size': file_size,
        'extension': file_path.suffix.lower()
    }


def validate_input_output_pair(input_path: Path, output_path: Path) -> None:
    """Validate input file exists and output directory is writable."""
    validate_file_exists(input_path, "Input file")
    validate_file_readable(input_path, "Input file")
    
    # Ensure output directory exists and is writable
    output_dir = output_path.parent
    validate_directory_writable(output_dir, "Output directory")


def validate_workspace(workspace_dir: Path, required_subdirs: Optional[list] = None) -> None:
    """Validate workspace directory structure."""
    validate_directory_writable(workspace_dir, "Workspace directory")
    
    # Create required subdirectories
    if required_subdirs:
        for subdir in required_subdirs:
            subdir_path = workspace_dir / subdir
            validate_directory_writable(subdir_path, f"Subdirectory '{subdir}'")


def get_file_info(file_path: Path) -> Dict[str, Any]:
    """Get comprehensive file information."""
    if not file_path.exists():
        return {'exists': False, 'path': str(file_path)}
    
    stat = file_path.stat()
    
    return {
        'exists': True,
        'path': str(file_path),
        'name': file_path.name,
        'stem': file_path.stem,
        'suffix': file_path.suffix,
        'size': stat.st_size,
        'size_mb': stat.st_size / (1024 * 1024),
        'size_gb': stat.st_size / (1024 * 1024 * 1024),
        'is_file': file_path.is_file(),
        'is_dir': file_path.is_dir(),
        'modified': stat.st_mtime,
        'created': stat.st_ctime,
        'readable': os.access(file_path, os.R_OK),
        'writable': os.access(file_path, os.W_OK),
        'executable': os.access(file_path, os.X_OK)
    }