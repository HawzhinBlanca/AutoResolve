"""Central constants for pro-auto-editor pipeline."""
from pathlib import Path
from typing import Dict, Set

# Version and app info
APP_NAME = "Pro Auto Editor"
APP_VERSION = "1.0.0"

# File size limits (in bytes)
MAX_VIDEO_FILE_SIZE = 5 * 1024 * 1024 * 1024  # 5GB
MAX_AUDIO_FILE_SIZE = 1 * 1024 * 1024 * 1024   # 1GB  
MAX_TEXT_FILE_SIZE = 50 * 1024 * 1024          # 50MB
UPLOAD_CHUNK_SIZE = 1024 * 1024                # 1MB chunks

# Allowed file extensions
ALLOWED_VIDEO_EXTENSIONS = {'.mp4', '.mov', '.avi', '.mkv', '.webm', '.m4v'}
ALLOWED_AUDIO_EXTENSIONS = {'.wav', '.mp3', '.aac', '.m4a', '.flac'}
ALLOWED_IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
ALLOWED_TEXT_EXTENSIONS = {'.txt', '.csv', '.json', '.srt', '.vtt', '.otio'}

# Processing limits and timeouts
MAX_CONCURRENT_JOBS = 3
JOB_TIMEOUT = 3600                    # 1 hour in seconds
STAGE_TIMEOUT = 1800                  # 30 minutes in seconds
HEALTH_CHECK_INTERVAL = 30            # seconds
POLL_INTERVAL = 2.0                   # seconds
RENDER_TIMEOUT = 36000.0              # 10 hours in seconds

# Retry configuration
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY = 1.0             # seconds
PIPELINE_RETRY_DELAY = 5.0            # seconds for pipeline operations
RESOLVE_MAX_RETRIES = 3
RESOLVE_RETRY_DELAY = 2.0             # seconds
RESOLVE_CONNECTION_TIMEOUT = 30.0     # seconds

# Directory paths
DB_PATH = Path('data/jobs.db')
TEMP_DIR = Path('temp')
UPLOAD_DIR = Path('uploads')
LOGS_DIR = Path('logs')
ARTIFACTS_DIR = Path('artifacts')
CACHE_DIR = Path('cache')

# Required directories for workspace setup
REQUIRED_DIRECTORIES = [
    'data', 'temp', 'uploads', 'logs', 'artifacts', 'cache'
]

# Video processing constants
DEFAULT_FPS = 30.0
THUMBNAIL_FRAME_COUNT = 9             # for smart crop analysis
DEFAULT_VIDEO_PROFILE = '16x9'
ASPECT_RATIOS = {
    '16x9': (1920, 1080),
    '9x16': (1080, 1920),
    '1x1': (1080, 1080),
    '4x3': (1440, 1080),
}

# Render presets and formats
DEFAULT_RENDER_FORMAT = 'mp4'
DEFAULT_RENDER_CODEC = 'H.264'
RENDER_PROFILES = {
    'youtube': 'YouTube_1080p.json',
    'tiktok': 'TikTok_1080x1920.json', 
    'square': 'Square_1080.json'
}

# ML/AI model configuration
BROLL_EMBEDDING_MODEL = "ViT-H-14"
BROLL_MODEL_PRETRAINED = "laion2b_s32b_b79k"
MAX_KEYFRAMES_PER_CLIP = 30
BROLL_WEIGHTS = {
    'semantic': 0.55,
    'diversity': 0.20,
    'duration_fit': 0.15,
    'freshness': 0.10
}

# Audio processing
DEFAULT_AUDIO_LANGUAGE = 'en'
AUDIO_TRACK_INDEX = 1
AUDIO_SAMPLE_RATE = 44100
AUDIO_CHANNELS = 2

# Performance and optimization
CPU_COUNT_MULTIPLIER = 2             # for worker process calculation
MEMORY_BUFFER_SIZE = 1024 * 1024     # 1MB buffer for file operations
BATCH_SIZE = 100                     # for batch processing operations

# Logging configuration
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
LOG_LEVEL = 'INFO'
MAX_LOG_SIZE = 10 * 1024 * 1024      # 10MB
LOG_BACKUP_COUNT = 5

# Web server configuration
DEFAULT_HOST = '0.0.0.0'
DEFAULT_PORT = 8080
CORS_ORIGINS = ['http://localhost:3000', 'http://localhost:8080']
SESSION_TIMEOUT = 3600               # 1 hour

# Database configuration
DB_TIMEOUT = 30.0                    # seconds
MAX_DB_CONNECTIONS = 10

# Error handling
MAX_ERROR_TRACEBACK_LENGTH = 5000    # characters
ERROR_REPORT_RETENTION_DAYS = 30

# Security
SECRET_KEY_LENGTH = 32               # bytes
TOKEN_EXPIRY_HOURS = 24
RATE_LIMIT_REQUESTS = 100            # per minute
RATE_LIMIT_WINDOW = 60               # seconds

# Environment variable names
ENV_VARS = {
    'RESOLVE_SCRIPT_API': 'RESOLVE_SCRIPT_API',
    'LOG_LEVEL': 'LOG_LEVEL',
    'HOST': 'HOST',
    'PORT': 'PORT',
    'MAX_FILE_SIZE': 'MAX_FILE_SIZE',
    'MAX_CONCURRENT_JOBS': 'MAX_CONCURRENT_JOBS',
    'SECRET_KEY': 'SECRET_KEY',
    'DATABASE_URL': 'DATABASE_URL',
}

# Default configuration values that can be overridden by environment
DEFAULT_CONFIG = {
    'host': DEFAULT_HOST,
    'port': DEFAULT_PORT,
    'max_file_size': MAX_VIDEO_FILE_SIZE,
    'max_concurrent_jobs': MAX_CONCURRENT_JOBS,
    'log_level': LOG_LEVEL,
    'job_timeout': JOB_TIMEOUT,
    'health_check_interval': HEALTH_CHECK_INTERVAL,
}

# Status messages and UI strings
STATUS_MESSAGES = {
    'queued': 'Job queued for processing',
    'validating': 'Validating input files',
    'processing': 'Processing video',
    'completed': 'Processing completed successfully',
    'failed': 'Processing failed',
    'cancelled': 'Processing cancelled',
}

ERROR_MESSAGES = {
    'file_not_found': 'File not found: {path}',
    'file_too_large': 'File too large: {size_gb:.2f}GB (max {max_gb}GB)',
    'unsupported_format': 'Unsupported format: {extension}. Allowed: {allowed}',
    'permission_denied': 'Permission denied: {path}',
    'connection_failed': 'Failed to connect to DaVinci Resolve',
    'timeout': 'Operation timed out after {timeout}s',
    'validation_failed': 'File validation failed: {reason}',
}

# Pipeline stage names
PIPELINE_STAGES = {
    'validation': 'File Validation',
    'transcription': 'Audio Transcription', 
    'scene_detection': 'Scene Detection',
    'broll_selection': 'B-Roll Selection',
    'timeline_creation': 'Timeline Creation',
    'rendering': 'Video Rendering',
    'cleanup': 'Cleanup',
}

# File naming patterns
TEMP_FILE_PREFIX = 'tmp_'
OUTPUT_FILE_PREFIX = 'output_'
BACKUP_FILE_SUFFIX = '.backup'
LOG_FILE_SUFFIX = '.log'