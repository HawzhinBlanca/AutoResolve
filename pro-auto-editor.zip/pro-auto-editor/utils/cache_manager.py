"""
Cache management for ML models and embeddings
Provides lazy loading and persistent caching for performance optimization
"""

import hashlib
import pickle
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
import numpy as np
import logging

logger = logging.getLogger(__name__)

class ModelManager:
    """Singleton manager for ML model caching."""
    _instance = None
    _models: Dict[str, Any] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def get_model(self, model_name: str, cache_dir: Optional[Path] = None):
        """Get a cached model or load it if not cached."""
        if model_name not in self._models:
            self._models[model_name] = self._load_model(model_name, cache_dir)
            logger.info(f"Model loaded and cached: {model_name}")
        return self._models[model_name]
    
    def _load_model(self, model_name: str, cache_dir: Optional[Path] = None):
        """Load model (implementation depends on model type)."""
        import open_clip
        
        if cache_dir:
            cache_dir = Path(cache_dir)
        else:
            cache_dir = Path.home() / '.cache' / 'autoresolve'
        
        cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Load OpenCLIP model
        model, _, preprocess = open_clip.create_model_and_transforms(
            model_name,
            pretrained='openai',
            cache_dir=str(cache_dir)
        )
        
        return {
            'model': model,
            'preprocess': preprocess,
            'name': model_name
        }
    
    def clear_cache(self):
        """Clear all cached models."""
        self._models.clear()
        logger.info("Model cache cleared")


class EmbeddingCache:
    """Persistent cache for computed embeddings."""
    
    def __init__(self, cache_dir: Optional[Path] = None):
        if cache_dir:
            self.cache_dir = Path(cache_dir)
        else:
            self.cache_dir = Path.home() / '.cache' / 'autoresolve' / 'embeddings'
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def _generate_key(self, video_path: str, model_name: str, frame_sample_rate: int = 1) -> str:
        """Generate unique cache key for an embedding."""
        key_str = f"{video_path}:{model_name}:{frame_sample_rate}"
        return hashlib.sha256(key_str.encode()).hexdigest()
    
    def get(self, video_path: str, model_name: str, frame_sample_rate: int = 1) -> Optional[np.ndarray]:
        """Get cached embedding if it exists."""
        cache_key = self._generate_key(video_path, model_name, frame_sample_rate)
        cache_file = self.cache_dir / f"{cache_key}.npy"
        
        if cache_file.exists():
            try:
                embedding = np.load(cache_file)
                logger.debug(f"Cache hit for {video_path}")
                return embedding
            except Exception as e:
                logger.warning(f"Failed to load cached embedding: {e}")
                return None
        return None
    
    def set(self, video_path: str, model_name: str, embedding: np.ndarray, frame_sample_rate: int = 1):
        """Save embedding to cache."""
        cache_key = self._generate_key(video_path, model_name, frame_sample_rate)
        cache_file = self.cache_dir / f"{cache_key}.npy"
        
        try:
            np.save(cache_file, embedding)
            logger.debug(f"Cached embedding for {video_path}")
        except Exception as e:
            logger.warning(f"Failed to cache embedding: {e}")
    
    def clear(self):
        """Clear all cached embeddings."""
        for cache_file in self.cache_dir.glob("*.npy"):
            try:
                cache_file.unlink()
            except Exception as e:
                logger.warning(f"Failed to delete cache file {cache_file}: {e}")
        logger.info("Embedding cache cleared")
    
    def get_cache_size(self) -> int:
        """Get total size of cache in bytes."""
        total_size = 0
        for cache_file in self.cache_dir.glob("*.npy"):
            total_size += cache_file.stat().st_size
        return total_size
    
    def get_cache_info(self) -> Dict[str, Any]:
        """Get cache statistics."""
        files = list(self.cache_dir.glob("*.npy"))
        total_size = sum(f.stat().st_size for f in files)
        
        return {
            'cache_dir': str(self.cache_dir),
            'num_cached': len(files),
            'total_size_mb': total_size / (1024 * 1024),
            'files': [f.name for f in files[:10]]  # First 10 files
        }


# Global instances
model_manager = ModelManager()
embedding_cache = EmbeddingCache()