from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


@dataclass
class BrollConfig:
    k: int = 8
    score_threshold: float = 0.72
    diversity_lambda: float = 0.6
    no_repeat_window: int = 3
    cross_dissolve_frames: int = 6
    per_clip_seconds: float = 3.0


@dataclass
class RenderConfig:
    duration_s: float = 90.0
    start_s: Optional[float] = None


@dataclass
class AudioConfig:
    voice_isolation_percent: Optional[int] = 70
    dialogue_leveler: bool = True


@dataclass
class CaptionsConfig:
    font: str = "Arial"
    size: int = 60
    color: str = "#FFFFFF"
    outline_color: str = "#000000"
    outline_width: int = 2
    box_opacity: float = 0.75
    box_color: str = "#000000"
    max_lines: int = 2
    align: str = "bottom"
    safe_margin_percent: float = 10.0
    fade_frames: int = 6


@dataclass
class ROIConfig:
    enable_smart_crop: bool = False
    zoom: float = 1.25
    offset_scale: float = 0.4


@dataclass
class IndexerConfig:
    sample_fps: int = 1
    max_keyframes_per_clip: int = 30
    embedding_model: str = "ViT-H-14"


@dataclass
class QCConfig:
    min_cover_ratio: float = 0.25
    max_cover_ratio: float = 0.55


@dataclass
class ProjectConfig:
    media_root: Optional[str]
    output_root: Optional[str]
    broll: BrollConfig
    render: RenderConfig
    audio: AudioConfig
    captions: CaptionsConfig
    roi: ROIConfig
    indexer: IndexerConfig
    qc: QCConfig


def _get_nested(d: Dict[str, Any], key: str, default: Any) -> Any:
    value = d.get(key, None)
    if value is None:
        return default
    return value


def load_project_config(path: Path) -> ProjectConfig:
    data: Dict[str, Any] = {}
    if path.exists():
        try:
            data = yaml.safe_load(path.read_text()) or {}
        except Exception:
            data = {}

    # Map existing keys from repo file to new structured config with safe defaults
    media_root = data.get('media_root')
    output_root = data.get('output_root')

    broll_dict: Dict[str, Any] = data.get('broll', {}) or {}
    broll_cfg = BrollConfig(
        k=int(broll_dict.get('k', 8)),
        score_threshold=float(broll_dict.get('score_threshold', broll_dict.get('threshold', 0.72))),
        diversity_lambda=float(broll_dict.get('diversity_lambda', 0.6)),
        no_repeat_window=int(broll_dict.get('no_repeat_window', 3)),
        cross_dissolve_frames=int(broll_dict.get('cross_dissolve_frames', 6)),
        per_clip_seconds=float(broll_dict.get('per_clip_seconds', 3.0)),
    )

    render_dict: Dict[str, Any] = data.get('render', {}) or {}
    # Back-compat: read exports duration from top-level if not present
    render_cfg = RenderConfig(
        duration_s=float(render_dict.get('duration_s', 90.0)),
        start_s=render_dict.get('start_s'),
    )

    audio_dict: Dict[str, Any] = data.get('audio', {}) or {}
    # Back-compat: top-level voice_isolation_percent present in repo
    audio_cfg = AudioConfig(
        voice_isolation_percent=int(audio_dict.get('voice_isolation_percent', data.get('voice_isolation_percent', 70))) if audio_dict.get('voice_isolation_percent', data.get('voice_isolation_percent', 70)) is not None else None,
        dialogue_leveler=bool(audio_dict.get('dialogue_leveler', True)),
    )

    captions_dict: Dict[str, Any] = data.get('captions', {}) or {}
    captions_cfg = CaptionsConfig(
        font=str(captions_dict.get('font', 'Arial')),
        size=int(captions_dict.get('size', 60)),
        color=str(captions_dict.get('color', '#FFFFFF')),
        outline_color=str(captions_dict.get('outline_color', '#000000')),
        outline_width=int(captions_dict.get('outline_width', 2)),
        box_opacity=float(captions_dict.get('box_opacity', 0.75)),
        box_color=str(captions_dict.get('box_color', '#000000')),
        max_lines=int(captions_dict.get('max_lines', 2)),
        align=str(captions_dict.get('align', 'bottom')),
        safe_margin_percent=float(captions_dict.get('safe_margin_percent', 10.0)),
        fade_frames=int(captions_dict.get('fade_frames', 6)),
    )

    roi_dict: Dict[str, Any] = data.get('roi', {}) or {}
    roi_cfg = ROIConfig(
        enable_smart_crop=bool(roi_dict.get('enable_smart_crop', False)),
        zoom=float(roi_dict.get('zoom', 1.25)),
        offset_scale=float(roi_dict.get('offset_scale', 0.4)),
    )

    indexer_dict: Dict[str, Any] = data.get('indexer', {}) or {}
    # Back-compat: some keys may live in broll.yaml but allow overrides here
    indexer_cfg = IndexerConfig(
        sample_fps=int(indexer_dict.get('sample_fps', 1)),
        max_keyframes_per_clip=int(indexer_dict.get('max_keyframes_per_clip', 30)),
        embedding_model=str(indexer_dict.get('embedding_model', 'ViT-H-14')),
    )

    qc_dict: Dict[str, Any] = data.get('qc', {}) or {}
    # Back-compat: repo has min/max cover ratio in broll section
    qc_cfg = QCConfig(
        min_cover_ratio=float(qc_dict.get('min_cover_ratio', broll_dict.get('min_cover_ratio', 0.25))),
        max_cover_ratio=float(qc_dict.get('max_cover_ratio', broll_dict.get('max_cover_ratio', 0.55))),
    )

    return ProjectConfig(
        media_root=media_root,
        output_root=output_root,
        broll=broll_cfg,
        render=render_cfg,
        audio=audio_cfg,
        captions=captions_cfg,
        roi=roi_cfg,
        indexer=indexer_cfg,
        qc=qc_cfg,
    )


