#!/usr/bin/env python3
"""
Pro Auto Editor GUI - Quick Launch Interface
A native Python GUI for the Pro Auto Editor pipeline
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
import subprocess
import json
import asyncio
import websockets
from pathlib import Path
import os
import sys

class ProAutoEditorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Pro Auto Editor - Professional Video Automation")
        self.root.geometry("1200x800")
        
        # Variables
        self.input_file = tk.StringVar()
        self.status = tk.StringVar(value="Ready")
        self.progress = tk.DoubleVar()
        
        # Setup UI
        self.setup_ui()
        
        # Start monitoring backend
        self.start_monitoring()
        
    def setup_ui(self):
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Title
        title = ttk.Label(main_frame, text="🎬 Pro Auto Editor", font=('Helvetica', 24, 'bold'))
        title.grid(row=0, column=0, columnspan=3, pady=10)
        
        subtitle = ttk.Label(main_frame, text="Professional Video Automation for DaVinci Resolve", font=('Helvetica', 12))
        subtitle.grid(row=1, column=0, columnspan=3, pady=(0, 20))
        
        # Input Section
        input_frame = ttk.LabelFrame(main_frame, text="Input Video", padding="10")
        input_frame.grid(row=2, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        ttk.Label(input_frame, text="Video File:").grid(row=0, column=0, sticky=tk.W)
        ttk.Entry(input_frame, textvariable=self.input_file, width=60).grid(row=0, column=1, padx=5)
        ttk.Button(input_frame, text="Browse", command=self.browse_file).grid(row=0, column=2)
        
        # Options Section
        options_frame = ttk.LabelFrame(main_frame, text="Pipeline Options", padding="10")
        options_frame.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        # Create notebook for tabs
        notebook = ttk.Notebook(options_frame)
        notebook.grid(row=0, column=0, columnspan=3, sticky=(tk.W, tk.E))
        
        # Editing Tab
        edit_tab = ttk.Frame(notebook)
        notebook.add(edit_tab, text="Editing")
        
        self.remove_silence = tk.BooleanVar(value=True)
        ttk.Checkbutton(edit_tab, text="Remove Silence", variable=self.remove_silence).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        self.detect_scenes = tk.BooleanVar(value=True)
        ttk.Checkbutton(edit_tab, text="Detect Scenes", variable=self.detect_scenes).grid(row=1, column=0, sticky=tk.W, pady=5)
        
        ttk.Label(edit_tab, text="Silence Threshold (dB):").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.silence_threshold = tk.Scale(edit_tab, from_=-60, to=-10, orient=tk.HORIZONTAL, length=200)
        self.silence_threshold.set(-30)
        self.silence_threshold.grid(row=2, column=1, pady=5)
        
        # B-Roll Tab
        broll_tab = ttk.Frame(notebook)
        notebook.add(broll_tab, text="B-Roll")
        
        self.enable_broll = tk.BooleanVar(value=True)
        ttk.Checkbutton(broll_tab, text="Add B-Roll", variable=self.enable_broll).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        ttk.Label(broll_tab, text="Coverage Ratio:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.broll_coverage = tk.Scale(broll_tab, from_=0.1, to=0.6, resolution=0.1, orient=tk.HORIZONTAL, length=200)
        self.broll_coverage.set(0.3)
        self.broll_coverage.grid(row=1, column=1, pady=5)
        
        # Captions Tab
        caption_tab = ttk.Frame(notebook)
        notebook.add(caption_tab, text="Captions")
        
        self.enable_captions = tk.BooleanVar(value=True)
        ttk.Checkbutton(caption_tab, text="Generate Captions", variable=self.enable_captions).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        self.caption_style = tk.StringVar(value="modern")
        ttk.Label(caption_tab, text="Caption Style:").grid(row=1, column=0, sticky=tk.W, pady=5)
        style_menu = ttk.Combobox(caption_tab, textvariable=self.caption_style, values=["modern", "classic", "minimal", "bold"])
        style_menu.grid(row=1, column=1, pady=5)
        
        # Audio Tab
        audio_tab = ttk.Frame(notebook)
        notebook.add(audio_tab, text="Audio")
        
        self.voice_isolation = tk.BooleanVar(value=True)
        ttk.Checkbutton(audio_tab, text="Voice Isolation", variable=self.voice_isolation).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        self.dialogue_leveler = tk.BooleanVar(value=True)
        ttk.Checkbutton(audio_tab, text="Dialogue Leveler", variable=self.dialogue_leveler).grid(row=1, column=0, sticky=tk.W, pady=5)
        
        # Export Tab
        export_tab = ttk.Frame(notebook)
        notebook.add(export_tab, text="Export")
        
        self.export_youtube = tk.BooleanVar(value=True)
        ttk.Checkbutton(export_tab, text="YouTube (16:9)", variable=self.export_youtube).grid(row=0, column=0, sticky=tk.W, pady=5)
        
        self.export_tiktok = tk.BooleanVar(value=True)
        ttk.Checkbutton(export_tab, text="TikTok (9:16)", variable=self.export_tiktok).grid(row=1, column=0, sticky=tk.W, pady=5)
        
        self.export_instagram = tk.BooleanVar(value=True)
        ttk.Checkbutton(export_tab, text="Instagram (1:1)", variable=self.export_instagram).grid(row=2, column=0, sticky=tk.W, pady=5)
        
        self.smart_crop = tk.BooleanVar(value=True)
        ttk.Checkbutton(export_tab, text="Smart AI Crop", variable=self.smart_crop).grid(row=3, column=0, sticky=tk.W, pady=5)
        
        # Action Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=3, pady=20)
        
        ttk.Button(button_frame, text="▶️ Process Video", command=self.process_video, 
                  style="Accent.TButton").grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="✓ Validate", command=self.validate_config).grid(row=0, column=1, padx=5)
        ttk.Button(button_frame, text="📁 Open Renders", command=self.open_renders).grid(row=0, column=2, padx=5)
        ttk.Button(button_frame, text="⚙️ Settings", command=self.open_settings).grid(row=0, column=3, padx=5)
        
        # Progress Section
        progress_frame = ttk.LabelFrame(main_frame, text="Progress", padding="10")
        progress_frame.grid(row=5, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=10)
        
        self.progress_bar = ttk.Progressbar(progress_frame, variable=self.progress, maximum=100, length=500)
        self.progress_bar.grid(row=0, column=0, columnspan=2, pady=5)
        
        ttk.Label(progress_frame, textvariable=self.status).grid(row=1, column=0, columnspan=2, pady=5)
        
        # Log Section
        log_frame = ttk.LabelFrame(main_frame, text="Output Log", padding="10")
        log_frame.grid(row=6, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=10)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=10, width=100)
        self.log_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(6, weight=1)
        
    def browse_file(self):
        filename = filedialog.askopenfilename(
            title="Select Video File",
            filetypes=[("Video files", "*.mp4 *.mov *.avi *.mkv"), ("All files", "*.*")]
        )
        if filename:
            self.input_file.set(filename)
            self.log(f"Selected: {filename}")
            
    def validate_config(self):
        self.log("Running validation checks...")
        try:
            # Check if DaVinci Resolve is running
            result = subprocess.run(['pgrep', '-x', 'Resolve'], capture_output=True)
            if result.returncode == 0:
                self.log("✓ DaVinci Resolve is running")
            else:
                self.log("⚠ DaVinci Resolve is not running")
                
            # Check input file
            if self.input_file.get() and Path(self.input_file.get()).exists():
                self.log(f"✓ Input file exists: {self.input_file.get()}")
            else:
                self.log("⚠ No input file selected")
                
            # Check B-roll folder
            broll_path = Path("inputs/broll")
            if broll_path.exists():
                broll_count = len(list(broll_path.glob("*.mp4")))
                self.log(f"✓ B-roll folder contains {broll_count} clips")
            else:
                self.log("⚠ B-roll folder not found")
                
            self.log("Validation complete!")
            
        except Exception as e:
            self.log(f"Error during validation: {e}")
            
    def process_video(self):
        if not self.input_file.get():
            messagebox.showerror("Error", "Please select a video file")
            return
            
        self.log("Starting video processing...")
        self.progress.set(0)
        self.status.set("Processing...")
        
        # Run in separate thread
        thread = threading.Thread(target=self.run_pipeline)
        thread.start()
        
    def run_pipeline(self):
        try:
            input_path = self.input_file.get()
            
            # Step 1: Remove silence
            if self.remove_silence.get():
                self.update_progress(10, "Removing silence...")
                self.run_command(['make', 'cuts', f'INPUT={input_path}'])
                
            # Step 2: Detect scenes
            if self.detect_scenes.get():
                self.update_progress(20, "Detecting scenes...")
                self.run_command(['make', 'scenes', f'INPUT={input_path}'])
                
            # Step 3: Generate transcript
            if self.enable_captions.get():
                self.update_progress(30, "Generating transcript...")
                self.run_command(['make', 'transcript', f'INPUT={input_path}'])
                
            # Step 4: Index B-roll
            if self.enable_broll.get():
                self.update_progress(40, "Indexing B-roll...")
                self.run_command(['make', 'index-broll'])
                
            # Step 5: Run shortsify pipeline
            self.update_progress(50, "Running main pipeline...")
            
            # Build command with options
            cmd = ['python3', '-m', 'pipelines.shortsify', 
                   '--input', input_path,
                   '--artifacts', './artifacts']
            
            if self.smart_crop.get():
                cmd.append('--enable_smart_crop')
                
            if not self.enable_broll.get():
                cmd.append('--disable_broll')
                
            if not self.enable_captions.get():
                cmd.append('--disable_captions')
                
            if not self.voice_isolation.get():
                cmd.append('--disable_audio_polish')
                
            self.run_command(cmd)
            
            # Step 6: QC
            self.update_progress(90, "Running quality checks...")
            self.run_command(['make', 'qc'])
            
            self.update_progress(100, "Complete!")
            self.log("✅ Processing complete! Check artifacts/renders for output files.")
            
        except Exception as e:
            self.log(f"❌ Error: {e}")
            self.status.set("Error occurred")
            
    def run_command(self, cmd):
        """Run a command and log output"""
        try:
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.stdout:
                self.log(result.stdout)
            if result.stderr:
                self.log(result.stderr)
            return result.returncode == 0
        except Exception as e:
            self.log(f"Command error: {e}")
            return False
            
    def update_progress(self, value, message):
        """Update progress bar and status"""
        self.progress.set(value)
        self.status.set(message)
        self.log(f"[{value}%] {message}")
        
    def log(self, message):
        """Add message to log"""
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
        self.root.update()
        
    def open_renders(self):
        """Open renders folder"""
        renders_path = Path("artifacts/renders")
        renders_path.mkdir(parents=True, exist_ok=True)
        subprocess.run(['open', str(renders_path)])
        
    def open_settings(self):
        """Open settings window"""
        settings_window = tk.Toplevel(self.root)
        settings_window.title("Settings")
        settings_window.geometry("400x300")
        
        ttk.Label(settings_window, text="Pro Auto Editor Settings", font=('Helvetica', 14, 'bold')).pack(pady=10)
        
        # Add settings options here
        ttk.Label(settings_window, text="B-Roll Folders:").pack(pady=5)
        broll_text = tk.Text(settings_window, height=5, width=50)
        broll_text.pack(pady=5)
        broll_text.insert(tk.END, "inputs/broll\n/Volumes/Media/Stock")
        
        ttk.Button(settings_window, text="Save", command=settings_window.destroy).pack(pady=10)
        
    def start_monitoring(self):
        """Start monitoring backend service"""
        def monitor():
            try:
                # Check if backend is running
                result = subprocess.run(['pgrep', '-f', 'backend_service'], capture_output=True)
                if result.returncode != 0:
                    self.log("Starting backend service...")
                    subprocess.Popen(['python3', 'MacGUI/backend_service.py'])
            except Exception as e:
                self.log(f"Backend monitoring error: {e}")
                
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()

def main():
    root = tk.Tk()
    
    # Style configuration
    style = ttk.Style()
    style.theme_use('aqua')  # macOS native theme
    
    # Create custom styles
    style.configure("Accent.TButton", foreground="blue", font=('Helvetica', 12, 'bold'))
    
    app = ProAutoEditorGUI(root)
    
    # Center window
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry(f'{width}x{height}+{x}+{y}')
    
    root.mainloop()

if __name__ == "__main__":
    main()