from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import List, Tuple

import numpy as np
from PIL import Image

from utils.jsonl_logger import get_logger


def _extract_thumbnails(media_path: str, num_frames: int = 9) -> List[Path]:
    """Extract a small number of evenly spaced thumbnails using ffmpeg.

    Returns a list of file paths to the extracted images.
    """
    logger = get_logger()
    tmpdir = Path(tempfile.mkdtemp(prefix="smartcrop_"))
    # Extract up to num_frames frames at 1 fps; portable across ffmpeg builds
    out_pattern = str(tmpdir / "%03d.jpg")
    cmd = [
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-i", media_path,
        "-vf", "fps=1,scale=640:-1:flags=bicubic",
        "-frames:v", str(num_frames),
        out_pattern,
    ]
    try:
        subprocess.check_call(cmd)
    except Exception:
        # Fallback: try thumbnail filter
        try:
            cmd = [
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-i", media_path,
                "-vf", f"thumbnail={max(1, num_frames)},scale=640:-1:flags=bicubic",
                "-frames:v", str(num_frames),
                out_pattern,
            ]
            subprocess.check_call(cmd)
        except Exception:
            logger.error("smartcrop_ffmpeg_extract_failed", path=media_path)
            shutil.rmtree(tmpdir, ignore_errors=True)
            return []
    thumbs = sorted(tmpdir.glob("*.jpg"))
    return thumbs


def _edge_centroid(img: Image.Image) -> Tuple[float, float]:
    """Compute a simple edge-based centroid in normalized coordinates (0..1)."""
    gray = img.convert("L")
    arr = np.array(gray, dtype=np.float32) / 255.0
    # Sobel-like gradients
    kx = np.array([[1, 0, -1], [2, 0, -2], [1, 0, -1]], dtype=np.float32)
    ky = np.array([[1, 2, 1], [0, 0, 0], [-1, -2, -1]], dtype=np.float32)
    from numpy.lib.stride_tricks import sliding_window_view
    if arr.shape[0] < 3 or arr.shape[1] < 3:
        return 0.5, 0.5
    win = sliding_window_view(arr, (3, 3))
    gx = (win * kx).sum(axis=(-1, -2))
    gy = (win * ky).sum(axis=(-1, -2))
    mag = np.hypot(gx, gy)
    mag = np.maximum(mag, 1e-6)
    h, w = mag.shape
    xs = np.arange(w, dtype=np.float32)
    ys = np.arange(h, dtype=np.float32)
    X, Y = np.meshgrid(xs, ys)
    cx = float((X * mag).sum() / mag.sum()) / max(w - 1, 1)
    cy = float((Y * mag).sum() / mag.sum()) / max(h - 1, 1)
    return cx, cy


def estimate_subject_center(media_path: str, num_frames: int = 9) -> Tuple[float, float]:
    """Estimate subject center (cx, cy) in normalized coordinates from 0..1.

    Uses a simple edge centroid aggregated across thumbnails.
    """
    thumbs = _extract_thumbnails(media_path, num_frames=num_frames)
    if not thumbs:
        return 0.5, 0.5
    centers = []
    for p in thumbs:
        try:
            with Image.open(p) as im:
                centers.append(_edge_centroid(im))
        except Exception:
            continue
    # Cleanup temp dir
    if thumbs:
        shutil.rmtree(thumbs[0].parent, ignore_errors=True)
    if not centers:
        return 0.5, 0.5
    cx = float(np.median([c[0] for c in centers]))
    cy = float(np.median([c[1] for c in centers]))
    return cx, cy


