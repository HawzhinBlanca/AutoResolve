from __future__ import annotations

import time
import logging
from dataclasses import dataclass
from typing import Dict, Optional

from utils.jsonl_logger import get_logger

from .core import ResolveHandles

std_logger = logging.getLogger(__name__)


@dataclass
class RenderProfile:
    format: str
    preset_name: str
    extra_settings: Optional[Dict[str, str]] = None


class RenderError(RuntimeError):
    """Raised when render operations fail"""
    def __init__(self, message: str, job_id: Optional[str] = None, status: Optional[Dict] = None):
        super().__init__(message)
        self.job_id = job_id
        self.status = status
        self.timestamp = time.time()
        std_logger.error(f"RenderError: {message}", extra={
            'job_id': job_id,
            'status': status
        })


def set_render_settings(handles: ResolveHandles, settings: Dict[str, str]) -> None:
    """Apply robust render settings with sane defaults and key sanitization.

    Many Resolve builds reject unknown keys. We sanitize to a safe subset and
    pre-set the format/codec to mp4/H.264 for broad compatibility.
    """
    logger = get_logger()
    project = handles.project

    # Try to set a broadly compatible format/codec first
    try:
        project.SetCurrentRenderFormatAndCodec('mp4', 'H.264')
    except Exception as e:
        std_logger.warning(f"Failed to set render format/codec to mp4/H.264: {e}")

    allowed_keys = {
        'TargetDir', 'CustomName',
        'ExportVideo', 'ExportAudio',
        'FormatWidth', 'FormatHeight',
        'FrameRate', 'PixelAspectRatio',
        'VideoCodec', 'Quality', 'Encoder',
        'AudioCodec', 'AudioBitRate', 'AudioSampleRate',
        'NetworkOptimization',
        # In/Out range keys (Resolve-specific; ignored if unsupported)
        'RenderInOutRange', 'MarkIn', 'MarkOut',
    }

    # Defaults
    sanitized: Dict[str, object] = {
        'ExportVideo': True,
        'ExportAudio': True,
    }

    # Merge provided settings, keeping only allowed keys
    for k, v in (settings or {}).items():
        if k in allowed_keys and v is not None:
            sanitized[k] = v

    # Fill in FrameRate if missing
    if 'FrameRate' not in sanitized:
        try:
            fr = project.GetSetting('timelineFrameRate')
            if fr:
                sanitized['FrameRate'] = str(fr)
        except Exception as e:
            std_logger.debug(f"Failed to get timeline frame rate: {e}")

    # Convert numeric-like values to expected types
    for key in ['FormatWidth', 'FormatHeight', 'AudioBitRate', 'AudioSampleRate', 'MarkIn', 'MarkOut']:
        if key in sanitized:
            try:
                sanitized[key] = int(sanitized[key])
            except Exception as e:
                std_logger.debug(f"Failed to convert {key} to int: {e}")
    if 'PixelAspectRatio' in sanitized:
        try:
            sanitized['PixelAspectRatio'] = float(sanitized['PixelAspectRatio'])
        except Exception as e:
            std_logger.debug(f"Failed to convert PixelAspectRatio to float: {e}")

    ok = project.SetRenderSettings(sanitized)
    if not ok:
        # Last resort: stringify all values except booleans
        fallback = {}
        for k, v in sanitized.items():
            if isinstance(v, bool):
                fallback[k] = v
            else:
                fallback[k] = str(v)
        ok = project.SetRenderSettings(fallback)
        if not ok:
            logger.error('set_render_settings_failed', settings=sanitized)
            raise RenderError('SetRenderSettings failed')


def add_render_job_with_retry(handles: ResolveHandles, *, max_attempts: int = 3, backoff_seconds: float = 2.0) -> str:
    project = handles.project
    attempts = 0
    last_err: Optional[Exception] = None
    while attempts < max_attempts:
        attempts += 1
        job_id = project.AddRenderJob()
        if job_id:
            return str(job_id)
        last_err = RenderError("AddRenderJob returned falsy job id")
        time.sleep(backoff_seconds * attempts)
    assert last_err is not None
    raise last_err


def start_and_poll(handles: ResolveHandles, job_id: str, *, poll_interval_s: float = 2.0, timeout_s: float = 36000.0) -> None:
    project = handles.project
    if not project.StartRendering([job_id]):
        raise RenderError("StartRendering failed")

    start_time = time.time()
    while True:
        status_map = project.GetRenderJobStatus(job_id)
        if not isinstance(status_map, dict):
            raise RenderError("GetRenderJobStatus returned unexpected type")
        state = status_map.get("JobStatus") or status_map.get("Status")
        if state in {"Complete", "Completed", "Success"}:
            return
        if state in {"Failed", "Error", "Canceled", "Cancelled"}:
            raise RenderError(f"Render failed: {status_map}")
        if time.time() - start_time > timeout_s:
            raise RenderError("Render timeout")
        time.sleep(poll_interval_s)
