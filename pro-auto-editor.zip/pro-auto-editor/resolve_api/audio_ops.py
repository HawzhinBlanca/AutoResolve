from __future__ import annotations
from utils.jsonl_logger import get_logger


def set_voice_isolation(timeline: object, enabled: bool, percent: int | None = None) -> None:
    logger = get_logger()
    ok = False
    # Primary API (Resolve 18.6+ on some builds)
    try:
        ok = bool(timeline.SetVoiceIsolationState(enabled))
    except Exception:
        ok = False

    # Fallback: attempt project setting key when timeline API not supported
    if not ok:
        try:
            # Known key used by some Resolve builds
            timeline.SetSetting('audioVoiceIsolationEnable', '1' if enabled else '0')
            ok = True
            logger.debug('voice_isolation_fallback_setting_used', enabled=enabled)
        except Exception:
            ok = False

    if not ok:
        # Gracefully continue; feature not available in this environment
        logger.debug('voice_isolation_toggle_unsupported', enabled=enabled)
        return
    if percent is not None:
        try:
            timeline.SetSetting('audioVoiceIsolation', str(int(percent)))
            logger.info('voice_isolation_percent_set', percent=int(percent))
        except Exception as e:
            logger.debug('voice_isolation_percent_unsupported', error=str(e))


def set_dialogue_leveler(timeline: object, enabled: bool) -> None:
    logger = get_logger()
    try:
        ok = timeline.SetDialogueProcessorState(enabled)
    except Exception:
        ok = False
    if not ok:
        logger.debug('dialogue_leveler_toggle_unsupported', enabled=enabled)
