from __future__ import annotations

import hashlib
import json
import logging
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Any, Callable
import os
import functools

logger = logging.getLogger(__name__)

# Error handling and retry configuration
MAX_RETRIES = 3
RETRY_DELAY = 2.0  # seconds
CONNECTION_TIMEOUT = 30.0  # seconds

class ResolveConnectionError(Exception):
    """Raised when connection to Resolve fails"""
    def __init__(self, message: str, retry_count: int = 0, last_error: Optional[Exception] = None):
        super().__init__(message)
        self.retry_count = retry_count
        self.last_error = last_error
        self.timestamp = time.time()
        logger.error(f"ResolveConnectionError: {message}", extra={
            'retry_count': retry_count,
            'last_error': str(last_error) if last_error else None
        })

class ResolveOperationError(Exception):
    """Raised when a Resolve operation fails"""
    def __init__(self, operation: str, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.operation = operation
        self.details = details or {}
        self.timestamp = time.time()
        logger.error(f"ResolveOperationError in {operation}: {message}", extra=self.details)

def with_resolve_retry(max_retries: int = MAX_RETRIES, delay: float = RETRY_DELAY):
    """Decorator to add retry logic to Resolve API calls"""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        logger.warning(
                            f"Resolve operation failed (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {delay}s..."
                        )
                        time.sleep(delay * (attempt + 1))  # Exponential backoff
                        continue
                    else:
                        logger.error(f"Resolve operation failed after {max_retries} attempts: {e}")
                        break
            
            raise ResolveOperationError("retry", f"Operation failed after {max_retries} attempts", {"retries": max_retries}) from last_exception
        return wrapper
    return decorator

def check_resolve_connection(resolve_handles: 'ResolveHandles') -> bool:
    """Check if Resolve connection is still valid"""
    try:
        if resolve_handles.project is None:
            return False
        
        # Test connection by getting project name
        name = resolve_handles.project.GetName()
        return name is not None
    except Exception:
        return False

def reconnect_resolve(project_name: Optional[str] = None) -> 'ResolveHandles':
    """Attempt to reconnect to Resolve"""
    logger.info("Attempting to reconnect to Resolve...")
    try:
        return connect(project_name)
    except Exception as e:
        raise ResolveConnectionError(f"Failed to reconnect to Resolve: {e}") from e

# Lazy Resolve scripting module import
RESOLVE_MODULE_HINT_PATHS = [
    '/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules',
    '/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Resources/Developer/Scripting/Modules',
    '/opt/BlackmagicDesign/DaVinciResolve/Developer/Scripting/Modules',
]

DaVinciResolveScript = None  # type: ignore


def _ensure_resolve_module() -> None:
    """Ensure the DaVinci Resolve scripting module is importable.

    Tries common installation paths and the RESOLVE_SCRIPT_API env var.
    """
    global DaVinciResolveScript  # type: ignore
    if DaVinciResolveScript is not None:
        return

    from importlib import import_module
    import os

    search_paths = []
    extra = os.environ.get('RESOLVE_SCRIPT_API')
    if extra:
        search_paths.append(extra)
    search_paths.extend(RESOLVE_MODULE_HINT_PATHS)

    # De-duplicate and append to sys.path
    for hint in [p for p in search_paths if p]:
        try:
            if hint not in sys.path:
                sys.path.append(hint)
        except Exception as e:
            # Non-fatal; continue trying other hints
            logger.debug(f"Failed to add path {hint} to sys.path: {e}")
            continue

    # Attempt imports
    try:
        DaVinciResolveScript = import_module('DaVinciResolveScript')  # type: ignore
        return
    except ImportError as e:
        logger.debug(f"Failed to import DaVinciResolveScript: {e}")
        # Continue to try fusionscript
    try:
        DaVinciResolveScript = import_module('fusionscript')  # type: ignore
        return
    except ImportError as e:
        logger.error(f"Failed to import fusionscript: {e}")
        # Provide detailed troubleshooting information
        troubleshooting = [
            "1. Ensure DaVinci Resolve is installed",
            "2. Enable scripting in Resolve: Preferences > System > General > External scripting using",
            "3. Set RESOLVE_SCRIPT_API environment variable to the Modules path",
            f"4. Searched paths: {search_paths}"
        ]
        raise RuntimeError(
            f'DaVinciResolveScript module not available. '
            f'Troubleshooting:\n' + '\n'.join(troubleshooting)
        ) from e



@dataclass
class ResolveHandles:
    script_app: object
    resolve: object
    project_manager: object
    project: object


@with_resolve_retry(max_retries=3, delay=2.0)
def connect(project_name: Optional[str] = None) -> ResolveHandles:
    logger.info('resolve_connect_start', extra={'project_name': project_name})
    _ensure_resolve_module()

    script_app = DaVinciResolveScript.scriptapp('Resolve')  # type: ignore
    if script_app is None:
        logger.error('resolve_connect_failed: No script app - is Resolve running?')
        raise ResolveConnectionError(
            'Failed to acquire Resolve script app. '
            'Please ensure DaVinci Resolve is running and scripting is enabled.'
        )

    resolve = script_app
    project_manager = resolve.GetProjectManager()
    if project_manager is None:
        raise ResolveConnectionError('Failed to get ProjectManager from Resolve')

    project = project_manager.GetCurrentProject()
    if project is None:
        # Try to load or create a project automatically
        desired_name = project_name or os.environ.get('AUTORESOLVE_PROJECT') or 'AutoResolve'
        try:
            loaded = project_manager.LoadProject(desired_name)
        except Exception:
            loaded = False
        if not loaded:
            try:
                project_manager.CreateProject(desired_name)
            except Exception:
                logger.warning(f"Failed to create project '{desired_name}': Project may already exist or permissions issue")
        project = project_manager.GetCurrentProject()
        if project is None:
            logger.error('resolve_no_project')
            raise ResolveConnectionError(
                f'No active Resolve project and failed to create "{desired_name}". '
                'Please open a project in DaVinci Resolve or check project permissions.'
            )

    if project_name and project.GetName() != project_name:
        logger.info('resolve_loading_project', extra={'name': project_name})
        if not project_manager.LoadProject(project_name):
            logger.error('resolve_project_load_failed', extra={'name': project_name})
            raise ResolveConnectionError(f"Project '{project_name}' not found or failed to load")
        project = project_manager.GetCurrentProject()
        if project is None:
            logger.error('resolve_project_none_after_load')
            raise ResolveConnectionError('Project load returned no project')

    logger.info('resolve_connect_success', extra={'project': project.GetName()})
    return ResolveHandles(
        script_app=script_app,
        resolve=resolve,
        project_manager=project_manager,
        project=project,
    )


def ensure_absolute_path(path_str: str) -> str:
    p = Path(path_str)
    if not p.is_absolute():
        raise ValueError(f'Absolute path required: {path_str}')
    return str(p)


def hash8(*, cuts_fcpxml: Path, scenes_otio: Path, broll_selection_json: Path, caption_settings_json: Path, transform_params_json: Path) -> str:
    logger.info('hash8_start')
    inputs: Dict[str, str] = {}
    for key, file_path in {
        'cuts_fcpxml': cuts_fcpxml,
        'scenes_otio': scenes_otio,
        'broll_selection_json': broll_selection_json,
        'caption_settings_json': caption_settings_json,
        'transform_params_json': transform_params_json,
    }.items():
        fp = Path(file_path).expanduser().resolve()
        if not fp.exists():
            raise FileNotFoundError(f'missing input for hash: {key} -> {fp}')
        inputs[key] = hashlib.sha256(fp.read_bytes()).hexdigest()

    digest_src = json.dumps(inputs, sort_keys=True).encode('utf-8')
    hash_result = hashlib.sha256(digest_src).hexdigest()[:8]
    logger.info('hash8_computed', extra={'hash': hash_result})
    return hash_result


def set_media_paths_for_import(project: object, source_clips_path: str, source_clips_folders: Optional[str] = None) -> None:
    ensure_absolute_path(source_clips_path)
    if source_clips_folders is not None:
        ensure_absolute_path(source_clips_folders)
    media_storage = project.GetMediaPool().GetMediaStorage()
    if source_clips_folders:
        media_storage.SetSystemFolders([source_clips_folders])
    if hasattr(media_storage, 'SetWatchFolder'):
        media_storage.SetWatchFolder(source_clips_path)
