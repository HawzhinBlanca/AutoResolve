from __future__ import annotations
from typing import Dict, List, Optional
from pathlib import Path
import json
import logging

from utils.jsonl_logger import get_logger
from pathlib import Path
from .core import ensure_absolute_path, set_media_paths_for_import
from .smart_crop import estimate_subject_center

std_logger = logging.getLogger(__name__)


def import_fcpxml(project: object, fcpxml_path: str, source_clips_path: Optional[str] = None, source_clips_folders: Optional[str] = None) -> object:
    logger = get_logger()
    path = ensure_absolute_path(fcpxml_path)
    logger.info('import_fcpxml_start', path=path)
    media_pool = project.GetMediaPool()
    # Apply environment hint to avoid relink UI
    try:
        if source_clips_path is not None:
            set_media_paths_for_import(project, source_clips_path, source_clips_folders)
    except Exception as e:
        logger.debug('import_fcpxml_path_hint_failed', error=str(e))
    tl = media_pool.ImportTimelineFromFile(path)
    if tl is None:
        logger.error('import_fcpxml_failed', path=path)
        raise RuntimeError(f'ImportTimelineFromFile failed for {path}')
    logger.info('import_fcpxml_success', timeline=tl.GetName())
    project.SetCurrentTimeline(tl)
    return tl


def duplicate_timeline(project: object, timeline: object, new_name: str) -> object:
    logger = get_logger()
    logger.info('duplicate_timeline_start', source=timeline.GetName(), new_name=new_name)
    dup = timeline.DuplicateTimeline(new_name)
    if dup is None:
        logger.error('duplicate_timeline_failed')
        raise RuntimeError('DuplicateTimeline failed')
    logger.info('duplicate_timeline_success', timeline=new_name)
    project.SetCurrentTimeline(dup)
    return dup


def transform_timeline_roi(timeline: object, profile: str) -> bool:
    logger = get_logger()
    logger.info('transform_timeline_start', profile=profile)
    # Deterministic transform: set resolution and input scaling to crop center
    if profile == '9x16':
        width, height = 1080, 1920
    elif profile == '1x1':
        width, height = 1080, 1080
    else:
        logger.error('transform_unsupported_profile', profile=profile)
        raise ValueError('Unsupported profile')
    # Some Resolve builds require enabling custom resolution first
    try:
        timeline.SetSetting('useCustomTimelineResolution', '1')
    except Exception as e:
        std_logger.warning(f"Failed to enable custom timeline resolution: {e}")

    ok_w = False
    ok_h = False
    # Primary attempt on timeline object
    try:
        ok_w = bool(timeline.SetSetting('timelineResolutionWidth', str(width)))
        ok_h = bool(timeline.SetSetting('timelineResolutionHeight', str(height)))
    except Exception:
        ok_w = ok_h = False

    # Fallback: set on project settings for current timeline
    if not (ok_w and ok_h):
        try:
            project = timeline.GetProject() if hasattr(timeline, 'GetProject') else None
        except Exception:
            project = None
        if project is not None:
            try:
                project.SetCurrentTimeline(timeline)
            except Exception as e:
                std_logger.debug(f"Failed to set current timeline: {e}")
            try:
                ok_w = bool(project.SetSetting('timelineResolutionWidth', str(width)))
                ok_h = bool(project.SetSetting('timelineResolutionHeight', str(height)))
            except Exception:
                ok_w = ok_h = False

    # Prefer crop center scaling
    try:
        timeline.SetSetting('inputScalingPreset', 'scale full frame with crop')
    except Exception as e:
        std_logger.warning(f"Failed to set input scaling preset: {e}")

    # Verify
    try:
        cur_w = int(timeline.GetSetting('timelineResolutionWidth') or 0)
        cur_h = int(timeline.GetSetting('timelineResolutionHeight') or 0)
    except Exception:
        cur_w = cur_h = 0

    if not (ok_w and ok_h) or not (cur_w == width and cur_h == height):
        # Graceful fallback: keep timeline as-is and rely on render settings to enforce output size
        logger.error('transform_resolution_failed', width=width, height=height)
        return False

    return True


def apply_clip_level_roi(timeline: object, profile: str) -> None:
    """Fallback framing when timeline resolution cannot be changed.

    Sets input scaling to crop and applies per-clip Zoom/Position to center content for vertical/square.
    """
    logger = get_logger()
    try:
        timeline.SetSetting('inputScalingPreset', 'scale full frame with crop')
    except Exception as e:
        std_logger.warning(f"Failed to set input scaling preset for clip-level ROI: {e}")
    # Determine target aspect ratio
    if profile == '9x16':
        target_aspect = 9/16
    elif profile == '1x1':
        target_aspect = 1.0
    else:
        return
    try:
        items = timeline.GetItemListInTrack('video', 1) or []
    except Exception:
        items = []
    for it in items:
        try:
            # Try to find source path
            media = it.GetMediaPoolItem() if hasattr(it, 'GetMediaPoolItem') else None
            media_path = None
            if media is not None and hasattr(media, 'GetClipProperty'):
                try:
                    media_path = media.GetClipProperty('File Path')
                except Exception:
                    media_path = None
            # Estimate center and apply position offsets (X: -0.5..0.5 normalized)
            cx, cy = (0.5, 0.5)
            if media_path:
                try:
                    cx, cy = estimate_subject_center(media_path)
                except Exception as e:
                    std_logger.debug(f"Failed to estimate subject center for {media_path}: {e}")
            # Convert center to position offsets; Resolve uses pixels/normalized per build, use small offsets
            offset_x = (cx - 0.5) * 0.4  # tuned nudge
            offset_y = (cy - 0.5) * 0.4
            it.SetProperty('ZoomX', 1.25)
            it.SetProperty('ZoomY', 1.25)
            it.SetProperty('PositionX', float(offset_x))
            it.SetProperty('PositionY', float(offset_y))
        except Exception:
            continue
    logger.info('clip_level_roi_applied', profile=profile, count=len(items))


def append_broll_v2(project: object, timeline: object, selection_json_path: str) -> None:
    logger = get_logger()
    logger.info('append_broll_start', path=selection_json_path)
    sel = json.loads(Path(selection_json_path).read_text())
    window_start = float(sel.get('window_start', 0.0))
    window_duration = float(sel.get('window_duration', 60.0))
    clips: List[Dict] = sel.get('clips', [])
    cross_dissolve_frames = int(sel.get('cross_dissolve_frames', 6))
    per_clip_seconds = float(sel.get('per_clip_seconds', 3.0))
    no_repeat_window = int(sel.get('no_repeat_window', 3))
    if not clips:
        logger.info('append_broll_no_clips')
        return
    media_pool = project.GetMediaPool()
    fps = float(timeline.GetSetting('timelineFrameRate') or 30)
    record_start_frame = int(round(window_start * fps))
    to_append = []
    current_frame = record_start_frame
    window_end_frame = record_start_frame + int(window_duration * fps)
    last_paths: List[str] = []
    for idx, c in enumerate(clips):
        media_path = ensure_absolute_path(c['path'])
        # No-repeat window: avoid placing the same path consecutively within 3 clips
        if media_path in last_paths:
            continue
        items = media_pool.ImportMedia([media_path]) or []
        if not items:
            continue
        mpi = items[0]
        # Append sequentially on V2, back-to-back with small overlap for dissolve
        record_frame = current_frame
        # Advance current frame by configured seconds minus dissolve to create overlap
        advance = int(fps * max(0.0, per_clip_seconds))
        current_frame = record_frame + max(1, advance - cross_dissolve_frames)
        if current_frame >= window_end_frame:
            break
        to_append.append({
            'mediaPoolItem': mpi,
            'trackType': 'Video',
            'trackIndex': 2,
            'recordFrame': record_frame,
        })
        # maintain small history for no-repeat policy
        last_paths.append(media_path)
        if len(last_paths) > max(1, no_repeat_window):
            last_paths.pop(0)
    if to_append:
        try:
            # Ensure target video track exists (V2) to avoid Resolve placing on V1 unexpectedly
            try:
                tracks = timeline.GetTrackCount('video') if hasattr(timeline, 'GetTrackCount') else 0
            except Exception:
                tracks = 0
            if tracks and tracks < 2:
                try:
                    # Add a blank video track 2 if possible
                    timeline.AddTrack('video')
                except Exception as e:
                    std_logger.debug(f"Failed to add blank video track 2: {e}")
            ok = media_pool.AppendToTimeline(to_append)
        except Exception:
            ok = False
        if not ok:
            raise RuntimeError('AppendToTimeline failed')
        # Note: Resolve API does not expose programmatic cross-dissolve reliably across versions.
        # We approximate by overlapping clips by `cross_dissolve_frames` frames to allow default
        # transition on import. If transition APIs are available, add here in a version-gated way.


def ensure_base_clip(project: object, timeline: object, input_path: str) -> None:
    """Ensure the main input clip is present on V1 starting at 0.

    Some environments fail FCPXML import or return an empty timeline. This function guarantees
    we have a base video layer to render under B-roll.
    """
    logger = get_logger()
    try:
        items = timeline.GetItemListInTrack('video', 1)
    except Exception:
        items = None
    has_v1 = bool(items)
    if has_v1:
        return
    media_pool = project.GetMediaPool()
    clip_path = ensure_absolute_path(input_path)
    try:
        # Import input clip if not already in bin
        imported = media_pool.ImportMedia([clip_path]) or []
    except Exception:
        imported = []
    if not imported:
        logger.error('ensure_base_clip_import_failed', path=clip_path)
        return
    mpi = imported[0]
    try:
        ok = media_pool.AppendToTimeline([
            {
                'mediaPoolItem': mpi,
                'trackType': 'Video',
                'trackIndex': 1,
                'recordFrame': 0,
            }
        ])
    except Exception:
        ok = False
    if not ok:
        logger.error('ensure_base_clip_append_failed', path=clip_path)
    else:
        logger.info('ensure_base_clip_appended', path=clip_path)


def purge_overlay_tracks(timeline: object) -> None:
    """Remove all clips on video tracks V2 and above if supported by API.

    This prevents leftover placeholder overlays from earlier runs when B-roll is disabled.
    Fails gracefully if methods are unavailable on current Resolve build.
    """
    logger = get_logger()
    try:
        track_count = timeline.GetTrackCount('video')
    except Exception:
        track_count = 0
    if not track_count or track_count < 2:
        return
    for track_index in range(2, int(track_count) + 1):
        try:
            items = timeline.GetItemListInTrack('video', track_index)
        except Exception:
            items = None
        if not items:
            continue
        removed_any = False
        # Try bulk delete first
        try:
            if hasattr(timeline, 'DeleteClips'):
                if timeline.DeleteClips(items):
                    removed_any = True
            else:
                raise AttributeError('DeleteClips not available')
        except Exception:
            # Fallback: best-effort per-item delete
            for it in items:
                try:
                    if hasattr(it, 'Delete'):
                        it.Delete()
                        removed_any = True
                except Exception as e:
                    std_logger.debug(f"Failed to delete clip on track {track_index}: {e}")
        if removed_any:
            logger.info('purged_overlay_track', track=track_index)
