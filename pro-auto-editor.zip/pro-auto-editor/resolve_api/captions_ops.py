from __future__ import annotations
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)


def transcribe_audio_and_create_subtitles(project: object, timeline: object, *, language: str = 'en', track_index: int = 1) -> bool:
    """Attempt transcription + subtitle creation with multiple API call variants.
    Returns True on success, False otherwise.
    """
    try:
        media_pool = project.GetMediaPool()
        root = media_pool.GetRootFolder()
        # Try transcribe on root folder
        try:
            ok_t = root.TranscribeAudio(language)
        except TypeError:
            # Some builds require no args
            ok_t = root.TranscribeAudio()
        if not ok_t:
            return False
        # Try CreateSubtitlesFromAudio with various arg styles
        variants = [
            {},
            {'TrackIndex': track_index, 'Language': language},
            {'Language': language},
        ]
        for args in variants:
            try:
                created = timeline.CreateSubtitlesFromAudio(args) if args else timeline.CreateSubtitlesFromAudio()
            except TypeError:
                continue
            if created:
                return True
        return False
    except Exception:
        return False


def apply_subtitle_style(timeline: object, style: Dict[str, object]) -> None:
    """Best-effort styling for subtitle items.

    Attempts multiple property keys to support different Resolve builds. Fails silently if unsupported.
    style keys supported (best-effort):
      - font, size, color, outline_color, outline_width, box_opacity, box_color, max_lines,
        align ('bottom'|'top'), safe_margin_percent, fade_frames
    """
    try:
        items = timeline.GetItemListInTrack('subtitle', 1)
    except Exception:
        items = None
    if not items:
        return

    fade = int(style.get('fade_frames', 0) or 0)
    for it in items:
        # Fades (if supported)
        if fade > 0:
            for key in ('FadeInFrames', 'FadeIn', 'FadeInDurationFrames'):
                try:
                    it.SetProperty(key, fade)
                    break
                except Exception as e:
                    logger.debug(f"Failed to set fade-in property '{key}': {e}")
            for key in ('FadeOutFrames', 'FadeOut', 'FadeOutDurationFrames'):
                try:
                    it.SetProperty(key, fade)
                    break
                except Exception as e:
                    logger.debug(f"Failed to set fade-in property '{key}': {e}")
        # Font / size
        if 'font' in style:
            for key in ('Font', 'TextFont'):
                try:
                    it.SetProperty(key, style['font'])
                    break
                except Exception as e:
                    logger.debug(f"Failed to set fade-in property '{key}': {e}")
        if 'size' in style:
            for key in ('FontSize', 'TextSize'):
                try:
                    it.SetProperty(key, int(style['size']))
                    break
                except Exception as e:
                    logger.debug(f"Failed to set fade-in property '{key}': {e}")
        # Colors
        if 'color' in style:
            for key in ('Color', 'TextColor'):
                try:
                    it.SetProperty(key, style['color'])
                    break
                except Exception as e:
                    logger.debug(f"Failed to set fade-in property '{key}': {e}")
        if 'outline_color' in style:
            for key in ('OutlineColor', 'StrokeColor'):
                try:
                    it.SetProperty(key, style['outline_color'])
                    break
                except Exception as e:
                    logger.debug(f"Failed to set fade-in property '{key}': {e}")
        if 'outline_width' in style:
            for key in ('OutlineWidth', 'StrokeWidth'):
                try:
                    it.SetProperty(key, int(style['outline_width']))
                    break
                except Exception as e:
                    logger.debug(f"Failed to set fade-in property '{key}': {e}")
        # Box settings
        if 'box_opacity' in style:
            for key in ('BoxOpacity', 'BackgroundOpacity'):
                try:
                    it.SetProperty(key, float(style['box_opacity']))
                    break
                except Exception as e:
                    logger.debug(f"Failed to set fade-in property '{key}': {e}")
        if 'box_color' in style:
            for key in ('BoxColor', 'BackgroundColor'):
                try:
                    it.SetProperty(key, style['box_color'])
                    break
                except Exception as e:
                    logger.debug(f"Failed to set fade-in property '{key}': {e}")
    # Alignment and safe margin are often timeline- or track-level; try timeline settings
    try:
        if 'max_lines' in style:
            for key in ('subtitleMaxNumLines', 'SubtitleMaxNumLines'):
                timeline.SetSetting(key, str(int(style['max_lines'])))
    except Exception as e:
        logger.debug(f"Failed to set timeline subtitle property: {e}")
    try:
        if 'align' in style:
            align_val = style['align']
            if align_val in ('bottom', 'top'):
                for key in ('subtitleAlign', 'SubtitleAlignment'):
                    timeline.SetSetting(key, align_val)
    except Exception as e:
        logger.debug(f"Failed to set timeline subtitle property: {e}")
    try:
        if 'safe_margin_percent' in style:
            for key in ('subtitleSafeMargin', 'SubtitleSafeMargin'):
                timeline.SetSetting(key, str(float(style['safe_margin_percent'])))
    except Exception as e:
        logger.debug(f"Failed to set timeline subtitle property: {e}")
