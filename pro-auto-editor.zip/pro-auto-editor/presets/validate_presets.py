#!/usr/bin/env python3
"""
Render Preset Validator
Validates DaVinci Resolve render presets for compatibility
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Required fields for DaVinci Resolve render presets
REQUIRED_FIELDS = {
    'FormatWidth': (int, lambda x: 1 <= x <= 8192),
    'FormatHeight': (int, lambda x: 1 <= x <= 8192),
    'FrameRate': (str, lambda x: x in ['23.976', '24', '25', '29.97', '30', '50', '59.94', '60']),
    'VideoCodec': (str, lambda x: x in ['h264', 'h265', 'ProRes', 'DNxHD', 'DNxHR']),
    'AudioCodec': (str, lambda x: x in ['aac', 'mp3', 'pcm', 'opus', 'ac3']),
}

# Optional fields with validation
OPTIONAL_FIELDS = {
    'PixelAspectRatio': (float, lambda x: 0.1 <= x <= 10.0),
    'VideoQuality': (int, lambda x: 0 <= x <= 5),
    'AudioBitRate': (int, lambda x: 32000 <= x <= 640000),
    'AudioSampleRate': (int, lambda x: x in [22050, 44100, 48000, 96000, 192000]),
    'VideoBitRate': (int, lambda x: 100000 <= x <= 100000000),
    'VideoProfile': (str, lambda x: x in ['Baseline', 'Main', 'High', 'High10', 'High422', 'High444']),
    'EncodingProfile': (str, lambda x: x in ['Baseline', 'Main', 'High', 'Auto']),
    'MultipassEncode': (bool, lambda x: isinstance(x, bool)),
    'AlphaMode': (int, lambda x: 0 <= x <= 2),
    'NetworkOptimization': (bool, lambda x: isinstance(x, bool)),
}

# Platform-specific presets
PLATFORM_SPECS = {
    'youtube': {
        'FormatWidth': 1920,
        'FormatHeight': 1080,
        'FrameRate': '30',
        'VideoCodec': 'h264',
        'AudioCodec': 'aac',
        'VideoBitRate': 8000000,
        'AudioBitRate': 320000,
    },
    'tiktok': {
        'FormatWidth': 1080,
        'FormatHeight': 1920,
        'FrameRate': '30',
        'VideoCodec': 'h264',
        'AudioCodec': 'aac',
        'VideoBitRate': 6000000,
        'AudioBitRate': 256000,
    },
    'instagram': {
        'FormatWidth': 1080,
        'FormatHeight': 1080,
        'FrameRate': '30',
        'VideoCodec': 'h264',
        'AudioCodec': 'aac',
        'VideoBitRate': 5000000,
        'AudioBitRate': 256000,
    },
    'square': {
        'FormatWidth': 1080,
        'FormatHeight': 1080,
        'FrameRate': '30',
        'VideoCodec': 'h264',
        'AudioCodec': 'aac',
        'VideoBitRate': 5000000,
        'AudioBitRate': 256000,
    }
}


class PresetValidator:
    """Validates and repairs DaVinci Resolve render presets"""
    
    @staticmethod
    def validate_field(name: str, value: Any, field_spec: tuple) -> tuple[bool, Optional[str]]:
        """Validate a single field"""
        expected_type, validator = field_spec
        
        # Type check
        if not isinstance(value, expected_type):
            return False, f"Expected {expected_type.__name__}, got {type(value).__name__}"
        
        # Value validation
        try:
            if not validator(value):
                return False, f"Value {value} failed validation"
        except Exception as e:
            return False, f"Validation error: {e}"
            
        return True, None
    
    @classmethod
    def validate_preset(cls, preset: Dict[str, Any], preset_name: str = "preset") -> Dict[str, Any]:
        """Validate a preset and return validation results"""
        results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'fixed': {}
        }
        
        # Check required fields
        for field, spec in REQUIRED_FIELDS.items():
            if field not in preset:
                results['valid'] = False
                results['errors'].append(f"Missing required field: {field}")
            else:
                valid, error = cls.validate_field(field, preset[field], spec)
                if not valid:
                    results['valid'] = False
                    results['errors'].append(f"Field '{field}': {error}")
        
        # Check optional fields
        for field, spec in OPTIONAL_FIELDS.items():
            if field in preset:
                valid, error = cls.validate_field(field, preset[field], spec)
                if not valid:
                    results['warnings'].append(f"Field '{field}': {error}")
        
        # Platform-specific validation
        if 'YouTube' in preset_name or 'youtube' in preset_name.lower():
            cls._validate_platform_preset(preset, 'youtube', results)
        elif 'TikTok' in preset_name or 'tiktok' in preset_name.lower():
            cls._validate_platform_preset(preset, 'tiktok', results)
        elif 'Instagram' in preset_name or 'instagram' in preset_name.lower():
            cls._validate_platform_preset(preset, 'instagram', results)
        elif 'Square' in preset_name or 'square' in preset_name.lower():
            cls._validate_platform_preset(preset, 'square', results)
            
        return results
    
    @staticmethod
    def _validate_platform_preset(preset: Dict[str, Any], platform: str, results: Dict):
        """Validate against platform-specific requirements"""
        if platform not in PLATFORM_SPECS:
            return
            
        specs = PLATFORM_SPECS[platform]
        
        for field, expected_value in specs.items():
            if field in preset:
                actual_value = preset[field]
                if actual_value != expected_value:
                    # For bit rates, allow ±20% variance
                    if 'BitRate' in field and isinstance(actual_value, int) and isinstance(expected_value, int):
                        variance = abs(actual_value - expected_value) / expected_value
                        if variance > 0.2:
                            results['warnings'].append(
                                f"{platform.title()} preset: {field} is {actual_value}, "
                                f"recommended {expected_value} (±20%)"
                            )
                    elif field in ['FormatWidth', 'FormatHeight']:
                        results['warnings'].append(
                            f"{platform.title()} preset: {field} is {actual_value}, "
                            f"standard is {expected_value}"
                        )
    
    @classmethod
    def repair_preset(cls, preset: Dict[str, Any], preset_name: str = "preset") -> Dict[str, Any]:
        """Attempt to repair a preset by adding missing fields with defaults"""
        repaired = preset.copy()
        
        # Detect platform from name
        platform = None
        if 'YouTube' in preset_name or 'youtube' in preset_name.lower():
            platform = 'youtube'
        elif 'TikTok' in preset_name or 'tiktok' in preset_name.lower():
            platform = 'tiktok'
        elif 'Instagram' in preset_name or 'instagram' in preset_name.lower():
            platform = 'instagram'
        elif 'Square' in preset_name or 'square' in preset_name.lower():
            platform = 'square'
        
        # Add missing required fields from platform specs
        if platform and platform in PLATFORM_SPECS:
            for field, value in PLATFORM_SPECS[platform].items():
                if field in REQUIRED_FIELDS and field not in repaired:
                    repaired[field] = value
                    logger.info(f"Added missing field '{field}' with value {value}")
        
        # Add generic defaults for remaining missing required fields
        defaults = {
            'FormatWidth': 1920,
            'FormatHeight': 1080,
            'FrameRate': '30',
            'VideoCodec': 'h264',
            'AudioCodec': 'aac',
        }
        
        for field in REQUIRED_FIELDS:
            if field not in repaired and field in defaults:
                repaired[field] = defaults[field]
                logger.info(f"Added missing field '{field}' with default {defaults[field]}")
        
        return repaired
    
    @classmethod
    def validate_preset_file(cls, file_path: Path) -> bool:
        """Validate a preset file"""
        try:
            with open(file_path, 'r') as f:
                preset = json.load(f)
            
            preset_name = file_path.stem
            results = cls.validate_preset(preset, preset_name)
            
            logger.info(f"\nValidating preset: {preset_name}")
            logger.info(f"Status: {'✅ VALID' if results['valid'] else '❌ INVALID'}")
            
            if results['errors']:
                logger.error("Errors:")
                for error in results['errors']:
                    logger.error(f"  - {error}")
            
            if results['warnings']:
                logger.warning("Warnings:")
                for warning in results['warnings']:
                    logger.warning(f"  - {warning}")
            
            # Attempt repair if invalid
            if not results['valid']:
                logger.info("\nAttempting to repair preset...")
                repaired = cls.repair_preset(preset, preset_name)
                
                # Validate repaired preset
                repair_results = cls.validate_preset(repaired, preset_name)
                if repair_results['valid']:
                    # Save repaired preset
                    backup_path = file_path.with_suffix('.json.backup')
                    shutil.copy(file_path, backup_path)
                    logger.info(f"Backed up original to {backup_path}")
                    
                    with open(file_path, 'w') as f:
                        json.dump(repaired, f, indent=2)
                    logger.info(f"✅ Preset repaired and saved to {file_path}")
                    return True
                else:
                    logger.error("❌ Could not fully repair preset")
                    return False
            
            return results['valid']
            
        except Exception as e:
            logger.error(f"Error validating {file_path}: {e}")
            return False


def validate_all_presets(directory: Path) -> bool:
    """Validate all presets in a directory"""
    all_valid = True
    
    preset_files = list(directory.glob('*.json'))
    if not preset_files:
        logger.warning(f"No preset files found in {directory}")
        return False
    
    logger.info(f"Found {len(preset_files)} preset files to validate")
    
    for preset_file in preset_files:
        if not PresetValidator.validate_preset_file(preset_file):
            all_valid = False
    
    return all_valid


def main():
    """Main validation entry point"""
    presets_dir = Path(__file__).parent / 'render'
    
    if not presets_dir.exists():
        logger.error(f"Presets directory not found: {presets_dir}")
        sys.exit(1)
    
    logger.info("=" * 60)
    logger.info("DaVinci Resolve Render Preset Validation")
    logger.info("=" * 60)
    
    if validate_all_presets(presets_dir):
        logger.info("\n✅ All presets are valid and compatible with DaVinci Resolve")
        sys.exit(0)
    else:
        logger.error("\n❌ Some presets have issues. Please review and fix.")
        sys.exit(1)


if __name__ == "__main__":
    main()