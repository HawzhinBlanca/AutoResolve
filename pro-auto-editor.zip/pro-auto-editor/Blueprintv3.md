# AutoResolve v3 — 100% Robust Blueprint

Lean, strict, shippable. V‑JEPA‑2 ViT‑L as the *attempted* brain, OpenCLIP as hard fallback. Proof-first, A/B side‑by‑side, linear head alignment into CLIP text space, temporal attention, memory governor, disk cache with weight fingerprint, long‑video caps, bootstrap CIs. If V‑JEPA‑2 fails **any** gate, CLIP ships by default.

---

## Non‑negotiable Gates

* **Quality:** V‑JEPA ≥ **+15%** over CLIP on **Top‑3** and **MRR** (and **95% CI lower bound > 0** for both deltas).
* **Perf:** ≤ **5.0 sec/min** of video on Mac; otherwise offload to CUDA with identical outputs.
* **Memory:** Peak RSS < **16 GB**; adaptive degradation (fps → window → crop).
* **Determinism:** Same input ⇒ same segments/embeddings/scores; all decisions logged.
* **Scope:** v3.0 excludes audio gen; SAM2 text→box long‑tracking deferred to v3.1 (manual box/points only in v3.0).

---

## Directory (locked; keep it lean)

```
autorez/
├─ Makefile
├─ requirements.txt
├─ conf/
│  └─ embeddings.ini
├─ datasets/
│  └─ broll_pilot/
│     └─ manifest.json        # you provide 50+ real queries
├─ src/
│  ├─ embedders/
│  │  ├─ vjepa_embedder.py
│  │  └─ clip_embedder.py
│  ├─ align/
│  │  └─ align_vjepa_to_clip.py
│  ├─ scoring/
│  │  └─ broll_scoring.py
│  ├─ eval/
│  │  ├─ ablate_vjepa_vs_clip.py
│  │  └─ bootstrap_ci.py
│  └─ utils/
│     ├─ memory.py
│     └─ cache.py
├─ artifacts/                 # emitted at runtime
└─ logs/                      # emitted at runtime
```

---

## `requirements.txt`

```
torch
transformers
open-clip-torch
pillow
av
psutil
numpy
```

---

## `conf/embeddings.ini`

```
default_model = clip          # clip | vjepa
backend       = mps           # mps | cuda
fps           = 1.0
window        = 16
crop          = 256
max_rss_gb    = 16
cache_dir     = artifacts/cache
strategy      = temp_attn     # cls | patch_mean | temp_attn
max_segments  = 500           # long-video cap
seed          = 1234
```

---

## `src/utils/memory.py`

```python
import psutil, torch, time, random, numpy as np
from dataclasses import dataclass

@dataclass
class Budget:
    max_gb: float = 16.0
    fps: float = 1.0
    window: int = 16
    crop: int = 256
    max_segments: int = 500

_DEF_FPS_FLOOR = 0.5
_DEF_WIN_FLOOR = 8
_DEF_CROP_FLOOR = 224

# Deterministic seeds
_DEF_SEED = 1234

def set_seeds(seed=_DEF_SEED):
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.backends.mps.is_available():
            # no-op determinism toggle for MPS; still set CPU seeds
            pass
    except Exception:
        pass

def rss_gb():
    return psutil.Process().memory_info().rss / (1024**3)

def enforce_budget(b: Budget, device: str):
    changes = []
    # degrade in order: fps → window → crop
    while rss_gb() > b.max_gb:
        if b.fps > _DEF_FPS_FLOOR:
            b.fps = max(_DEF_FPS_FLOOR, round(b.fps * 0.75, 3)); changes.append(("fps", b.fps)); break
        if b.window > _DEF_WIN_FLOOR:
            b.window = max(_DEF_WIN_FLOOR, int(b.window * 0.75)); changes.append(("window", b.window)); break
        if b.crop > _DEF_CROP_FLOOR:
            b.crop = max(_DEF_CROP_FLOOR, int(b.crop * 0.9)); changes.append(("crop", b.crop)); break
        time.sleep(0.02); break
    if device == "cuda":
        try: torch.cuda.empty_cache()
        except Exception: pass
    return changes, b
```

---

## `src/utils/cache.py`

```python
import os, json, hashlib, numpy as np

def sha256_str(s: str):
    return hashlib.sha256(s.encode()).hexdigest()

def key(video_path, fps, window, crop, strategy, model_tag, weights_hash):
    base = f"{video_path}|{fps}|{window}|{crop}|{strategy}|{model_tag}|{weights_hash}"
    return hashlib.sha256(base.encode()).hexdigest()

def save(cache_dir, k, segments, meta):
    os.makedirs(cache_dir, exist_ok=True)
    np.savez_compressed(os.path.join(cache_dir, f"{k}.npz"), data=segments)
    with open(os.path.join(cache_dir, f"{k}.json"), "w") as f: json.dump(meta, f)

def load(cache_dir, k):
    npz = os.path.join(cache_dir, f"{k}.npz")
    js  = os.path.join(cache_dir, f"{k}.json")
    if not (os.path.exists(npz) and os.path.exists(js)): return None, None
    arr = np.load(npz, allow_pickle=True)["data"]
    meta = json.load(open(js))
    return arr.tolist(), meta
```

---

## `src/embedders/vjepa_embedder.py`

```python
import torch, av, numpy as np, os, json, time, hashlib
from transformers import AutoVideoProcessor, AutoModel
from src.utils.memory import Budget, enforce_budget, rss_gb, set_seeds
from src.utils.cache import key, load, save

class VJEPAEmbedder:
    def __init__(self, repo="facebook/vjepa2-vitl-fpc64-256", cache_dir="artifacts/cache", device=None, dtype=torch.float16, seed=1234):
        set_seeds(seed)
        self.device = device or ("mps" if torch.backends.mps.is_available() else "cpu")
        self.model  = AutoModel.from_pretrained(repo).to(self.device).eval()
        self.proc   = AutoVideoProcessor.from_pretrained(repo)
        self.dtype  = dtype
        self.cache_dir = cache_dir
        self.model_tag = f"vjepa2-vitl"
        self.weights_hash = self._weights_fingerprint(self.model)

    def _weights_fingerprint(self, model):
        h = hashlib.sha256()
        sd = model.state_dict()
        for k, v in sd.items():
            h.update(k.encode()); h.update(str(tuple(v.shape)).encode()); h.update(str(v.dtype).encode())
            try:
                h.update(v.view(-1)[:1].detach().cpu().numpy().tobytes())
            except Exception:
                pass
        return h.hexdigest()[:16]

    def _read_frames(self, path, fps=1.0):
        container = av.open(path); s = container.streams.video[0]
        frames, ts = [], []
        step = int(round(s.average_rate / fps)) if s.average_rate else 30
        for i, fr in enumerate(container.decode(s)):
            if i % step == 0:
                frames.append(fr.to_ndarray(format="rgb24"))
                ts.append(float(fr.time) if fr.time else (i/float(s.average_rate or 30)))
        container.close(); return frames, ts

    def _temp_attn(self, tokens):  # [T, 1+N, D]
        cls = tokens[:,0,:]
        w = torch.softmax((cls @ cls.mean(0).unsqueeze(1)).squeeze(-1), dim=0)
        emb = (w[:,None]*cls).sum(0)
        return torch.nn.functional.normalize(emb, dim=-1)

    @torch.inference_mode()
    def embed_segments(self, video_path, fps=1.0, window=16, crop=256, strategy="temp_attn", max_rss_gb=16, max_segments=500):
        b = Budget(max_gb=max_rss_gb, fps=fps, window=window, crop=crop, max_segments=max_segments)
        k = key(video_path, b.fps, b.window, b.crop, strategy, self.model_tag, self.weights_hash)
        cached, meta = load(self.cache_dir, k)
        if cached is not None:
            return cached, meta

        frames, ts = self._read_frames(video_path, fps=b.fps)
        segs, t0 = [], time.time()
        total_segments = min(len(frames)//b.window, b.max_segments)
        for si in range(total_segments):
            i = si * b.window
            chunk = frames[i:i+b.window]
            px = self.proc(list(chunk), return_tensors="pt", do_resize=True, size={"shortest_edge": b.crop})
            px = {k:v.to(self.device) for k,v in px.items()}
            with torch.autocast(self.device, dtype=self.dtype):
                out = self.model(**px)
            h = out.last_hidden_state.squeeze(0)  # [T, tokens, D]
            h = torch.nn.functional.normalize(h, dim=-1)
            if strategy == "cls":
                emb = torch.nn.functional.normalize(h[:,0,:].mean(0), dim=-1)
            elif strategy == "patch_mean":
                emb = torch.nn.functional.normalize(h[:,1:,:].mean((0,1)), dim=-1)
            else:
                emb = self._temp_attn(h)
            segs.append({"t0": ts[i], "t1": ts[i+b.window-1],
                         "emb": emb.detach().cpu().to(torch.float32).numpy()})
            enforce_budget(b, self.device)
        elapsed = time.time()-t0
        mins = (len(frames)/max(1e-9, b.fps))/60.0
        meta = {"model": self.model_tag, "weights_hash": self.weights_hash,
                "fps": b.fps, "window": b.window, "crop": b.crop, "segments": len(segs),
                "elapsed_s": elapsed, "sec_per_min": elapsed/max(mins,1e-6), "peak_rss_gb": rss_gb()}
        save(self.cache_dir, k, segs, meta)
        os.makedirs("artifacts", exist_ok=True)
        with open("artifacts/VERSIONS.json","w") as f: json.dump({"vjepa2": self.model_tag, "vjepa2_hash": self.weights_hash}, f)
        return segs, meta
```

---

## `src/embedders/clip_embedder.py`

```python
import torch, av, numpy as np, hashlib
import open_clip
from PIL import Image
from src.utils.memory import Budget, enforce_budget, set_seeds
from src.utils.cache import key, load, save

class CLIPEmbedder:
    def __init__(self, model_name="ViT-H-14", pretrained="laion2B-s32B-b79K", cache_dir="artifacts/cache", seed=1234):
        set_seeds(seed)
        self.device = "mps" if torch.backends.mps.is_available() else "cpu"
        self.model, _, self.preprocess = open_clip.create_model_and_transforms(
            model_name, pretrained=pretrained, device=self.device)
        self.tokenize = open_clip.get_tokenizer(model_name)
        self.cache_dir = cache_dir
        self.model_tag = f"openclip-{model_name}-{pretrained}"
        self.weights_hash = self._weights_fingerprint()

    def _weights_fingerprint(self):
        h = hashlib.sha256()
        sd = {**{k:v for k,v in self.model.state_dict().items()}}
        for k, v in sd.items():
            h.update(k.encode()); h.update(str(tuple(v.shape)).encode()); h.update(str(v.dtype).encode())
            try: h.update(v.view(-1)[:1].detach().cpu().numpy().tobytes())
            except Exception: pass
        return h.hexdigest()[:16]

    def _read_frames(self, path, fps=1.0):
        c = av.open(path); s = c.streams.video[0]
        frames, ts, step = [], [], int(round(s.average_rate / fps)) if s.average_rate else 30
        for i, fr in enumerate(c.decode(s)):
            if i % step == 0:
                frames.append(Image.fromarray(fr.to_ndarray(format="rgb24")))
                ts.append(float(fr.time) if fr.time else (i/float(s.average_rate or 30)))
        c.close(); return frames, ts

    @torch.inference_mode()
    def embed_segments(self, video_path, fps=1.0, window=16, strategy="temp_attn", max_segments=500):
        b = Budget(fps=fps, window=window, crop=224, max_segments=max_segments)
        k = key(video_path, b.fps, b.window, b.crop, strategy, self.model_tag, self.weights_hash)
        cached, meta = load(self.cache_dir, k)
        if cached is not None: return cached, meta

        frames, ts = self._read_frames(video_path, fps=b.fps)
        segs = []
        total_segments = min(len(frames)//b.window, b.max_segments)
        for si in range(total_segments):
            i = si * b.window
            chunk = frames[i:i+b.window]
            imgs = torch.stack([self.preprocess(im) for im in chunk]).to(self.device)
            feats = self.model.encode_image(imgs)              # [T,D]
            feats = torch.nn.functional.normalize(feats, dim=-1)
            q = feats @ feats.mean(0, keepdim=True).T          # temporal attention
            w = torch.softmax(q.squeeze(-1), dim=0)
            emb = torch.nn.functional.normalize((w[:,None]*feats).sum(0), dim=-1)
            segs.append({"t0": ts[i], "t1": ts[i+b.window-1], "emb": emb.cpu().numpy()})
            enforce_budget(b, self.device)
        meta = {"model": self.model_tag, "weights_hash": self.weights_hash,
                "fps": b.fps, "window": b.window, "crop": b.crop, "segments": len(segs)}
        save(self.cache_dir, k, segs, meta)
        return segs, meta

    @torch.inference_mode()
    def encode_text(self, texts):
        tok = self.tokenize(texts).to(self.device)
        z = self.model.encode_text(tok)
        return torch.nn.functional.normalize(z, dim=-1).cpu().numpy()
```

---

## `src/align/align_vjepa_to_clip.py`

```python
import numpy as np
from typing import Tuple

def fit_linear_head(v_embs, t_embs, lam=1e-2):
    V = np.asarray(v_embs, dtype=np.float32)  # [N,Dv]
    T = np.asarray(t_embs, dtype=np.float32)  # [N,Dt]
    Dv = V.shape[1]
    A = V.T @ V + lam * np.eye(Dv, dtype=np.float32)
    B = V.T @ T
    W = np.linalg.solve(A, B)                 # [Dv,Dt]
    return W

def fit_linear_head_kfold(v_embs, t_embs, k=5, lam=1e-2) -> Tuple[np.ndarray, float]:
    V = np.asarray(v_embs, dtype=np.float32); T = np.asarray(t_embs, dtype=np.float32)
    N = len(V); idx = np.arange(N)
    best_W, best_score = None, -1
    for fold in range(k):
        val_mask = (idx % k) == fold
        tr, va = ~val_mask, val_mask
        if tr.sum() == 0 or va.sum() == 0: continue
        W = fit_linear_head(V[tr], T[tr], lam=lam)
        P = project(V[va], W)
        # cosine to targets as quick proxy
        cos = (P * T[va]).sum(axis=1)
        score = float(np.mean(cos))
        if score > best_score: best_W, best_score = W, score
    return best_W if best_W is not None else fit_linear_head(V, T, lam=lam), float(best_score)

def project(V, W):
    P = V @ W
    P /= (np.linalg.norm(P, axis=1, keepdims=True) + 1e-9)
    return P
```

---

## `src/eval/bootstrap_ci.py`

```python
import numpy as np

def bootstrap_ci(samples, iters=1000, alpha=0.05):
    samples = np.array(samples, dtype=np.float32)
    n = len(samples); stats=[]
    for _ in range(iters):
        idx = np.random.randint(0, n, n)
        stats.append(np.mean(samples[idx]))
    stats.sort()
    return stats[int((alpha/2)*iters)], np.mean(stats), stats[int((1-alpha/2)*iters)]
```

---

## `src/eval/ablate_vjepa_vs_clip.py`

```python
import json, numpy as np
from src.embedders.vjepa_embedder import VJEPAEmbedder
from src.embedders.clip_embedder  import CLIPEmbedder
from src.align.align_vjepa_to_clip import fit_linear_head_kfold, project
from src.eval.bootstrap_ci import bootstrap_ci

def cos(a,b):
    a=a/(np.linalg.norm(a)+1e-9); b=b/(np.linalg.norm(b)+1e-9)
    return float((a*b).sum())

def load_manifest(p): return json.load(open(p))

def flatten(idx, vid): return [{"video":vid, **s} for s in idx[vid]]

def build_segments(m, vjepa, clip, fps, window, crop_v=256, max_segments=500):
    idx_v, idx_c = {}, {}
    v_meta = None
    for v in m["videos"]:
        sv, mv = vjepa.embed_segments(v["path"], fps=fps, window=window, crop=crop_v, strategy="temp_attn", max_segments=max_segments)
        sc, _  = clip .embed_segments(v["path"], fps=fps, window=window, strategy="temp_attn", max_segments=max_segments)
        idx_v[v["id"]] = sv; idx_c[v["id"]] = sc; v_meta = mv
    return idx_v, idx_c, v_meta

def positives_hit_fn(q):
    def is_pos(seg):
        for p in q["positives"]:
            if seg["video"]==p["video"] and seg["t0"]>=p["t0"]-0.5 and seg["t1"]<=p["t1"]+0.5:
                return True
        return False
    return is_pos

def topk(index, qvec, K=3):
    sims = [(i, cos(qvec, e["emb"])) for i,e in enumerate(index)]
    sims.sort(key=lambda x: x[1], reverse=True)
    return [index[j[0]] for j in sims[:K]], [s for _,s in sims[:K]]

def eval_manifest(manifest, fps=1.0, window=16, crop_v=256, kfold=5):
    m = load_manifest(manifest)
    vjepa, clip = VJEPAEmbedder(), CLIPEmbedder()
    idx_v, idx_c, v_meta = build_segments(m, vjepa, clip, fps, window, crop_v=crop_v)

    # Text embeddings in CLIP TEXT space
    texts = [q["q"] for q in m["queries"]]
    T = clip.encode_text(texts)

    # Build (V-JEPA video seg, CLIP text) positive pairs
    pairs_v, pairs_t = [], []
    for qi, q in enumerate(m["queries"]):
        for p in q["positives"]:
            for seg in idx_v[p["video"]]:
                if seg["t0"]>=p["t0"]-0.5 and seg["t1"]<=p["t1"]+0.5:
                    pairs_v.append(seg["emb"]); pairs_t.append(T[qi]); break

    # Fit linear head with K-fold CV to reduce overfit risk
    W, _ = fit_linear_head_kfold(pairs_v, pairs_t, k=kfold, lam=1e-2)

    # Flatten indices
    flat_v = [{"video":vid, **seg} for vid, segs in idx_v.items() for seg in segs]
    flat_c = [{"video":vid, **seg} for vid, segs in idx_c.items() for seg in segs]

    # Project V-JEPA embeddings to CLIP text space
    Vproj = project(np.array([s["emb"] for s in flat_v], dtype=np.float32), W)
    Cemb  = np.array([s["emb"] for s in flat_c], dtype=np.float32)

    top3_v, top3_c, mrr_v, mrr_c = [], [], [], []
    for qi, q in enumerate(m["queries"]):
        qvec = T[qi]
        v_top, _ = topk([{"emb":e,**flat_v[i]} for i,e in enumerate(Vproj)], qvec, 3)
        c_top, _ = topk([{"emb":e,**flat_c[i]} for i,e in enumerate(Cemb )], qvec, 3)
        is_pos = positives_hit_fn(q)
        top3_v.append(1 if any(is_pos(s) for s in v_top) else 0)
        top3_c.append(1 if any(is_pos(s) for s in c_top) else 0)
        def mrr(top):
            for r,s in enumerate(top,1):
                if is_pos(s): return 1.0/r
            return 0.0
        mrr_v.append(mrr(v_top)); mrr_c.append(mrr(c_top))

    ci_t3_v = bootstrap_ci(top3_v); ci_t3_c = bootstrap_ci(top3_c)
    ci_mr_v = bootstrap_ci(mrr_v);  ci_mr_c = bootstrap_ci(mrr_c)

    res = {
      "top3": {"vjepa": float(np.mean(top3_v)), "clip": float(np.mean(top3_c)),
                "vjepa_ci": ci_t3_v, "clip_ci": ci_t3_c},
      "mrr":  {"vjepa": float(np.mean(mrr_v)),  "clip": float(np.mean(mrr_c)),
                "vjepa_ci": ci_mr_v,  "clip_ci": ci_mr_c}
    }
    if v_meta is not None:
        res["perf"] = {"vjepa_sec_per_min": v_meta.get("sec_per_min", None),
                        "vjepa_peak_rss_gb": v_meta.get("peak_rss_gb", None)}

    print(json.dumps(res, indent=2))
    return res

if __name__ == "__main__":
    import sys
    eval_manifest(sys.argv[1])
```

---

## `src/scoring/broll_scoring.py`

```python
import numpy as np, json, os

def cosine(a,b):
    a=a/(np.linalg.norm(a)+1e-9); b=b/(np.linalg.norm(b)+1e-9)
    return float((a*b).sum())

def score_candidate(emb_vjepa_proj, emb_clip, qtext_clip, mask_iou, beat_sync,
                    wv=.45, wc=.25, wm=.15, wb=.15, agree_thresh=.25):
    cos_v = cosine(emb_vjepa_proj, qtext_clip)
    cos_c = cosine(emb_clip,       qtext_clip)
    if cos_v < agree_thresh or cos_c < agree_thresh:
        wv = min(wv, .15)
    score = wv*cos_v + wc*cos_c + wm*mask_iou + wb*beat_sync
    return score, {"cos_v":cos_v,"cos_c":cos_c,"wm":wm,"wb":wb}

def log_decision(path, record):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a") as f: f.write(json.dumps(record)+"\n")
```

---

## `datasets/broll_pilot/manifest.json` (you provide)

* ≥ **50** queries, stratified across categories (people/action/objects/landscape).
* For each, list **positives** with `{video, t0, t1}` windows.

Example shape:

```json
{
  "videos": [
    {"id":"a1","path":"assets/pilots/a1.mp4"},
    {"id":"b2","path":"assets/pilots/b2.mp4"}
  ],
  "queries": [
    {"q":"wide aerial city at sunset","positives":[{"video":"a1","t0":60.0,"t1":75.0}]}
  ]
}
```

---

## `Makefile`

```make
PY=python

setup:
	$(PY) -m pip install -r requirements.txt

# A/B eval (prints JSON with top3/MRR, CIs, and V-JEPA perf)
eval-ablate:
	$(PY) -m src.eval.ablate_vjepa_vs_clip datasets/broll_pilot/manifest.json

# Speed test on a 5-minute clip (prints segments, sec/min, peak RSS)
bench-vjepa:
	$(PY) - << 'PY'
from src.embedders.vjepa_embedder import VJEPAEmbedder
E=VJEPAEmbedder()
segs, meta = E.embed_segments("assets/pilots/clip_5m.mp4", fps=1.0, window=16, strategy="temp_attn")
print({"segments": len(segs), **meta})
PY

bench-clip:
	$(PY) - << 'PY'
from src.embedders.clip_embedder import CLIPEmbedder
E=CLIPEmbedder()
segs, meta = E.embed_segments("assets/pilots/clip_5m.mp4", fps=1.0, window=16, strategy="temp_attn")
print({"segments": len(segs), **meta})
PY

# Clean cache (if you change models or configs)
clean-cache:
	rm -rf artifacts/cache/*.npz artifacts/cache/*.json || true
```

---

## Promotion Logic (copy into your app)

```python
def promote_vjepa(results, sec_per_min):
    top3_gain = results["top3"]["vjepa"] / max(1e-9, results["top3"]["clip"]) - 1.0
    mrr_gain  = results["mrr"]["vjepa"]  / max(1e-9, results["mrr"]["clip"])  - 1.0
    ci_lower_t3 = results["top3"]["vjepa_ci"][0] - results["top3"]["clip_ci"][2]
    ci_lower_mr = results["mrr"]["vjepa_ci"][0]  - results["mrr"]["clip_ci"][2]
    return (top3_gain >= 0.15 and mrr_gain >= 0.15 and ci_lower_t3 > 0 and ci_lower_mr > 0 and sec_per_min <= 5.0)
```

---

## Ship Checklist (no hand‑waving)

1. `make setup`
2. Fill `datasets/broll_pilot/manifest.json` with **50+ queries** (real, stratified).
3. `make eval-ablate` → confirm **≥15%** gains with **95% CI LB > 0**.
4. `make bench-vjepa` → confirm **sec\_per\_min ≤ 5.0** and **peak\_rss\_gb < 16** in meta.
5. If both pass → set `default_model = vjepa` in `conf/embeddings.ini`. Else keep `clip`.
6. Commit and ship.

---

## v3.1 (out of scope for this repo)

* **SAM2 text→box long‑tracking:** GroundingDINO → SAM2 video → SAM2Long memory tree.
* **Audio generation:** ACE‑Step / YuE / MMAudio; each gated by a tiny Proof Pack (run locally, license verified, LUFS/sync checked).

---

**This is the final, brutally lean blueprint. Paste this structure, fill the manifest, run the A/B. The model that earns the win ships—no exceptions.**
