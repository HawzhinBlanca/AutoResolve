#!/usr/bin/env bash

# Auto-Editor Integration Script for Silence Removal
# Uses Auto-Editor to generate FCPXML with silence cuts

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

INPUT=${1:?"input video is required"}
OUT_FCPXML=${2:-"./artifacts/editdata/cuts.fcpxml"}

# Ensure output directory exists
mkdir -p "$(dirname "$OUT_FCPXML")"

# Check if Auto-Editor is installed
if ! command -v auto-editor >/dev/null 2>&1; then
    echo -e "${YELLOW}Auto-Editor not found, installing...${NC}" >&2
    pip install auto-editor
fi

echo -e "${GREEN}Processing silence removal for: $INPUT${NC}" >&2

# Run Auto-Editor with optimized parameters for video content
# --motion-threshold: How much motion is needed to not be cut
# --edit-based-on: What to base cuts on (audio for silence removal)
# --margin: Frames to add before and after cuts
# --frame-margin: Additional frames to keep for smooth cuts
# --export: Export format (final-cut-pro for DaVinci Resolve compatibility)
# --min-clip-length: Minimum length of clips to keep

auto-editor \
    "$INPUT" \
    --edit-based-on audio \
    --silent-threshold 0.04 \
    --silent-speed 99999 \
    --frame-margin 6 \
    --min-clip-length 0.5 \
    --export final-cut-pro \
    --output "$OUT_FCPXML" \
    --no-open \
    --temp-dir "$(dirname "$OUT_FCPXML")/../temp" \
    2>&1 | tee "$(dirname "$OUT_FCPXML")/../logs/auto_editor.log" || {
        echo -e "${RED}Error: Auto-Editor failed${NC}" >&2
        exit 1
    }

# Check if output was created
if [ -f "$OUT_FCPXML" ]; then
    echo -e "${GREEN}✓ FCPXML generated successfully: $OUT_FCPXML${NC}" >&2
    
    # Extract cut statistics for logging
    CLIP_COUNT=$(grep -c "clip" "$OUT_FCPXML" 2>/dev/null || echo "0")
    echo -e "${GREEN}✓ Found $CLIP_COUNT clips after silence removal${NC}" >&2
else
    echo -e "${RED}Error: Failed to generate FCPXML${NC}" >&2
    exit 1
fi

echo -e "${GREEN}✓ Silence removal complete${NC}" >&2
