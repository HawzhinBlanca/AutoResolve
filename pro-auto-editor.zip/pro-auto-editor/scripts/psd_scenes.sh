#!/usr/bin/env bash

# PySceneDetect Integration Script for Scene Detection
# Uses PySceneDetect to generate OTIO with scene cuts

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

INPUT=${1:?"input video is required"}
OUT_OTIO=${2:-"./artifacts/editdata/scenes.otio"}

OUT_DIR=$(dirname "$OUT_OTIO")
TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT

# Ensure output directory exists
mkdir -p "$OUT_DIR"

# Check if PySceneDetect is installed
if ! command -v scenedetect >/dev/null 2>&1; then
    echo -e "${YELLOW}PySceneDetect not found, installing...${NC}" >&2
    pip install scenedetect[opencv]
fi

echo -e "${GREEN}Detecting scenes in: $INPUT${NC}" >&2

# Run PySceneDetect with optimized parameters
# detect-content: Content-aware scene detection
# --threshold: Sensitivity for scene changes (lower = more sensitive)
# save-images: Optional - save thumbnails of detected scenes
# list-scenes: Generate CSV with scene timecodes

scenedetect \
    -i "$INPUT" \
    detect-content \
    --threshold 27.0 \
    list-scenes \
    -o "$TMPDIR" \
    2>&1 | tee "$OUT_DIR/../logs/scenedetect.log" || {
        echo -e "${RED}Error: PySceneDetect failed${NC}" >&2
        exit 1
    }

# Find the generated CSV file
CSV=$(find "$TMPDIR" -name "*.csv" | head -n1)

if [ -z "$CSV" ] || [ ! -f "$CSV" ]; then
    echo -e "${RED}Error: No scene list CSV generated${NC}" >&2
    exit 1
fi

echo -e "${GREEN}Converting CSV to OTIO format...${NC}" >&2

# Convert CSV to OTIO using Python
python3 -c "
import csv
import json
import sys
from pathlib import Path

def timecode_to_seconds(timecode):
    '''Convert HH:MM:SS.mmm to seconds'''
    parts = timecode.split(':')
    hours = float(parts[0]) if len(parts) > 2 else 0
    minutes = float(parts[-2]) if len(parts) > 1 else 0  
    seconds = float(parts[-1])
    return hours * 3600 + minutes * 60 + seconds

# Read scene CSV
scenes = []
with open('$CSV', 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        start_time = timecode_to_seconds(row['Start Time'])
        end_time = timecode_to_seconds(row['End Time'])
        scenes.append({
            'scene_number': int(row['Scene Number']),
            'start_time': start_time,
            'end_time': end_time,
            'duration': end_time - start_time,
            'start_frame': row.get('Start Frame', ''),
            'end_frame': row.get('End Frame', '')
        })

# Create simplified OTIO-like structure
otio_data = {
    'OTIO_SCHEMA': 'Timeline.1',
    'metadata': {
        'source_file': '$INPUT',
        'scene_count': len(scenes),
        'detection_method': 'pyscenedetect',
        'threshold': 27.0
    },
    'name': 'scenes',
    'tracks': [{
        'OTIO_SCHEMA': 'Track.1',
        'name': 'V1',
        'kind': 'Video',
        'children': [
            {
                'OTIO_SCHEMA': 'Clip.1',
                'name': f'Scene_{scene[\"scene_number\"]}',
                'source_range': {
                    'start_time': {
                        'OTIO_SCHEMA': 'RationalTime.1',
                        'value': int(scene['start_time'] * 30),  # Assume 30fps
                        'rate': 30
                    },
                    'duration': {
                        'OTIO_SCHEMA': 'RationalTime.1', 
                        'value': int(scene['duration'] * 30),  # Assume 30fps
                        'rate': 30
                    }
                },
                'metadata': {
                    'start_time_seconds': scene['start_time'],
                    'end_time_seconds': scene['end_time'],
                    'duration_seconds': scene['duration']
                }
            } for scene in scenes
        ]
    }]
}

# Write OTIO file
with open('$OUT_OTIO', 'w') as f:
    json.dump(otio_data, f, indent=2)

print(f'Converted {len(scenes)} scenes to OTIO format')
" || {
    echo -e "${RED}Error: CSV to OTIO conversion failed${NC}" >&2
    exit 1
}

# Check if output was created
if [ -f "$OUT_OTIO" ]; then
    SCENE_COUNT=$(python3 -c "
import json
with open('$OUT_OTIO') as f:
    data = json.load(f)
    print(data['metadata']['scene_count'])
    ")
    echo -e "${GREEN}✓ OTIO generated successfully: $OUT_OTIO${NC}" >&2
    echo -e "${GREEN}✓ Detected $SCENE_COUNT scenes${NC}" >&2
else
    echo -e "${RED}Error: Failed to generate OTIO${NC}" >&2
    exit 1
fi

echo -e "${GREEN}✓ Scene detection complete${NC}" >&2
