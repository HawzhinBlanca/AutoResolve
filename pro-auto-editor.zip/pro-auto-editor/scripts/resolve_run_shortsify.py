# Resolve internal runner
from __future__ import annotations
import json
from pathlib import Path
from resolve_api.core import connect
from pipelines.shortsify import main as shortsify_main

def run(input_path: str, artifacts_root: str):
    # Ensure we can connect inside Resolve host
    h = connect()
    # Call the pipeline CLI-style
    import sys
    sys.argv = ['shortsify.py', '--input', input_path, '--artifacts', artifacts_root]
    return shortsify_main()

if __name__ == '__main__':
    # Adjust these paths as needed before running from Resolve Scripts menu
    ip = '/Users/hawzhin/AutoResolve/test_video_43min.mp4'
    ar = '/Users/hawzhin/AutoResolve/pro-auto-editor/artifacts'
    rc = run(ip, ar)
    print(json.dumps({'status': 'done', 'rc': rc}))
