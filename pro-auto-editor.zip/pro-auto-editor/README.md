# pro-auto-editor

Production-grade Resolve pipeline per Blueprint.md (implemented end-to-end). This README documents setup, usage, and QC with Resolve scripting.

## Prerequisites
- macOS (Apple Silicon) with Homebrew
- DaVinci Resolve 18/20 Studio installed and scripting enabled
  - Preferences → System → General → Enable scripting
  - Add scripting modules to PYTHONPATH if needed:
    - `/Library/Application Support/Blackmagic Design/DaVinci Resolve/Developer/Scripting/Modules`
    - `/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Resources/Developer/Scripting/Modules`
- Python 3.11+
- ffmpeg installed (`brew install ffmpeg`)

## Install
```bash
cd pro-auto-editor
make setup
```

## Inputs and Artifacts
- Place long-form inputs in `inputs/` or pass absolute paths
- Pipeline artifacts live under `artifacts/`:
  - `artifacts/editdata/` cuts.fcpxml, scenes.otio, transcript.json, selection/config JSON
  - `artifacts/broll.db` OpenCLIP sqlite index
  - `artifacts/logs/pipeline.jsonl` structured logs
  - `artifacts/renders/` output files

## Workflow (Core)
1) Generate cuts and scenes
```bash
make cuts INPUT=inputs/test_main.mp4
make scenes INPUT=inputs/test_main.mp4
```

2) (Optional) Transcribe for better B‑roll queries
```bash
make transcript INPUT=inputs/test_main.mp4
```

3) Build/refresh B‑roll index
Update `conf/broll.yaml` to include your local library paths. This repo includes your `inputs` folder by default.
```yaml
libraries:
  - "/Users/hawzhin/AutoResolve/pro-auto-editor/inputs"
  # add more absolute folders as needed
```
Then index:
```bash
make index-broll
```

4) Run the Resolve pipeline (shortsify)
- Preferred: run from inside Resolve (Scripts) to guarantee the scripting API is available.
  - Edit `scripts/resolve_run_shortsify.py` bottom lines to set `input_path` and `artifacts_root`.
  - Execute the script from Resolve’s Scripts menu.

- Or: run from terminal while Resolve is open (scripting enabled):
```bash
python3 -m pipelines.shortsify \
  --input /absolute/path/to/your/video.mp4 \
  --artifacts /Users/hawzhin/AutoResolve/pro-auto-editor/artifacts \
  --enable_smart_crop
```

Flags:
- `--enable_smart_crop` enables subject‑centric clip‑level ROI when timeline resolution changes fail on your Resolve build. The pipeline first attempts timeline resolution changes; on failure, it falls back to per‑clip Zoom/Position guided by edge‑centroid estimation.
- `--disable_broll`, `--disable_captions`, `--disable_audio_polish`, `--no_render` are available for debugging.

5) QC gates
```bash
make qc
```
Runs:
- Cut parity and/or basic scene validation
- B‑roll bounds and coverage ratio
- Render smoke (ffprobe) on the latest output if present

## Logging
Structured JSONL logs are written to `artifacts/logs/pipeline.jsonl`. Key events: `shortsify_*`, `import_fcpxml_*`, `duplicate_timeline_*`, `transform_timeline_*`, `append_broll_*`, `queue_render_profile`, `render_complete_profile`.

## Troubleshooting
- Resolve scripting not found from terminal
  - Ensure Resolve is running and scripting is enabled
  - Export the scripting modules path into `PYTHONPATH`
  - Prefer running `scripts/resolve_run_shortsify.py` inside Resolve

- `import_fcpxml_failed`
  - The pipeline falls back to creating/using the current timeline and ensures the base clip on V1. Verify media paths and `conf/project.yaml` `media_root` if you rely on relinking.

- `transform_resolution_failed`
  - Some Resolve builds restrict programmatic timeline resolution changes. With `--enable_smart_crop` the pipeline applies clip‑level ROI to reframe 9×16 and 1×1.

- Empty B‑roll selection
  - Make sure `conf/broll.yaml` points to actual folders and run `make index-broll`. You can also generate a selection directly:
  ```bash
  python3 -m tools.broll_select --db artifacts/broll.db \
    --output artifacts/editdata/broll_selection.json --window_start 0 --window_duration 60 --k 8
  ```

## Modules Overview
- `resolve_api/core.py`: connect(), absolute path guards, `hash8()`
- `resolve_api/timeline_ops.py`: import FCPXML, duplicate timeline, transform ROI (timeline or clip‑level), append B‑roll to V2
- `resolve_api/captions_ops.py`: TranscribeAudio → CreateSubtitlesFromAudio; apply subtitle styling
- `resolve_api/audio_ops.py`: Voice Isolation, Dialogue Leveler (where supported)
- `resolve_api/render_ops.py`: safe SetRenderSettings, AddRenderJob (retry), Start+poll
- `broll/index.py`: keyframes → OpenCLIP embeddings (averaged) → sqlite
- `broll/query.py`: phrase extraction + text embeddings
- `broll/select.py`: ranking with cascade + MMR diversity; selection JSON
- `pipelines/shortsify.py`: end‑to‑end orchestration, variants, renders
- `pipelines/multicam_podcast.py`: multicam build, SmartSwitch UI step, continue
- `tests/`: QC gates

## Naming and Fingerprints
Filanames: `{project}_{timeline}_{profile}_{YYYYMMDD-HHMMss}_{hash8}`
Hash inputs: `cuts.fcpxml`, `scenes.otio`, `broll_selection.json`, `caption_settings.json`, `transform_params.json`.

## Security Notes
- Absolute paths only; no secrets committed
- Safe YAML load, structured logs

